/** @format */

// ** info: nest core imports
import { APP_INTERCEPTOR } from "@nestjs/core"

// ** info: nest common imports
import { MiddlewareConsumer } from "@nestjs/common"
import { Module } from "@nestjs/common"
import { Logger } from "@nestjs/common"

// ** info: nest config imports
import { ConfigService } from "@nestjs/config"
import { ConfigModule } from "@nestjs/config"

// ** info: nest axios imports
import { HttpModule } from "@nestjs/axios"

// ** info: nest pino
import { LoggerModule } from "nestjs-pino"

// ** info: common artifacts imports
import { AllExceptionsFilter } from "@common-artifacts/decorators/all-exceptions.filter"
import { LoggingInterceptor } from "@common-artifacts/interceptors/logging.interceptor"
import { validationSchema } from "@common-artifacts/config/app-validation.schema"
import { LoggingService } from "@common-artifacts/logger-service/logging.service"
import { AuthMiddleware } from "@common-artifacts/middleware/auth.middleware"
import config from "@common-artifacts/config/app.config"

// ** info: common modules imports
import { DataTreatementModule } from "@common-modules/data-treatement/data-treatement.module"
import { AuthenticationModule } from "@common-modules/authentication/authentication.module"
import { DianDatabaseModule } from "@common-modules/dian-database/dian-database.module"
import { CustomLoggerModule } from "@common-artifacts/logger-service/logger.module"

// ** info: core modules imports
import { DianTransversalModule } from "@core-modules/transversal/dian-transversal.module"
import { ConsolidatedModule } from "@core-modules/consolidated/consolidated.module"
import { LoadAlertsModule } from "@core-modules/load-alerts/load-alerts.module"
import { MovementsModule } from "@core-modules/movements/movements.module"
import { SummarysModule } from "@core-modules/summarys/summarys.module"
import { OfficesModule } from "@core-modules/offices/offices.module"
import { ReportsModule } from "@core-modules/reports/reports.module"
import { IssuesModule } from "@core-modules/issues/issues.module"
import { HealthModule } from "@core-modules/health/health.module"
import { TaxesModule } from "@core-modules/taxes/taxes.module"

const envMode: string = process.env.ENVIRONMENT_MODE

// todo: move pino config to separated file
const formatters: object = {
	level(label: string) {
		return { severity: label }
	},
}

// todo: move pino config to separated file
const pinoProdConfig: object = {
	pinoHttp: {
		base: { pid: process.pid },
		formatters: formatters,
		messageKey: "message",
		timestamp: false,
		level: "debug",
	},
}

// todo: move pino config to separated file
const pinoDevConfig: object = {
	pinoHttp: {
		transport: {
			target: "pino-pretty",
			options: {
				ignore: "pid,hostname,err",
				levelFirst: true,
				singleLine: true,
				colorize: true,
			},
		},
		level: "debug",
	},
}

let pinoConfig: object

// ** info: selecting logger config
if (envMode === "production") {
	pinoConfig = pinoProdConfig
} else {
	pinoConfig = pinoDevConfig
}

@Module({
	imports: [
		ConfigModule.forRoot({
			validationSchema: validationSchema,
			ignoreEnvFile: envMode === "production" ? true : false,
			envFilePath: `.env`,
			load: [config],
			isGlobal: true,
		}),
		LoggerModule.forRoot(pinoConfig),
		DianTransversalModule,
		AuthenticationModule,
		DataTreatementModule,
		ConsolidatedModule,
		DianDatabaseModule,
		CustomLoggerModule,
		LoadAlertsModule,
		MovementsModule,
		SummarysModule,
		OfficesModule,
		ReportsModule,
		HealthModule,
		IssuesModule,
		TaxesModule,
		HttpModule,
	],
	providers: [
		AllExceptionsFilter,
		LoggingService,
		AuthMiddleware,
		{
			useClass: LoggingInterceptor,
			provide: APP_INTERCEPTOR,
		},
	],
})
export class AppModule {
	private readonly logger: Logger = new Logger(AppModule.name)

	public static port: number
	public constructor(private readonly configService: ConfigService) {
		AppModule.port = this.configService.get("HTTP_PORT")
	}

	public configure(consumer: MiddlewareConsumer): void {
		if (this.configService.get("ACTIVE_AUTH") == true) {
			this.logger.debug(
				{ authMiddlewarActivationValue: this.configService.get("ACTIVE_AUTH") },
				"auth middleware active"
			)
			consumer.apply(AuthMiddleware).exclude("/health").forRoutes("*")
		} else {
			this.logger.debug(
				{ authMiddlewarActivationValue: this.configService.get("ACTIVE_AUTH") },
				"auth middleware inactive"
			)
		}
	}
}
