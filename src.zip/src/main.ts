/** @format */

// ** info: common artifacts imports
import { ValidationException } from "@common-artifacts/decorators/validation.filter"

// ** info: nest common imports
import { INestApplication } from "@nestjs/common"
import { ValidationError } from "@nestjs/common"
import { ValidationPipe } from "@nestjs/common"

// ** info: nest pino
import { Logger } from "nestjs-pino"

// ** info: nest core imports
import { NestFactory } from "@nestjs/core"

// ** info: app main module import
import { AppModule } from "./app.module"

// ** info: helmet imports
import helmet from "helmet"

async function main(): Promise<void> {
	const app: INestApplication = await NestFactory.create(AppModule, {
		bufferLogs: true,
	})
	app.useLogger(app.get(Logger))

	// ** info: setting up the main server global pipes.
	app.useGlobalPipes(
		new ValidationPipe({
			forbidNonWhitelisted: true,
			whitelist: true,

			// todo: disable and remove rule omition
			// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
			exceptionFactory: (errors: ValidationError[]) => {
				let errMsg: string = ""

				// todo: disable and remove rule omition
				// eslint-disable-next-line @typescript-eslint/typedef
				errors.forEach((err) => {
					errMsg = errMsg + err.property + ","
				})

				const message: string =
					"Bad Request. Datos de entrada no validos: " + errMsg
				const messagePrettier: string = message.substring(0, message.length - 1)

				return new ValidationException(messagePrettier)
			},
		})
	)

	// ** info: setting up the main server middlewares
	app.enableCors()
	app.use(helmet())

	// ** info: starting the app
	await app.listen(AppModule.port)
}

main()
