/** @format */

import { Injectable } from "@nestjs/common"

@Injectable()
export class DataTreatementService {
	public fillWithCharacter(params: {
		string: string
		character: string
		desiredLenght: number
		right: boolean
	}): string {
		let complementaryString: string = ""
		let newString: string = ""

		const dif: number = params.desiredLenght - params.string.length
		if (dif < 0) {
			return params.string
		}

		complementaryString = complementaryString.concat(
			params.character.repeat(dif)
		)

		if (!params.right) {
			newString = complementaryString.concat(params.string)
		} else {
			newString = params.string.concat(complementaryString)
		}

		return newString
	}
}
