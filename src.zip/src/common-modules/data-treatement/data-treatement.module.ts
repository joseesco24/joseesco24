/** @format */

import { Module } from "@nestjs/common"
import { Global } from "@nestjs/common"

import { DataTreatementService } from "@common-modules/data-treatement/data-treatement.service"

@Global()
@Module({
	providers: [DataTreatementService],
	exports: [DataTreatementService],
	imports: [DataTreatementService],
})
export class DataTreatementModule {}
