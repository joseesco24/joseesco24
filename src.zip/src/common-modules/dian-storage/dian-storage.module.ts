/** @format */

// ** info: nest imports
import { Module } from "@nestjs/common"

// ** info: dian storage service import
import { DianStorageService } from "@common-modules/dian-storage/services/dian-storage.service"

@Module({
	providers: [DianStorageService],
	exports: [DianStorageService],
})
export class DianStorageModule {}
