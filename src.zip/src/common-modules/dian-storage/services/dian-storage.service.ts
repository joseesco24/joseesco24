/** @format */

// ** info: gcp imports
import { DownloadResponse } from "@google-cloud/storage"
import { Storage } from "@google-cloud/storage"

// ** info: nest imports
import { Injectable } from "@nestjs/common"

@Injectable()
export class DianStorageService {
	private readonly storage: Storage

	public constructor() {
		this.storage = new Storage({})
	}

	public async getReportByPath(params: {
		reportPath: string
	}): Promise<Buffer> {
		// todo: replace burned parametrization by params table call
		// ! warning: burned parametrization here [ gcpBucket ]
		const gcpBucket: string = "o3i-backofficegcs-d01"

		const fileResponse: DownloadResponse = await this.storage
			.bucket(gcpBucket)
			.file(params.reportPath)
			.download({})

		const buffer: Buffer = fileResponse[0]

		return buffer
	}
}
