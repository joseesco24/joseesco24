/** @format */

import { Type } from "class-transformer"
import { IsNotEmpty, IsNumber } from "class-validator"

/**Custom Imports */
import { IssuesFoundData } from "@core-modules/issues/dtos/issuesFoundData.dto"

export class IssuesDataCount {
	@IsNumber()
	@IsNotEmpty()
	public count!: number

	@Type(() => IssuesFoundData)
	@IsNotEmpty()
	public data!: IssuesFoundData[]
}
