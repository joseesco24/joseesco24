/** @format */

import { IsInt, IsNotEmpty, IsString } from "class-validator"

export class FoundPaymentDate {
	@IsString()
	@IsNotEmpty()
	public systemDate!: string

	@IsString()
	@IsNotEmpty()
	public paymentDate!: string

	@IsInt()
	@IsNotEmpty()
	public dayTypeDomainId!: number
}
