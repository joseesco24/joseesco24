/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsString } from "class-validator"
import { IsNumber } from "class-validator"
import { IsInt } from "class-validator"

export class NotNullishForm {
	@IsString()
	@IsNotEmpty()
	public paymentForm!: string

	@IsString()
	@IsNotEmpty()
	public realDate!: string

	@IsString()
	@IsNotEmpty()
	public taxName!: string

	@IsNumber()
	@IsNotEmpty()
	public paymentsValue!: number

	@IsInt()
	@IsNotEmpty()
	public paymentsCount!: number
}

export class NotNullishForm2 extends NotNullishForm {
	@IsInt()
	@IsNotEmpty()
	public paymentsMethod!: string
}
