/** @format */

import { IsBoolean, IsInt, IsString } from "class-validator"

export class FoundIssueByIdExc {
	@IsString()
	public declarationNumber!: string

	@IsString()
	public paymentValuePesos!: number

	@IsInt()
	public nitOrId!: number

	@IsBoolean()
	public exclude!: boolean

	@IsInt()
	public movementId!: number
}
