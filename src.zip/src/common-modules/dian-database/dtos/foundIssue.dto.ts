/** @format */

import { IsBoolean, IsInt, IsNumberString, IsString } from "class-validator"

export class FoundIssue {
	@IsString()
	public adhesiveNumber!: string

	@IsString()
	public referenceNumber!: string

	@IsString()
	public accountNumber!: string

	@IsString()
	public paymentValue!: string

	@IsString()
	public dayTypeDescription!: string

	@IsNumberString()
	public channelInd!: string | number

	@IsString()
	public systemDate!: string

	@IsInt()
	public movementId!: number

	@IsInt()
	public reportId!: number

	@IsBoolean()
	public exclude!: boolean
}
