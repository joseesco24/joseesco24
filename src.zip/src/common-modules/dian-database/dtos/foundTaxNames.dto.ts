/** @format */

import { IsString } from "class-validator"

export class FoundTaxNames {
	@IsString()
	public taxName!: string
}
