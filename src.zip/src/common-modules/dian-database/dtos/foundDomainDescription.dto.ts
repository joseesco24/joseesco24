/** @format */

import { IsNumber, IsString } from "class-validator"

export class FoundDomainDescription {
	@IsString()
	public domainDescription!: string

	@IsNumber()
	public domainId!: number

	@IsString()
	public realValue!: string
}
