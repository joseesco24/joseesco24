/** @format */

import { IsInt } from "class-validator"

export class LastIssueFound {
	@IsInt()
	public movementId!: number

	@IsInt()
	public issueType!: number
}
