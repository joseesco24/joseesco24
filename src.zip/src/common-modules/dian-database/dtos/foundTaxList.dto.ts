/** @format */

import { IsInt, IsString } from "class-validator"

export class FoundTaxList {
	@IsString()
	public description!: string

	@IsInt()
	public id!: number
}
