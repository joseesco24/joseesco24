/** @format */

import { IsInt, IsNumberString, IsString } from "class-validator"

export class FoundIssueByIdMod {
	@IsString()
	public taxName!: string

	@IsString()
	public adhesiveNumber!: string

	@IsString()
	public declarationNumber!: string

	@IsString()
	public accountNumber!: string

	@IsString()
	public paymentValuePesos!: string

	@IsString()
	public dayTypeDescription!: string

	@IsInt()
	public earId!: number

	@IsInt()
	public contributionIndicator!: number

	@IsNumberString()
	public channelInd!: string | number

	@IsString()
	public paymentMethod!: string

	@IsString()
	public systemDate!: string

	@IsString()
	public operationNumber!: string

	@IsString()
	public authorizationNumber!: string

	@IsString()
	public contributorId!: string

	@IsString()
	public limitPaymentDate!: string

	@IsString()
	public hashNumber!: string

	@IsString()
	public iacCode!: string

	@IsString()
	public terminalId!: string

	@IsInt()
	public movementId!: number
}
