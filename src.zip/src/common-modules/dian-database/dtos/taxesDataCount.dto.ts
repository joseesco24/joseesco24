/** @format */

import { Type } from "class-transformer"
import { IsNotEmpty, IsNumber } from "class-validator"
import { TaxesFoundData } from "./taxesFoundData.dto"

export class TaxesDataCount {
	@IsNumber()
	@IsNotEmpty()
	public count!: number

	@Type(() => TaxesFoundData)
	@IsNotEmpty()
	public data!: TaxesFoundData[]
}
