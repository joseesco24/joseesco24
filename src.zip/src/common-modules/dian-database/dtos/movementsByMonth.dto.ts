/** @format */

import { IsNotEmpty, IsString } from "class-validator"

export class MovementsByMonth {
	@IsNotEmpty()
	@IsString()
	public paymentValueSum!: string

	@IsNotEmpty()
	@IsString()
	public month!: string

	@IsNotEmpty()
	@IsString()
	public count!: string
}
