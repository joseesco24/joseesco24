/** @format */

import { IsBoolean, IsInt, IsNotEmpty, IsString } from "class-validator"

export class TaxesFoundData {
	@IsNotEmpty()
	@IsString()
	public taxName!: string

	@IsNotEmpty()
	@IsString()
	public dianMode!: number

	@IsNotEmpty()
	@IsBoolean()
	public status!: boolean

	@IsNotEmpty()
	@IsInt()
	public formId!: boolean

	@IsNotEmpty()
	@IsInt()
	public conceptId!: boolean

	@IsNotEmpty()
	@IsString()
	public modificationUser!: string

	@IsNotEmpty()
	@IsString()
	public lastModificationDate!: string

	@IsNotEmpty()
	@IsInt()
	public taxId!: number
}
