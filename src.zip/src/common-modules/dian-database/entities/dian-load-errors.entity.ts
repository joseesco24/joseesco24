/** @format */

import {
	Column,
	Entity,
	Index,
	JoinColumn,
	ManyToOne,
	PrimaryGeneratedColumn,
} from "typeorm"
import { DianBatchLoad } from "@common-modules/dian-database/entities/dian-batch-load.entity"

@Index("dian_errores_cargue_pkey", ["codigoCargueError"], { unique: true })
@Entity("dian_errores_cargue", { schema: "sc_estadistico_dian" })
export class DianLoadError {
	@ManyToOne(
		() => DianBatchLoad,
		(dianBatchLoad: DianBatchLoad) => dianBatchLoad.codigoCargue
	)
	@JoinColumn([{ referencedColumnName: "codigoCargue", name: "codigo_cargue" }])
	@Column("integer", { name: "codigo_cargue" })
	public codigoCargue: number

	@PrimaryGeneratedColumn({ type: "integer", name: "codigo_cargue_error" })
	public codigoCargueError: number

	@Column("character varying", { name: "descripcion_error", length: 500 })
	public descripcionError: string

	@Column("integer", { name: "numero_registro_error" })
	public numeroRegistroError: number
}
