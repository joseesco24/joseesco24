/** @format */

// ** info: typeorm imports
import { OneToMany, PrimaryGeneratedColumn } from "typeorm"
import { JoinColumn } from "typeorm"
import { ManyToOne } from "typeorm"
import { Column } from "typeorm"
import { Entity } from "typeorm"
import { Index } from "typeorm"

// ** info: other entities imports
import { DianDomain } from "@common-modules/dian-database/entities/dian-domain.entity"
import { DianTax } from "@common-modules/dian-database/entities/dian-tax.entity"
import { DianIssues } from "./dian-issues.entity"

@Index(
	"dian_movimientos_adhesivo_cus_numero_declaracion_key",
	["adhesiveOrCus", "declarationNumber"],
	{ unique: true }
)
@Index("dian_movimientos_pkey", ["movementId"], { unique: true })
@Entity("dian_movimientos", { schema: "sc_estadistico_dian" })
export class DianMovements {
	@PrimaryGeneratedColumn({ type: "integer", name: "codigo_movimiento" })
	public readonly movementId!: number

	@Column("integer", { name: "codigo_generacion_reporte_1188", nullable: true })
	public readonly reportId1188!: number

	@Column("integer", { name: "codigo_generacion_reporte_1740", nullable: true })
	public readonly reportId1740!: number

	@Column("integer", { name: "codigo_cargue", nullable: true })
	public readonly loadId!: number

	@Column("integer", { name: "dominio_modalidad_dian", nullable: false })
	public readonly dianModeDomain!: number

	@Column("integer", { name: "dominio_tipo_inconsistencia", nullable: true })
	public readonly issueTypeDomain: number

	@ManyToOne(
		() => DianDomain,
		(paymentFormDomain: DianDomain) => paymentFormDomain.id
	)
	@JoinColumn([{ referencedColumnName: "id", name: "dominio_forma_pago" }])
	public readonly paymentFormDomain!: number

	@ManyToOne(
		() => DianDomain,
		(typeFormDomain: DianDomain) => typeFormDomain.id
	)
	@JoinColumn([{ referencedColumnName: "id", name: "dominio_tipo_formulario" }])
	public readonly typeFormDomain!: number

	@Column("integer", { name: "dominio_tipo_contable", nullable: true })
	public readonly accountTypeDomain!: number

	@ManyToOne(() => DianTax, (taxId: DianTax) => taxId.taxId)
	@JoinColumn([{ referencedColumnName: "taxId", name: "codigo_impuesto" }])
	public readonly taxId!: number

	@Column("integer", { name: "codigo_ear_real", nullable: false })
	public readonly earId!: number

	@Column({
		name: "dominio_tipo_archivo",
		type: "integer",
		nullable: true,
	})
	public readonly fileTypeDomainId!: number

	@Column({
		name: "dominio_ind_jornada",
		type: "integer",
		nullable: false,
	})
	public readonly dayTypeDomainId!: number

	@Column("character varying", {
		name: "adhesivo_cus",
		length: 16,
		nullable: true,
	})
	public readonly adhesiveOrCus!: string

	@Column("bigint", { name: "numero_declaracion", nullable: false })
	public readonly declarationNumber!: number

	@Column("timestamp without time zone", {
		name: "fecha_jornada",
		nullable: true,
	})
	public readonly paymentDate!: Date

	@Column("timestamp without time zone", {
		name: "fecha_real",
		nullable: false,
	})
	public readonly realDate!: Date

	@Column("time without time zone", { name: "hora_real", nullable: false })
	public readonly realHour!: string

	@Column("bigint", { name: "nit_o_cedula", nullable: false })
	public readonly nitOrId!: number

	@Column("smallint", { name: "motivo", nullable: false })
	public readonly formId!: number

	@Column("numeric", {
		name: "valor_cheque",
		precision: 19,
		scale: 2,
		nullable: false,
	})
	public readonly paymentValueCheque!: number

	@Column("numeric", {
		name: "valor_unidad",
		precision: 19,
		scale: 2,
		nullable: false,
	})
	public readonly paymentValueUnit!: number

	@Column("numeric", {
		name: "valor_pesos",
		precision: 19,
		scale: 2,
		nullable: false,
	})
	public readonly paymentValuePesos!: number

	@Column("integer", { name: "id_terminal", nullable: false })
	public readonly terminalId: number

	@Column("date", { name: "fecha_lim_pago", nullable: true })
	public readonly limitPaymentDate!: Date

	@Column("character varying", {
		name: "cod_cajero",
		length: 10,
		nullable: false,
	})
	public readonly tellerCode!: string

	@Column("smallint", { name: "concepto", nullable: true })
	public readonly conceptId!: number

	@Column("integer", { name: "num_operacion", nullable: true })
	public readonly operationNumber!: number

	@Column("bigint", { name: "cod_hash", nullable: true })
	public readonly hashCode!: number

	@Column("integer", { name: "secuencia", nullable: true })
	public readonly sequence!: number

	@Column("smallint", { name: "cod_comp_cheque", nullable: true })
	public readonly chequeCodComp!: number

	@Column("smallint", { name: "cod_ent_fin_deb", nullable: true })
	public readonly debFinEntCod!: number

	@Column("bigint", { name: "num_cheque", nullable: true })
	public readonly chequeNum!: number

	@Column("integer", { name: "num_autorizacion", nullable: true })
	public readonly authorizationNumber!: number

	@Column("smallint", { name: "causal_devolucion", nullable: true })
	public readonly returnReason!: number

	@Column("numeric", {
		name: "valor_recaudado",
		nullable: true,
		precision: 19,
		scale: 2,
	})
	public readonly collectedValue!: number

	@Column("smallint", { name: "procedencia_pago", nullable: true })
	public readonly paymentOrigin!: number

	@Column("smallint", { name: "medio_pago", nullable: true })
	public readonly paymentMethod!: number

	@Column("numeric", {
		name: "valor_recaudado_canje",
		nullable: true,
		precision: 19,
		scale: 2,
	})
	public readonly exchangePaymentValue!: number

	@Column("smallint", { name: "tipo_recaudo", nullable: true })
	public readonly paymentType!: number

	@Column("numeric", {
		name: "valor_pesos_saldo",
		nullable: true,
		precision: 19,
		scale: 2,
	})
	public readonly pesosValueBalance!: number

	@Column("bigint", { name: "numero_tarjeta_credito", nullable: true })
	public readonly creditCardNumber!: number

	@Column("smallint", { name: "administracion_dian", nullable: true })
	public readonly dianAdmin!: number

	@Column("integer", { name: "talon", nullable: true })
	public readonly talon!: number

	@Column("bigint", { name: "acta_ofic_rdmov", nullable: true })
	public readonly oficActRdmov!: number

	@Column("bigint", { name: "aceptacion_rdmov", nullable: true })
	public readonly acceptanceRdmov!: number

	@Column("integer", { name: "cant_decl_rdmov", nullable: true })
	public readonly declQtyRdmov!: number

	@Column("bigint", { name: "adhesivo_rdmove", nullable: true })
	public readonly adhesiveRdmove!: number

	@Column("date", { name: "fecha_acep_rdmove", nullable: true })
	public readonly acceptanceDateRdmove!: Date

	@Column("smallint", { name: "apl_pago_rdmov", nullable: true })
	public readonly paymentAplRdmov!: number

	@Column("bigint", { name: "vlr_cas1_rdmov", nullable: true })
	public readonly cas1ValueRdmov!: number

	@Column("bigint", { name: "vlr_cas2_rdmov", nullable: true })
	public readonly cas2ValueRdmov!: number

	@Column("bigint", { name: "vlr_cas3_rdmov", nullable: true })
	public readonly cas3ValueRdmov!: number

	@Column("bigint", { name: "vlr_cas4_rdmov", nullable: true })
	public readonly cas4ValueRdmov!: number

	@Column("bigint", { name: "vlr_cas5_rdmov", nullable: true })
	public readonly cas5ValueRdmov!: number

	@Column("bigint", { name: "vlr_cas6_rdmov", nullable: true })
	public readonly cas6ValueRdmov!: number

	@Column("smallint", { name: "periodo", nullable: true })
	public readonly period!: number

	@Column("integer", { name: "anio_gravable", nullable: true })
	public readonly taxableYear!: number

	@Column("bigint", { name: "numero_cuenta", nullable: true })
	public readonly accountNumber!: number

	@Column("character varying", { name: "tipo_aso", nullable: true, length: 2 })
	public readonly asoType!: string

	@Column({
		name: "excluir",
		type: "boolean",
		nullable: false,
	})
	public readonly exclude!: boolean

	@ManyToOne(() => DianTax, (dianTax: DianTax) => dianTax.dianMovements)
	@JoinColumn([{ name: "codigo_impuesto", referencedColumnName: "taxId" }])
	public dianTax: DianTax

	@OneToMany(
		() => DianIssues,
		(dianIssues: DianIssues) => dianIssues.movementId
	)
	public dianIssues?: DianIssues[]

	@ManyToOne(
		() => DianDomain,
		(dianDomainDayType: DianDomain) => dianDomainDayType.dianMovementsDayType
	)
	@JoinColumn([{ name: "dominio_ind_jornada", referencedColumnName: "id" }])
	public dianDomainDayType: DianDomain

	@ManyToOne(
		() => DianDomain,
		(dianDomainFormType: DianDomain) => dianDomainFormType.dianDomainFormType
	)
	@JoinColumn([{ name: "dominio_tipo_formulario", referencedColumnName: "id" }])
	public dianDomainFormType: DianDomain
}
