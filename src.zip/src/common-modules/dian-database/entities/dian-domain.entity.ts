/** @format */

// ** info: typeorm imports
import { OneToMany } from "typeorm"
import { Column } from "typeorm"
import { Entity } from "typeorm"
import { Index } from "typeorm"

// ** info: other entities imports
import { DianMovements } from "@common-modules/dian-database/entities/dian-movements.entity"
import { DianIssues } from "@common-modules/dian-database/entities/dian-issues.entity"

@Index("dian_dominio_pkey", ["id"], { unique: true })
@Index("dian_dominio_valor_dominio_key", ["type", "realValue"], {
	unique: true,
})
@Entity("dian_dominio", { schema: "sc_estadistico_dian" })
export class DianDomain {
	@Column("integer", {
		primary: true,
		name: "codigo_dominio",
		nullable: false,
	})
	public readonly id!: number

	@Column("character varying", {
		name: "dominio",
		length: 50,
		nullable: false,
	})
	public readonly type!: string

	@Column("character varying", {
		name: "valor",
		length: 100,
		nullable: false,
	})
	public readonly realValue!: string

	@Column("character varying", {
		name: "descripcion",
		length: 200,
		nullable: false,
	})
	public readonly description!: string

	@Column("boolean", { name: "estado", nullable: false })
	public readonly state!: boolean

	@OneToMany(
		() => DianIssues,
		(dianIssues: DianIssues) => dianIssues.dianDomainIssueType
	)
	public readonly dianIssuesIssueType!: DianIssues[]

	@OneToMany(
		() => DianMovements,
		(dianMovement: DianMovements) => dianMovement.dianDomainDayType
	)
	public readonly dianMovementsDayType!: DianMovements[]

	@OneToMany(
		() => DianMovements,
		(dianMovement: DianMovements) => dianMovement.dianDomainFormType
	)
	public readonly dianDomainFormType!: DianMovements[]
}
