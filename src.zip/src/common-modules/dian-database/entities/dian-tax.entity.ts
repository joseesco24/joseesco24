/** @format */

// ** info: typeorm imports
import { Column } from "typeorm"
import { Entity } from "typeorm"
import { Index, OneToMany } from "typeorm"
import { DianMovements } from "./dian-movements.entity"

@Index("dian_impuestos_pkey", ["taxId"], { unique: true })
@Index(
	"dian_impuestos_dominio_modalidad_dian_nombre_impuesto_conce_key",
	["conceptId", "dianModeDomain", "formId", "taxName"],
	{ unique: true }
)
@Entity("dian_impuestos", { schema: "sc_estadistico_dian" })
export class DianTax {
	@Column("smallint", { name: "motivo", nullable: false })
	public readonly formId!: number

	@Column("smallint", { name: "concepto", nullable: true })
	public readonly conceptId!: number

	@Column("smallint", { name: "dominio_modalidad_dian", nullable: false })
	public readonly dianModeDomain!: number

	@Column("character varying", {
		name: "nombre_impuesto",
		length: 50,
		nullable: false,
	})
	public readonly taxName!: string

	@Column("integer", {
		primary: true,
		name: "codigo_impuesto",
		nullable: false,
	})
	public readonly taxId!: number

	@Column("character varying", {
		name: "ip_modificacion",
		length: 15,
		nullable: false,
	})
	public readonly modificationIp!: string

	@Column("character varying", {
		name: "ip_creacion",
		length: 15,
		nullable: false,
	})
	public readonly creationIp!: string

	@Column("character varying", {
		name: "usuario_modificacion",
		length: 60,
		nullable: false,
	})
	public readonly modificationUser!: string

	@Column("character varying", {
		name: "usuario_creacion",
		length: 60,
		nullable: false,
	})
	public readonly creationUser!: string

	@Column("boolean", { name: "vigencia", nullable: false })
	public readonly status!: boolean

	@Column("timestamp without time zone", {
		name: "fecha_modificacion",
		nullable: false,
	})
	public readonly modificationDate!: Date

	@Column("timestamp without time zone", {
		name: "fecha_creacion",
		nullable: false,
	})
	public readonly creationDate!: Date

	@OneToMany(
		() => DianMovements,
		(dianMovement: DianMovements) => dianMovement.dianTax
	)
	public readonly dianMovements!: DianMovements[]
}
