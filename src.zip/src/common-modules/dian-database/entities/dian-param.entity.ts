/** @format */

import { Column, Entity, Index, PrimaryColumn } from "typeorm"

@Index("dian_parametrizacion_pkey", ["parameterCode"], { unique: true })
@Entity("dian_parametrizacion", { schema: "sc_estadistico_dian" })
export class DianParam {
	@PrimaryColumn("character varying", {
		name: "codigo_parametro",
		length: 70,
		nullable: false,
	})
	public readonly parameterCode!: string

	@Column("character varying", {
		name: "valor",
		length: 100,
		nullable: false,
	})
	public readonly value!: string

	@Column("character varying", {
		name: "descripcion",
		length: 200,
		nullable: false,
	})
	public readonly description!: string

	@Column("boolean", { name: "estado", nullable: false })
	public readonly state!: boolean
}
