/** @format */

// ** info: type orm imports
import { Column } from "typeorm"
import { Entity } from "typeorm"
import { Index } from "typeorm"

@Index("dian_entidades_recaudadoras_pkey", ["earId"], { unique: true })
@Entity("dian_entidades_recaudadoras", { schema: "sc_estadistico_dian" })
export class DianOffice {
	@Column("integer", { name: "codigo_cargue", nullable: false })
	public readonly loadId!: number

	@Column("integer", { name: "dominio_tipo_ear", nullable: false })
	public readonly earDomainType!: number

	@Column("integer", { primary: true, name: "codigo_ear_real" })
	public readonly earId!: number

	@Column("integer", { name: "codigo_ear_dian", nullable: false })
	public readonly earDianId!: number

	@Column("character varying", {
		name: "nombre_ear",
		nullable: false,
		length: 100,
	})
	public readonly name!: string

	@Column("character varying", { name: "ciudad", length: 60, nullable: false })
	public readonly city!: string

	@Column("timestamp without time zone", {
		name: "fecha_creacion",
		nullable: false,
	})
	public readonly creationDate!: Date
}
