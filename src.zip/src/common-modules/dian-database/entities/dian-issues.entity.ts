/** @format */

import { Column, Entity, Index, JoinColumn, ManyToOne } from "typeorm"
import { DianDomain } from "./dian-domain.entity"
import { DianMovements } from "./dian-movements.entity"

@Index("dian_inconsistencias_pkey", ["issueId"], { unique: true })
@Entity("dian_inconsistencias", { schema: "sc_estadistico_dian" })
export class DianIssues {
	@Column("integer", { primary: true, name: "codigo_inconsistencia" })
	public readonly issueId!: number

	@Column({
		name: "codigo_movimiento",
		type: "integer",
		nullable: false,
	})
	public readonly movementId!: number

	@ManyToOne(
		() => DianMovements,
		(dianMovements: DianMovements) => dianMovements.dianIssues
	)
	@JoinColumn([
		{ name: "codigo_movimiento", referencedColumnName: "movementId" },
	])
	public dianMovements: DianMovements

	@Column("integer", { name: "dominio_tipo_inconsistencia", nullable: true })
	public readonly issueTypeDomain: number

	@Column("bigint", { name: "numero_formulario", nullable: false })
	public readonly declarationNumber!: string

	@Column("character varying", {
		name: "detalle_inconsistencia",
		length: 100,
		nullable: false,
	})
	public readonly justification!: string

	@Column("numeric", {
		name: "valor_pesos",
		precision: 19,
		scale: 2,
		nullable: false,
	})
	public readonly paymentValuePesos!: number

	@Column("bigint", { name: "nit_o_cedula", nullable: false })
	public readonly nitOrId!: number

	@Column("character varying", {
		name: "usuario_creacion_inconsistencia",
		length: 60,
		nullable: false,
	})
	public readonly creationUser!: string

	@Column("character varying", {
		name: "ip_creacion_inconsistencia",
		length: 15,
		nullable: false,
	})
	public readonly creationIp!: string

	@Column("timestamp without time zone", {
		name: "fecha_creacion_inconsistencia",
		nullable: false,
	})
	public readonly creationDate!: Date

	@ManyToOne(
		() => DianDomain,
		(dianDomainIssueType: DianDomain) => dianDomainIssueType.dianIssuesIssueType
	)
	@JoinColumn([
		{ name: "dominio_tipo_inconsistencia", referencedColumnName: "id" },
	])
	public dianDomainIssueType: DianDomain
}
