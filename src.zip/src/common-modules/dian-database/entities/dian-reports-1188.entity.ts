/** @format */

import { Column, Entity, Index, PrimaryGeneratedColumn } from "typeorm"

@Index("dian_reportes_1188_pkey", ["reportId1188"], {
	unique: true,
})
@Entity("dian_reportes_1188", { schema: "sc_estadistico_dian" })
export class DianReport1188 {
	@PrimaryGeneratedColumn({
		type: "integer",
		name: "codigo_generacion_reporte_1188",
	})
	public readonly reportId1188!: number

	@Column("integer", { name: "dominio_tipo_emision_reporte", nullable: false })
	public readonly emissionTypeDomain!: number

	@Column("smallint", { name: "consecutivo_reporte_xml", nullable: false })
	public readonly consecutive!: number

	@Column("smallint", { name: "dias_reciprocidad", nullable: false })
	public readonly reciprocityDays!: number

	@Column("date", { name: "anio_reporte_xml", nullable: false })
	public readonly reportYear!: Date

	@Column("date", { name: "mes_reporte_xml", nullable: false })
	public readonly reportMonth!: Date

	@Column("character varying", {
		name: "nombre_reporte_xml",
		length: 80,
		nullable: false,
	})
	public readonly reportName!: string

	@Column("character varying", {
		name: "path_reporte",
		length: 200,
		nullable: false,
	})
	public readonly reportPath!: string

	@Column("numeric", {
		name: "intereses_consignados",
		precision: 19,
		scale: 2,
		nullable: false,
	})
	public readonly consignedInterests!: number

	@Column("numeric", {
		name: "sanciones_consignados",
		precision: 19,
		scale: 2,
		nullable: false,
	})
	public readonly consignedSanctions!: number

	@Column("numeric", {
		name: "intereses_por_consignados",
		precision: 19,
		scale: 2,
		nullable: false,
	})
	public readonly notConsignedInterests!: number

	@Column("numeric", {
		name: "sanciones_por_consignados",
		precision: 19,
		scale: 2,
		nullable: false,
	})
	public readonly notConsignedSanctions!: number

	@Column("numeric", {
		name: "saldo_por_consignar",
		precision: 19,
		scale: 2,
		nullable: false,
	})
	public readonly notConsignedPayment!: number

	@Column("character varying", {
		name: "usuario_creacion",
		length: 60,
		nullable: false,
	})
	public readonly creationUser!: string

	@Column("character varying", {
		name: "ip_creacion",
		length: 15,
		nullable: false,
	})
	public readonly creationIp!: string

	@Column({
		name: "fecha_sistema",
		type: "date",
		nullable: false,
	})
	public readonly systemDate!: string

	@Column({
		name: "novedad",
		type: "boolean",
		nullable: true,
	})
	public readonly news!: boolean

	@Column("timestamp without time zone", {
		name: "fecha_creacion",
		nullable: false,
	})
	public readonly creationDate!: Date
}
