/** @format */

import {
	Column,
	Entity,
	Index,
	OneToMany,
	PrimaryGeneratedColumn,
} from "typeorm"

import { DianOffice } from "@common-modules/dian-database/entities/dian-office.entity"
import { DianLoadError } from "@common-modules/dian-database/entities/dian-load-errors.entity"

@Index("dian_cargue_batch_pkey", ["codigoCargue"], { unique: true })
@Entity("dian_cargue_batch", { schema: "sc_estadistico_dian" })
export class DianBatchLoad {
	@PrimaryGeneratedColumn({ type: "integer", name: "codigo_cargue" })
	public codigoCargue: number

	@Column("character varying", { name: "nombre_archivo_cargado", length: 40 })
	public nombreArchivoCargado: string

	@Column("timestamp without time zone", { name: "tiempo_carga" })
	public tiempoCarga: Date

	@Column("integer", { name: "cantidad_registros", nullable: true })
	public cantidadRegistros: number | null

	@Column("integer", { name: "cantidad_registros_exitosos", nullable: true })
	public cantidadRegistrosExitosos: number | null

	@Column("integer", { name: "cantidad_registros_fallidos", nullable: true })
	public cantidadRegistrosFallidos: number | null

	@OneToMany(() => DianOffice, (dianOffice: DianOffice) => dianOffice.loadId)
	public dianOffice: DianOffice[]

	@OneToMany(
		() => DianLoadError,
		(dianLoadError: DianLoadError) => dianLoadError.codigoCargue
	)
	public dianLoadError: DianLoadError[]
}
