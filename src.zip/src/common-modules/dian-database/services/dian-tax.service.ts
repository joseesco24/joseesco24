/** @format */

import { databaseErrorMessage } from "@common-artifacts/constants/constants"
import { CreateRequestDto } from "@core-modules/taxes/dtos/module/create-request.dto"
import { UpdateRequestDto } from "@core-modules/taxes/dtos/module/update-request.dto"
import { TaxesTableRequestDto } from "@core-modules/taxes/dtos/module/taxes-table-request.dto"
import {
	BadRequestException,
	Injectable,
	ServiceUnavailableException,
} from "@nestjs/common"
import { InjectRepository } from "@nestjs/typeorm"
import { DataSource, QueryRunner } from "typeorm"
import { DianTax } from "@common-modules/dian-database/entities/dian-tax.entity"
import { FoundTaxNames } from "../dtos/foundTaxNames.dto"
import { TaxesDataCount } from "../dtos/taxesDataCount.dto"
import { DianDomainService } from "./dian-domain.service"
import { FindTaxByIdResponseDto } from "@core-modules/taxes/dtos/module/find-tax-by-id-response.dto"

// ** info: type orm imports
import { SelectQueryBuilder } from "typeorm"
import { Repository } from "typeorm"

@Injectable()
export class DianTaxService {
	private readonly tableAlias: string = "dian_impuestos"

	public constructor(
		@InjectRepository(DianTax)
		private readonly dianTaxRepository: Repository<DianTax>,
		private readonly dianDomainService: DianDomainService,
		private readonly dataSource: DataSource
	) {}

	public async getTaxNamesByIds(taxIds: number[]): Promise<any> {
		try {
			return await this.dianTaxRepository
				.createQueryBuilder(`${this.tableAlias}`)
				.select([`${this.tableAlias}.taxName AS "taxName"`])
				.addSelect([`${this.tableAlias}.taxId AS "taxId"`])
				.where(`${this.tableAlias}.taxId IN (:...ids)`, {
					ids: taxIds,
				})
				.getRawMany()
		} catch (e) {
			try {
				const errorMessage: string =
					await this.dianDomainService.getRealValueByDomainId(
						databaseErrorMessage
					)
				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (e: any) {
				throw new ServiceUnavailableException(e.message)
			}
		}
	}

	public async getAllTaxNames(): Promise<FoundTaxNames[]> {
		try {
			return await this.dianTaxRepository
				.createQueryBuilder(`${this.tableAlias}`)
				.select([`${this.tableAlias}.taxName AS "taxName"`])
				.where(`${this.tableAlias}.parentTax  IS NULL`)
				.andWhere(`${this.tableAlias}.status = :status`, {
					status: true,
				})
				.getRawMany()
		} catch (e) {
			try {
				const errorMessage: string =
					await this.dianDomainService.getRealValueByDomainId(
						databaseErrorMessage
					)
				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (e: any) {
				throw new ServiceUnavailableException(e.message)
			}
		}
	}

	public async allActiveTaxNames(): Promise<DianTax[]> {
		const sqlQuery: SelectQueryBuilder<DianTax> = this.dianTaxRepository
			.createQueryBuilder(`${this.tableAlias}`)
			.select([`${this.tableAlias}.taxName AS "taxName"`])
			.where(`${this.tableAlias}.status = :status`, {
				status: true,
			})
			.groupBy(`${this.tableAlias}.taxName`)

		const dianTaxes: DianTax[] = await sqlQuery.getRawMany()

		return dianTaxes
	}

	public async allTaxNames(): Promise<DianTax[]> {
		const sqlQuery: SelectQueryBuilder<DianTax> = this.dianTaxRepository
			.createQueryBuilder(`${this.tableAlias}`)
			.select([`${this.tableAlias}.taxName AS "taxName"`])
			.groupBy(`${this.tableAlias}.taxName`)

		const dianTaxes: DianTax[] = await sqlQuery.getRawMany()

		return dianTaxes
	}

	public async filterTaxes(
		taxesTableRequest: TaxesTableRequestDto,
		searchBool: boolean[]
	): Promise<TaxesDataCount> {
		try {
			const taxesFoundQuery: SelectQueryBuilder<DianTax> =
				this.dianTaxRepository
					.createQueryBuilder(`${this.tableAlias}`)
					.where(`${this.tableAlias}.status IN (:...status)`, {
						status: searchBool,
					})

			if (
				taxesTableRequest.taxName !== undefined &&
				taxesTableRequest.taxName !== ""
			) {
				taxesFoundQuery.andWhere(
					`lower(unaccent(${this.tableAlias}.taxName)) like lower(unaccent(:taxName))`,
					{ taxName: `%${taxesTableRequest.taxName}%` }
				)
			}
			if (
				taxesTableRequest.modificationUser !== undefined &&
				taxesTableRequest.modificationUser !== ""
			) {
				taxesFoundQuery.andWhere(
					`lower(unaccent(${this.tableAlias}.modificationUser)) like lower(unaccent(:modUser))`,
					{ modUser: `%${taxesTableRequest.modificationUser}%` }
				)
			}
			if (
				taxesTableRequest.formId !== undefined &&
				taxesTableRequest.formId !== ""
			) {
				taxesFoundQuery.andWhere(`${this.tableAlias}.formId =:formId`, {
					formId: parseInt(taxesTableRequest.formId) || 0,
				})
			}
			if (
				taxesTableRequest.conceptId !== undefined &&
				taxesTableRequest.conceptId !== ""
			) {
				taxesFoundQuery.andWhere(`${this.tableAlias}.conceptId =:conceptId`, {
					conceptId: parseInt(taxesTableRequest.conceptId) || 0,
				})
			}
			taxesFoundQuery
				.select([`${this.tableAlias}.taxName AS "taxName"`])
				.addSelect([`${this.tableAlias}.formId AS "formId"`])
				.addSelect([`${this.tableAlias}.conceptId AS "conceptId"`])
				.addSelect([`${this.tableAlias}.dianModeDomain AS "dianMode"`])
				.addSelect([`${this.tableAlias}.status AS "status"`])
				.addSelect([
					`${this.tableAlias}.modificationUser AS "modificationUser"`,
				])
				.addSelect([
					`${this.tableAlias}.modificationDate AS "lastModificationDate"`,
				])
				.addSelect([`${this.tableAlias}.taxId AS "taxId"`])
				.orderBy(`${this.tableAlias}.modificationDate`, "DESC")
			const [data, count]: [any[], number] = await Promise.all([
				taxesFoundQuery
					.limit(taxesTableRequest.limit)
					.offset(taxesTableRequest.offset)
					.getRawMany(),
				taxesFoundQuery.getCount(),
			])
			return {
				count,
				data,
			}
		} catch (e) {
			try {
				const errorMessage: string =
					await this.dianDomainService.getRealValueByDomainId(
						databaseErrorMessage
					)
				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (e: any) {
				throw new ServiceUnavailableException(e.message)
			}
		}
	}
	/**
	 *
	 *
	 * @param {number} taxIdParam
	 * @return {*}  {Promise<TaxByIdResponseDto>}
	 * @memberof DianTaxService
	 */
	public async getTaxById(taxIdParam: number): Promise<FindTaxByIdResponseDto> {
		try {
			return await this.dianTaxRepository
				.createQueryBuilder(`${this.tableAlias}`)
				.select([`${this.tableAlias}.taxName AS "taxName"`])
				.addSelect([`${this.tableAlias}.formId AS "formId"`])
				.addSelect([`${this.tableAlias}.conceptId AS "conceptId"`])
				.addSelect([`${this.tableAlias}.status AS "status"`])
				.addSelect([`${this.tableAlias}.dianModeDomain AS "dianMode"`])
				.andWhere(`${this.tableAlias}.taxId = :taxId`, {
					taxId: taxIdParam,
				})
				.getRawOne()
		} catch (e: any) {
			try {
				const errorMessage: string =
					await this.dianDomainService.getRealValueByDomainId(
						databaseErrorMessage
					)
				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (e: any) {
				throw new ServiceUnavailableException(e.message)
			}
		}
	}
	/**
	 *
	 *
	 * @param {string} taxName
	 * @param {number} formId
	 * @param {number} conceptId
	 * @param {number} dianMode
	 * @return {*}  {Promise<TaxByIdResponseDto>}
	 * @memberof DianTaxService
	 */
	public async getduplicateContraint(
		taxName: string,
		formId: number,
		conceptId: number,
		dianMode: number
	): Promise<FindTaxByIdResponseDto> {
		try {
			return await this.dianTaxRepository
				.createQueryBuilder(`${this.tableAlias}`)
				.select([`${this.tableAlias}.taxId`])
				.where(`${this.tableAlias}.formId = :formId`, {
					formId: formId,
				})
				.andWhere(`${this.tableAlias}.conceptId = :conceptId`, {
					conceptId: conceptId,
				})
				.andWhere(`${this.tableAlias}.dianModeDomain = :dianModeDomain`, {
					dianModeDomain: dianMode,
				})
				.andWhere(`${this.tableAlias}.taxName = :taxName`, {
					taxName: taxName,
				})
				.getRawOne()
		} catch (e: any) {
			try {
				const errorMessage: string =
					await this.dianDomainService.getRealValueByDomainId(
						databaseErrorMessage
					)
				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (e: any) {
				throw new ServiceUnavailableException(e.message)
			}
		}
	}
	public async getTaxIdByIndexes(
		formId: number,
		conceptId: number,
		dianMode: number
	): Promise<any> {
		try {
			return await this.dianTaxRepository
				.createQueryBuilder(`${this.tableAlias}`)
				.select([`${this.tableAlias}.taxId`])
				.where(`${this.tableAlias}.formId = :formId`, {
					formId: formId,
				})
				.andWhere(`${this.tableAlias}.conceptId = :conceptId`, {
					conceptId: conceptId,
				})
				.andWhere(`${this.tableAlias}.dianModeDomain = :dianModeDomain`, {
					dianModeDomain: dianMode,
				})
				.getRawOne()
		} catch (e: any) {
			try {
				const errorMessage: string =
					await this.dianDomainService.getRealValueByDomainId(
						databaseErrorMessage
					)
				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (e: any) {
				throw new ServiceUnavailableException(e.message)
			}
		}
	}

	public async addTax(
		addTaxRequest: CreateRequestDto,
		ip: string,
		realStatus: boolean
	): Promise<DianTax> {
		const queryRunner: QueryRunner = this.dataSource.createQueryRunner()
		await queryRunner.connect()
		await queryRunner.startTransaction()

		const date: Date = new Date()

		const lastId: any = await this.getOneMaximumTaxCode()

		try {
			const tax: object = queryRunner.manager.create(DianTax, {
				taxId: lastId,
				conceptId: addTaxRequest.conceptId,
				dianModeDomain: addTaxRequest.dianMode,
				formId: addTaxRequest.formId,
				modificationDate: date,
				creationDate: date,
				modificationUser: addTaxRequest.generationUser,
				creationUser: addTaxRequest.generationUser,
				modificationIp: ip,
				creationIp: ip,
				status: realStatus,
				taxName: addTaxRequest.taxName,
			})
			await Promise.all([queryRunner.manager.save(tax)])
			await queryRunner.commitTransaction()
			// ! warning: doubtful type assertion
			return tax as DianTax
		} catch (err: any) {
			await queryRunner.rollbackTransaction()
			throw new BadRequestException("Código de Impuesto ya asignado")
		} finally {
			await queryRunner.release()
		}
	}

	public async modifyTax(
		modifyTaxRequest: UpdateRequestDto,
		ip: string,
		realStatus: boolean
	): Promise<any> {
		const queryRunner: QueryRunner = this.dataSource.createQueryRunner()
		await queryRunner.connect()
		await queryRunner.startTransaction()

		const date: Date = new Date()
		try {
			const modifyTax: object = {
				conceptId: modifyTaxRequest.conceptId,
				dianModeDomain: modifyTaxRequest.dianMode,
				formId: modifyTaxRequest.formId,
				modificationDate: date,
				modificationUser: modifyTaxRequest.generationUser,
				modificationIp: ip,
				status: realStatus,
				taxName: modifyTaxRequest.taxName,
			}

			await Promise.all([
				await queryRunner.manager
					.createQueryBuilder()
					.update(DianTax)
					.set(modifyTax)
					.where(`dian_impuestos.codigo_impuesto = :id`, {
						id: modifyTaxRequest.taxId,
					})
					.execute(),
			])
			await queryRunner.commitTransaction()

			return modifyTax
		} catch (err: any) {
			await queryRunner.rollbackTransaction()
			throw new BadRequestException("Código de Impuesto ya asignado")
		} finally {
			await queryRunner.release()
		}
	}

	private async getOneMaximumTaxCode(): Promise<number> {
		const query: SelectQueryBuilder<DianTax> =
			this.dianTaxRepository.createQueryBuilder(`${this.tableAlias}`)
		query.select(`MAX(${this.tableAlias}.taxId)`, "max")
		const result: any = await query.getRawOne()
		return result.max
	}

	public async replaceTxCodesByTaxName(params: {
		objectsList: object[]
		domainKey: string
	}): Promise<void> {
		const domainsCache: object = {}
		for (const obj of params.objectsList) {
			const domainId: number = obj[params.domainKey] as number
			if (obj !== undefined) {
				if (domainId in domainsCache) {
					obj[params.domainKey] = domainsCache[domainId]
				} else if (!(domainId in domainsCache)) {
					const domainRealValue: string = (await this.getTaxById(domainId))
						.taxName
					domainsCache[domainId] = domainRealValue
					obj[params.domainKey] = domainRealValue
				}
			} else if (obj === undefined) {
				domainsCache[domainId] = undefined
				obj[params.domainKey] = undefined
			}
		}
	}
}
