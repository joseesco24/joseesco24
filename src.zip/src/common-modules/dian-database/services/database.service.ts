/** @format */

// ** info: nest config imports
import { ConfigModule, ConfigService } from "@nestjs/config"

// ** info: nest commons imports
import { DynamicModule } from "@nestjs/common"

// ** info: nest type orm imports
import { TypeOrmModule } from "@nestjs/typeorm"

// ** info: type orm imports
import { DataSourceOptions } from "typeorm"

// ** info: common artifacts imports
import DatabaseLogger from "@common-artifacts/middleware/databaseLogger"

// ** info: common entities imports
import { DianReport1188 } from "@common-modules/dian-database/entities/dian-reports-1188.entity"
import { DianReport1740 } from "@common-modules/dian-database/entities/dian-reports-1740.entity"
import { DianLoadError } from "@common-modules/dian-database/entities/dian-load-errors.entity"
import { DianBatchLoad } from "@common-modules/dian-database/entities/dian-batch-load.entity"
import { DianMovements } from "@common-modules/dian-database/entities/dian-movements.entity"
import { DianIssues } from "@common-modules/dian-database/entities/dian-issues.entity"
import { DianDomain } from "@common-modules/dian-database/entities/dian-domain.entity"
import { DianOffice } from "@common-modules/dian-database/entities/dian-office.entity"
import { DianParam } from "@common-modules/dian-database/entities/dian-param.entity"
import { DianTax } from "@common-modules/dian-database/entities/dian-tax.entity"

export const dataBaseProviders: DynamicModule[] = [
	TypeOrmModule.forRootAsync({
		imports: [ConfigModule],
		inject: [ConfigService],
		useFactory(configService: ConfigService) {
			return {
				type: "postgres",
				host: configService.get("POSTGRES_HOST"),
				port: configService.get("POSTGRES_PORT"),
				database: configService.get("POSTGRES_DATABASE"),
				schema: configService.get("POSTGRES_SCHEMA"),
				username: configService.get("POSTGRES_USER"),
				password: configService.get("POSTGRES_PASSWORD"),
				logger: new DatabaseLogger(),
				synchronize: false,
				retryAttempts: 10,
				retryDelay: 3000,
				extra: { max: 10 },
				entities: [
					DianReport1188,
					DianReport1740,
					DianMovements,
					DianBatchLoad,
					DianLoadError,
					DianDomain,
					DianOffice,
					DianIssues,
					DianParam,
					DianTax,
				],
			} as DataSourceOptions
		},
	}),
]
