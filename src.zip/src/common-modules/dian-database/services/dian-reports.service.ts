/** @format */

// ** info: nest commons imports
import { Injectable } from "@nestjs/common"
import { Logger } from "@nestjs/common"

// ** info: nest type orm imports
import { InjectRepository } from "@nestjs/typeorm"

// ** info: type orm imports
import { SelectQueryBuilder } from "typeorm"
import { Repository } from "typeorm"

// ** info: entites repositorioes imports
import { DianReport1188 } from "@common-modules/dian-database/entities/dian-reports-1188.entity"
import { DianReport1740 } from "@common-modules/dian-database/entities/dian-reports-1740.entity"
import { DianMovements } from "@common-modules/dian-database/entities/dian-movements.entity"

// ** info: entites interfaces imports
import { DianReports1188TableDataInterface } from "@common-modules/dian-database/interfaces/dian-reports-1188-table-data.interface"
import { DianReports1740TableDataInterface } from "@common-modules/dian-database/interfaces/dian-reports-1740-table-data.interface"

@Injectable()
export class DianReportsService {
	private readonly logger: Logger = new Logger(DianReportsService.name)

	private readonly report1188TableAlias: string = "dian1188ReportTable"
	private readonly report1740TableAlias: string = "dian1740ReportTable"
	private readonly movementsTableAlias: string = "dianMovementsTable"

	public constructor(
		@InjectRepository(DianReport1188)
		private readonly dianReport1188Repository: Repository<DianReport1188>,
		@InjectRepository(DianReport1740)
		private readonly dianReport1740Repository: Repository<DianReport1740>,
		@InjectRepository(DianMovements)
		private readonly dianMovementsRepository: Repository<DianMovements>
	) {}

	public async getReport1188PathNameById(params: {
		reportId: number
	}): Promise<[string, string]> {
		const query: SelectQueryBuilder<DianReport1188> =
			this.dianReport1188Repository
				.createQueryBuilder(`${this.report1188TableAlias}`)
				.select([
					`${this.report1188TableAlias}.reportPath`,
					`${this.report1188TableAlias}.reportName`,
				])
				.where(`${this.report1188TableAlias}.reportId1188 >= :reportId1188`, {
					reportId1188: params.reportId,
				})

		const fetchMovement: DianReport1188 = await query.getOneOrFail()

		return [fetchMovement.reportPath, fetchMovement.reportName]
	}

	public async validate1188(params: {
		endDate: Date
		initDate: Date
		consecutive: number
		reciprocityDays: number
		consignedInterests: number
		consignedSanctions: number
		notConsignedInterests: number
		notConsignedSanctions: number
	}): Promise<boolean> {
		const query: SelectQueryBuilder<DianReport1188> =
			this.dianReport1188Repository
				.createQueryBuilder(`${this.report1188TableAlias}`)
				.select([`${this.report1188TableAlias}.reportName`])
				.where(`${this.report1188TableAlias}.systemDate >= :startDate`, {
					startDate: params.initDate.toISOString(),
				})
				.andWhere(`${this.report1188TableAlias}.systemDate <= :endDate`, {
					endDate: params.endDate.toISOString(),
				})
				.andWhere(
					`${this.report1188TableAlias}.reciprocityDays = :reciprocityDays`,
					{
						reciprocityDays: params.reciprocityDays,
					}
				)
				.andWhere(
					`${this.report1188TableAlias}.consignedInterests = :consignedInterests`,
					{
						consignedInterests: params.consignedInterests,
					}
				)
				.andWhere(
					`${this.report1188TableAlias}.consignedSanctions = :consignedSanctions`,
					{
						consignedSanctions: params.consignedSanctions,
					}
				)
				.andWhere(
					`${this.report1188TableAlias}.notConsignedInterests = :notConsignedInterests`,
					{
						notConsignedInterests: params.notConsignedInterests,
					}
				)
				.andWhere(
					`${this.report1188TableAlias}.notConsignedSanctions = :notConsignedSanctions`,
					{
						notConsignedSanctions: params.notConsignedSanctions,
					}
				)

		const resultsCount: number = await query.getCount()

		if (resultsCount >= 1) {
			return true
		}

		return false
	}

	public async getReport1188MetadataById(params: {
		reportId: number
	}): Promise<DianReport1188> {
		const query: SelectQueryBuilder<DianReport1188> =
			this.dianReport1188Repository
				.createQueryBuilder(`${this.report1188TableAlias}`)
				.select(["*"])
				.where(`${this.report1188TableAlias}.reportId1188 >= :reportId1188`, {
					reportId1188: params.reportId,
				})

		const fetchMovement: DianReport1188 = await query.getOneOrFail()

		return fetchMovement
	}

	public async getReport1740PathNameById(params: {
		reportId: number
	}): Promise<[string, string]> {
		const query: SelectQueryBuilder<DianReport1740> =
			this.dianReport1740Repository
				.createQueryBuilder(`${this.report1188TableAlias}`)
				.select([
					`${this.report1188TableAlias}.reportPath`,
					`${this.report1188TableAlias}.reportName`,
				])
				.where(`${this.report1188TableAlias}.reportId1740 >= :reportId1740`, {
					reportId1740: params.reportId,
				})

		const fetchMovement: DianReport1740 = await query.getOneOrFail()

		return [fetchMovement.reportPath, fetchMovement.reportName]
	}

	public async getReport1740MetadataById(params: {
		reportId: number
	}): Promise<DianReport1740> {
		const query: SelectQueryBuilder<DianReport1740> =
			this.dianReport1740Repository
				.createQueryBuilder(`${this.report1188TableAlias}`)
				.select(["*"])
				.where(`${this.report1188TableAlias}.reportId1740 >= :reportId1740`, {
					reportId1740: params.reportId,
				})

		const fetchMovement: DianReport1740 = await query.getOneOrFail()

		return fetchMovement
	}

	public async reportsHistoricalTable1188(params: {
		consecutive: number | undefined
		startDate: Date | undefined
		endDate: Date | undefined
		offset: number
		limit: number
	}): Promise<[DianReports1188TableDataInterface[], number]> {
		const reportsHistoricalTable1188Registers: DianReports1188TableDataInterface[] =
			[] as DianReports1188TableDataInterface[]

		const query: SelectQueryBuilder<DianReport1188> =
			this.dianReport1188Repository
				.createQueryBuilder(`${this.report1188TableAlias}`)
				.select([
					`${this.report1188TableAlias}.consecutive`,
					`${this.report1188TableAlias}.creationDate`,
					`${this.report1188TableAlias}.creationUser`,
					`${this.report1188TableAlias}.news`,
					`${this.report1188TableAlias}.systemDate`,
					`${this.report1188TableAlias}.reportId1188`,
					`${this.report1188TableAlias}.reportName`,
					`${this.report1188TableAlias}.emissionTypeDomain`,
				])

		// ! warning: the orm has a bug, if you send the date as a Date type the dates will not match, use toISOString in this cases
		if (params.startDate !== undefined && params.endDate !== undefined) {
			query
				.andWhere(`${this.report1188TableAlias}.systemDate >= :startDate`, {
					startDate: params.startDate.toISOString(),
				})
				.andWhere(`${this.report1188TableAlias}.systemDate <= :endDate`, {
					endDate: params.endDate.toISOString(),
				})
		}

		if (params.consecutive !== undefined) {
			query.andWhere(
				`${this.report1188TableAlias}.consecutive <= :consecutive`,
				{
					consecutive: params.consecutive,
				}
			)
		}

		const [dianReport1188Data, count]: [DianReport1188[], number] =
			await Promise.all([
				query.offset(params.offset).limit(params.limit).getMany(),
				query.getCount(),
			])

		dianReport1188Data.map(
			(dianReport1188RegisterData: DianReport1188): void => {
				const reportsHistoricalTable1188Register: DianReports1188TableDataInterface =
					new Object() as DianReports1188TableDataInterface

				reportsHistoricalTable1188Register.consecutive =
					dianReport1188RegisterData.consecutive

				reportsHistoricalTable1188Register.generationDate =
					dianReport1188RegisterData.creationDate

				reportsHistoricalTable1188Register.generationUser =
					dianReport1188RegisterData.creationUser

				reportsHistoricalTable1188Register.news =
					dianReport1188RegisterData.news

				reportsHistoricalTable1188Register.realDate =
					dianReport1188RegisterData.systemDate

				reportsHistoricalTable1188Register.reportId1188 =
					dianReport1188RegisterData.reportId1188

				reportsHistoricalTable1188Register.reportName =
					dianReport1188RegisterData.reportName

				reportsHistoricalTable1188Register.reportType =
					dianReport1188RegisterData.emissionTypeDomain

				reportsHistoricalTable1188Registers.push(
					reportsHistoricalTable1188Register
				)
			}
		)

		return [reportsHistoricalTable1188Registers, count]
	}

	public async countReportsInHistoricalTable1188(params: {
		startDate: Date
		endDate: Date
	}): Promise<number> {
		const query: SelectQueryBuilder<DianReport1188> =
			this.dianReport1188Repository
				.createQueryBuilder(`${this.report1188TableAlias}`)
				.where(`${this.report1188TableAlias}.creationDate >= :startDate`, {
					startDate: params.startDate.toISOString(),
				})
				.andWhere(`${this.report1188TableAlias}.creationDate <= :endDate`, {
					endDate: params.endDate.toISOString(),
				})

		const count: number = await query.getCount()

		return count
	}

	public async report1188Consecutive(): Promise<number> {
		const [yearStartDate, yearEndDate]: [Date, Date] =
			this.getCurrentYearStartEndDate()

		const query: SelectQueryBuilder<DianReport1188> =
			this.dianReport1188Repository
				.createQueryBuilder(`${this.report1188TableAlias}`)
				.select([
					`MAX(${this.report1188TableAlias}.consecutive) AS "consecutive"`,
				])
				.where(`${this.report1188TableAlias}.systemDate >= :startDate`, {
					startDate: yearStartDate.toISOString(),
				})
				.andWhere(`${this.report1188TableAlias}.systemDate <= :endDate`, {
					endDate: yearEndDate.toISOString(),
				})

		const mostRecentReportData: DianReport1188 = await query.getRawOne()

		const consecutive: number =
			mostRecentReportData.consecutive !== null
				? mostRecentReportData.consecutive
				: 0

		return consecutive
	}

	public async report1740Consecutive(): Promise<number> {
		const [yearStartDate, yearEndDate]: [Date, Date] =
			this.getCurrentYearStartEndDate()

		const query: SelectQueryBuilder<DianReport1740> =
			this.dianReport1740Repository
				.createQueryBuilder(`${this.report1740TableAlias}`)
				.select([
					`MAX(${this.report1740TableAlias}.consecutive) AS "consecutive"`,
				])
				.where(`${this.report1740TableAlias}.systemDate >= :startDate`, {
					startDate: yearStartDate.toISOString(),
				})
				.andWhere(`${this.report1740TableAlias}.systemDate <= :endDate`, {
					endDate: yearEndDate.toISOString(),
				})

		const mostRecentReportData: DianReport1740 = await query.getRawOne()

		const consecutive: number =
			mostRecentReportData.consecutive !== null
				? mostRecentReportData.consecutive
				: 0

		return consecutive
	}

	public async fullDataReportCount(params: {
		startDate: Date
	}): Promise<number> {
		const queryResult: number = await this.dianMovementsRepository
			.createQueryBuilder(`${this.movementsTableAlias}`)
			.where(`${this.movementsTableAlias}.realDate = :startDate`, {
				startDate: params.startDate.toISOString(),
			})
			.getCount()

		return queryResult
	}

	public async fullDataReportMovements(params: {
		startDate: Date
	}): Promise<DianMovements[]> {
		const queryResult: DianMovements[] = await this.dianMovementsRepository
			.createQueryBuilder(`${this.movementsTableAlias}`)
			.where(`${this.movementsTableAlias}.realDate = :startDate`, {
				startDate: params.startDate.toISOString(),
			})
			.getRawMany()

		return queryResult
	}

	public async reportsHistoricalTable1740(params: {
		consecutive: number | undefined
		startDate: Date | undefined
		endDate: Date | undefined
		offset: number
		limit: number
	}): Promise<[DianReports1740TableDataInterface[], number]> {
		const reportsHistoricalTable1740Registers: DianReports1740TableDataInterface[] =
			[] as DianReports1740TableDataInterface[]

		const query: SelectQueryBuilder<DianReport1740> =
			this.dianReport1740Repository
				.createQueryBuilder(`${this.report1740TableAlias}`)
				.select([
					`${this.report1740TableAlias}.consecutive`,
					`${this.report1740TableAlias}.creationDate`,
					`${this.report1740TableAlias}.creationUser`,
					`${this.report1740TableAlias}.news`,
					`${this.report1740TableAlias}.systemDate`,
					`${this.report1740TableAlias}.reportId1740`,
					`${this.report1740TableAlias}.reportName`,
					`${this.report1740TableAlias}.emissionTypeDomain`,
				])

		// ! warning: the orm has a bug, if you send the date as a Date type the dates will not match, use toISOString in this cases
		if (params.startDate !== undefined && params.endDate !== undefined) {
			query
				.andWhere(`${this.report1740TableAlias}.systemDate >= :startDate`, {
					startDate: params.startDate.toISOString(),
				})
				.andWhere(`${this.report1740TableAlias}.systemDate <= :endDate`, {
					endDate: params.endDate.toISOString(),
				})
		}

		if (params.consecutive !== undefined) {
			query.andWhere(
				`${this.report1740TableAlias}.consecutive <= :consecutive`,
				{
					consecutive: params.consecutive,
				}
			)
		}

		const [dianReport1740Data, count]: [DianReport1740[], number] =
			await Promise.all([
				query.offset(params.offset).limit(params.limit).getMany(),
				query.getCount(),
			])

		dianReport1740Data.map(
			(dianReport1740RegisterData: DianReport1740): void => {
				const reportsHistoricalTable1740Register: DianReports1740TableDataInterface =
					new Object() as DianReports1740TableDataInterface

				reportsHistoricalTable1740Register.consecutive =
					dianReport1740RegisterData.consecutive

				reportsHistoricalTable1740Register.generationDate =
					dianReport1740RegisterData.creationDate

				reportsHistoricalTable1740Register.generationUser =
					dianReport1740RegisterData.creationUser

				reportsHistoricalTable1740Register.news =
					dianReport1740RegisterData.news

				reportsHistoricalTable1740Register.realDate =
					dianReport1740RegisterData.systemDate

				reportsHistoricalTable1740Register.reportId1740 =
					dianReport1740RegisterData.reportId1740

				reportsHistoricalTable1740Register.reportName =
					dianReport1740RegisterData.reportName

				reportsHistoricalTable1740Register.reportType =
					dianReport1740RegisterData.emissionTypeDomain

				reportsHistoricalTable1740Registers.push(
					reportsHistoricalTable1740Register
				)
			}
		)

		return [reportsHistoricalTable1740Registers, count]
	}

	public async countReportsInHistoricalTable1740(params: {
		startDate: Date
		endDate: Date
	}): Promise<number> {
		const query: SelectQueryBuilder<DianReport1740> =
			this.dianReport1740Repository
				.createQueryBuilder(`${this.report1740TableAlias}`)
				.where(`${this.report1740TableAlias}.creationDate >= :startDate`, {
					startDate: params.startDate.toISOString(),
				})
				.andWhere(`${this.report1740TableAlias}.creationDate <= :endDate`, {
					endDate: params.endDate.toISOString(),
				})

		const count: number = await query.getCount()

		return count
	}

	private getCurrentYearStartEndDate(): [Date, Date] {
		const currentDate: Date = new Date(Date.now())
		const currentYear: number = currentDate.getFullYear()
		const yearStartDate: Date = new Date(`${currentYear}-01-01`)
		const yearEndDate: Date = new Date(`${currentYear}-12-31`)
		return [yearStartDate, yearEndDate]
	}
}
