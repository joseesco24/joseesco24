/** @format */

import { InjectRepository } from "@nestjs/typeorm"
import { Injectable, ServiceUnavailableException } from "@nestjs/common"
import { Repository } from "typeorm"

import { DianDomain } from "@common-modules/dian-database/entities/dian-domain.entity"
import { databaseErrorMessage } from "@common-artifacts/constants/constants"
import { FoundDomainDescription } from "@common-modules/dian-database/dtos/foundDomainDescription.dto"

@Injectable()
export class DianDomainService {
	private readonly domainRealCodesCache: object = {}
	private readonly tableAlias: string = "domain"

	public constructor(
		@InjectRepository(DianDomain)
		private readonly dianDomainRepository: Repository<DianDomain>
	) {}

	public async getRealValueByDomainId(
		domainCode: number,
		domainType?: string
	): Promise<string> {
		try {
			if (domainType === undefined) {
				const queryResult: DianDomain = await this.dianDomainRepository
					.createQueryBuilder(`${this.tableAlias}`)
					.select([`${this.tableAlias}.realValue`])
					.where(`${this.tableAlias}.id = :id`, {
						id: domainCode,
					})
					.andWhere(`${this.tableAlias}.state = :state`, {
						state: true,
					})
					.getOneOrFail()

				return queryResult.realValue
			} else {
				const queryResult: DianDomain = await this.dianDomainRepository
					.createQueryBuilder(`${this.tableAlias}`)
					.select([`${this.tableAlias}.realValue`])
					.where(`${this.tableAlias}.id = :id`, {
						id: domainCode,
					})
					.andWhere(`${this.tableAlias}.state = :state`, {
						state: true,
					})
					.andWhere(`${this.tableAlias}.type = :type`, {
						type: domainType,
					})
					.getOneOrFail()

				this.domainRealCodesCache[domainCode] = queryResult.realValue

				return queryResult.realValue
			}
		} catch (e: any) {
			throw new ServiceUnavailableException(e.message)
		}
	}

	public async getRealValueByDomainIdNull(
		domainCode: number,
		domainType?: string
	): Promise<string> {
		try {
			if (domainCode in this.domainRealCodesCache) {
				return this.domainRealCodesCache[domainCode]
			}

			if (domainType === undefined) {
				const queryResult: DianDomain = await this.dianDomainRepository
					.createQueryBuilder(`${this.tableAlias}`)
					.select([`${this.tableAlias}.realValue`])
					.where(`${this.tableAlias}.id = :id`, {
						id: domainCode,
					})
					.andWhere(`${this.tableAlias}.state = :state`, {
						state: true,
					})
					.getOneOrFail()

				this.domainRealCodesCache[domainCode] = queryResult.realValue

				return queryResult.realValue
			} else {
				const queryResult: DianDomain = await this.dianDomainRepository
					.createQueryBuilder(`${this.tableAlias}`)
					.select([`${this.tableAlias}.realValue`])
					.where(`${this.tableAlias}.id = :id`, {
						id: domainCode,
					})
					.andWhere(`${this.tableAlias}.state = :state`, {
						state: true,
					})
					.andWhere(`${this.tableAlias}.type = :type`, {
						type: domainType,
					})
					.getOneOrFail()

				this.domainRealCodesCache[domainCode] = queryResult.realValue

				return queryResult.realValue
			}
		} catch (e: any) {
			return undefined
		}
	}

	public async getDescriptionsByDomainIds(
		domainCodes: number[]
	): Promise<DianDomain[]> {
		try {
			return await this.dianDomainRepository
				.createQueryBuilder(`${this.tableAlias}`)
				.select([`${this.tableAlias}.description AS "description"`])
				.addSelect([`${this.tableAlias}.id AS "id"`])
				.addSelect([`${this.tableAlias}.realValue AS "realValue"`])
				.addSelect([`${this.tableAlias}.type AS "type"`])
				.addSelect([`${this.tableAlias}.state AS "state"`])
				.where(`${this.tableAlias}.id IN (:...ids)`, {
					ids: domainCodes,
				})
				.andWhere(`${this.tableAlias}.state = :state`, {
					state: true,
				})
				.getRawMany()
		} catch (e) {
			try {
				const errorMessage: string = await this.getRealValueByDomainId(
					databaseErrorMessage
				)

				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (e: any) {
				throw new ServiceUnavailableException(e.message)
			}
		}
	}
	/**
	 *
	 *
	 * @param {string} domainType
	 * @return {*}  {Promise<FoundDomainDescription[]>}
	 * @memberof DianDomainService
	 */
	public async getDescriptionsByDomain(
		domainType: string
	): Promise<FoundDomainDescription[]> {
		try {
			return await this.dianDomainRepository
				.createQueryBuilder(`${this.tableAlias}`)
				.select([`${this.tableAlias}.description AS "domainDescription"`])
				.addSelect([`${this.tableAlias}.id AS "domainId"`])
				.addSelect([`${this.tableAlias}.realValue AS "realValue"`])
				.addSelect([`${this.tableAlias}.type AS "type"`])
				.addSelect([`${this.tableAlias}.state AS "state"`])
				.where(`${this.tableAlias}.type = :type`, {
					type: domainType,
				})
				.andWhere(`${this.tableAlias}.state = :state`, {
					state: true,
				})
				.getRawMany()
		} catch (e) {
			try {
				const errorMessage: string = await this.getRealValueByDomainId(
					databaseErrorMessage
				)
				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (e: any) {
				throw new ServiceUnavailableException(e.message)
			}
		}
	}

	public async getDescriptionByDomainId(params: {
		domainId: number
	}): Promise<string> {
		const queryResult: DianDomain = await this.dianDomainRepository
			.createQueryBuilder(`${this.tableAlias}`)
			.where(`${this.tableAlias}.id = :id`, {
				id: params.domainId,
			})
			.getOneOrFail()

		return queryResult.description
	}

	public async getDescriptionByDomainIdNull(params: {
		domainId: number
	}): Promise<string> {
		try {
			const queryResult: DianDomain = await this.dianDomainRepository
				.createQueryBuilder(`${this.tableAlias}`)
				.where(`${this.tableAlias}.id = :id`, {
					id: params.domainId,
				})
				.getOneOrFail()

			return queryResult.description
		} catch (e: any) {
			return undefined
		}
	}
	/**
	 *
	 *
	 * @param {number} domainCode
	 * @param {string} domainType
	 * @return {*}  {Promise<DianDomain>}
	 * @memberof DianDomainService
	 */
	public async getValueDescriptionByDomain(
		domainCode: number,
		domainType: string
	): Promise<DianDomain> {
		try {
			return await this.dianDomainRepository
				.createQueryBuilder(`${this.tableAlias}`)
				.select([`${this.tableAlias}.description AS "description"`])
				.addSelect([`${this.tableAlias}.realValue AS "realValue"`])
				.addSelect([`${this.tableAlias}.id AS "id"`])
				.addSelect([`${this.tableAlias}.type AS "type"`])
				.addSelect([`${this.tableAlias}.state AS "state"`])
				.where(`${this.tableAlias}.type = :type`, {
					type: domainType,
				})
				.andWhere(`${this.tableAlias}.id = :id`, {
					id: domainCode,
				})
				.andWhere(`${this.tableAlias}.state = :state`, {
					state: true,
				})
				.getRawOne()
		} catch (e) {
			try {
				const errorMessage: string = await this.getRealValueByDomainId(
					databaseErrorMessage
				)
				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (e: any) {
				throw new ServiceUnavailableException(e.message)
			}
		}
	}

	public async getIdbyDomainRealValue(
		realValueParam: string,
		domainType: string
	): Promise<DianDomain> {
		try {
			return await this.dianDomainRepository
				.createQueryBuilder(`${this.tableAlias}`)
				.select([`${this.tableAlias}.id AS "id"`])
				.addSelect([`${this.tableAlias}.description AS "description"`])
				.addSelect([`${this.tableAlias}.realValue AS "realValue"`])
				.addSelect([`${this.tableAlias}.type AS "type"`])
				.addSelect([`${this.tableAlias}.state AS "state"`])
				.where(`${this.tableAlias}.type = :type`, {
					type: domainType,
				})
				.andWhere(`${this.tableAlias}.realValue = :realValue`, {
					realValue: realValueParam,
				})
				.andWhere(`${this.tableAlias}.state = :state`, {
					state: true,
				})
				.getRawOne()
		} catch (e) {
			try {
				const errorMessage: string = await this.getRealValueByDomainId(
					databaseErrorMessage
				)
				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (e: any) {
				throw new ServiceUnavailableException(e.message)
			}
		}
	}

	public async replaceChannelValuesByName(params: {
		objectsList: object[]
		domainKey: string
	}): Promise<void> {
		const domainsCache: object = {}
		for (const obj of params.objectsList) {
			const domainId: number = obj[params.domainKey] as number
			if (obj !== undefined) {
				if (domainId in domainsCache) {
					obj[params.domainKey] = domainsCache[domainId]
				} else if (!(domainId in domainsCache)) {
					const domainRealValue: string = (
						await this.getIdbyDomainRealValue(
							domainId.toString(),
							"indicador_canal"
						)
					).description
					domainsCache[domainId] = domainRealValue
					obj[params.domainKey] = domainRealValue
				}
			} else if (obj === undefined) {
				domainsCache[domainId] = undefined
				obj[params.domainKey] = undefined
			}
		}
	}

	public async replaceDomainsByDescription(params: {
		objectsList: object[]
		domainKey: string
	}): Promise<void> {
		const domainsCache: object = {}
		for (const obj of params.objectsList) {
			const domainId: number = obj[params.domainKey] as number
			if (obj !== undefined) {
				if (domainId in domainsCache) {
					obj[params.domainKey] = domainsCache[domainId]
				} else if (!(domainId in domainsCache)) {
					const domainRealValue: string = await this.getDescriptionByDomainId({
						domainId: domainId,
					})
					domainsCache[domainId] = domainRealValue
					obj[params.domainKey] = domainRealValue
				}
			} else if (obj === undefined) {
				domainsCache[domainId] = undefined
				obj[params.domainKey] = undefined
			}
		}
	}
}
