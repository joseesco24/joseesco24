/** @format */

// ** info: nest commons imports
import { InjectRepository } from "@nestjs/typeorm"
import { Injectable } from "@nestjs/common"

// ** info: type orm imports
import { SelectQueryBuilder } from "typeorm"
import { Repository } from "typeorm"

import { DianLoadError } from "@common-modules/dian-database/entities/dian-load-errors.entity"
import { DianBatchLoad } from "@common-modules/dian-database/entities/dian-batch-load.entity"

import { LoadErrorsFullData } from "@common-modules/dian-database/interfaces/load-errors-full-data.interface"
import { FilesWithoutLoadErrorsDetails } from "@common-modules/dian-database/interfaces/files-without-load-errors-details.interface"

@Injectable()
export class LoadAlertsDbService {
	private readonly batchLoadTableAlias: string = "batchLoad"
	private readonly errorsLoadTableAlias: string = "errorsLoad"

	public constructor(
		@InjectRepository(DianBatchLoad)
		private readonly shdCargueBatchRepository: Repository<DianBatchLoad>,
		@InjectRepository(DianLoadError)
		private readonly shdErroresCargueRepository: Repository<DianLoadError>
	) {}

	public async getLoadErrorsFullDataInDateRange(params: {
		startDate: Date
		endDate: Date
	}): Promise<LoadErrorsFullData[]> {
		const query: SelectQueryBuilder<DianLoadError> =
			this.shdErroresCargueRepository
				.createQueryBuilder(`${this.errorsLoadTableAlias}`)
				.leftJoinAndSelect(
					`${this.errorsLoadTableAlias}.codigoCargue`,
					`${this.batchLoadTableAlias}`
				)
				.select([
					`${this.errorsLoadTableAlias}.codigoCargue AS codigoCargue`,
					`${this.errorsLoadTableAlias}.codigoCargueError AS codigoCargueError`,
					`${this.errorsLoadTableAlias}.descripcionError AS descripcionError`,
					`${this.errorsLoadTableAlias}.numeroRegistroError AS numeroRegistroError`,
					`${this.batchLoadTableAlias}.nombreArchivoCargado AS nombreArchivoCargado`,
					`${this.batchLoadTableAlias}.tiempoCarga AS tiempoCarga`,
					`${this.batchLoadTableAlias}.cantidadRegistros AS cantidadRegistros`,
					`${this.batchLoadTableAlias}.cantidadRegistrosExitosos AS cantidadRegistrosExitosos`,
					`${this.batchLoadTableAlias}.cantidadRegistrosFallidos AS cantidadRegistrosFallidos`,
				])
				.where(`${this.batchLoadTableAlias}.tiempoCarga >= :startDate`, {
					startDate: params.startDate.toISOString(),
				})
				.andWhere(`${this.batchLoadTableAlias}.tiempoCarga <= :endDate`, {
					endDate: params.endDate.toISOString(),
				})
				.andWhere(
					`${this.batchLoadTableAlias}.cantidadRegistrosFallidos > :cantidadRegistrosFallidos`,
					{
						cantidadRegistrosFallidos: 0,
					}
				)
				.orderBy(`${this.errorsLoadTableAlias}.codigoCargue`, "DESC")
				.orderBy(`${this.errorsLoadTableAlias}.codigoCargueError`, "DESC")

		const loadErrorsFullDataInDateRange: LoadErrorsFullData[] =
			await query.getRawMany()

		return loadErrorsFullDataInDateRange
	}

	public async getFilesWithoutLoadErrorsDetailsInDatesRange(params: {
		startDate: Date
		endDate: Date
	}): Promise<FilesWithoutLoadErrorsDetails[]> {
		const query: SelectQueryBuilder<DianBatchLoad> =
			this.shdCargueBatchRepository
				.createQueryBuilder(`${this.batchLoadTableAlias}`)
				.select([
					`${this.batchLoadTableAlias}.codigoCargue AS codigoCargue`,
					`${this.batchLoadTableAlias}.nombreArchivoCargado AS nombreArchivoCargado`,
					`${this.batchLoadTableAlias}.tiempoCarga AS tiempoCarga`,
					`${this.batchLoadTableAlias}.cantidadRegistros AS cantidadRegistros`,
					`${this.batchLoadTableAlias}.cantidadRegistrosExitosos AS cantidadRegistrosExitosos`,
					`${this.batchLoadTableAlias}.cantidadRegistrosFallidos AS cantidadRegistrosFallidos`,
				])
				.where(`${this.batchLoadTableAlias}.tiempoCarga >= :startDate`, {
					startDate: params.startDate.toISOString(),
				})
				.andWhere(`${this.batchLoadTableAlias}.tiempoCarga <= :endDate`, {
					endDate: params.endDate.toISOString(),
				})
				.andWhere(
					`${this.batchLoadTableAlias}.cantidadRegistrosFallidos = :cantidadRegistrosFallidos`,
					{
						cantidadRegistrosFallidos: 0,
					}
				)
				.orderBy(`${this.batchLoadTableAlias}.codigoCargue`, "DESC")

		const filesWithoutLoadErrors: FilesWithoutLoadErrorsDetails[] =
			await query.getRawMany()

		return filesWithoutLoadErrors
	}

	public async getFileNamesWithLoadErrorsInDatesRange(params: {
		startDate: Date
		endDate: Date
	}): Promise<DianBatchLoad[]> {
		const query: SelectQueryBuilder<DianBatchLoad> =
			this.shdCargueBatchRepository
				.createQueryBuilder(`${this.batchLoadTableAlias}`)
				.select([
					`${this.batchLoadTableAlias}.nombreArchivoCargado AS "nombreArchivoCargado"`,
				])
				.where(`${this.batchLoadTableAlias}.tiempoCarga >= :startDate`, {
					startDate: params.startDate.toISOString(),
				})
				.andWhere(`${this.batchLoadTableAlias}.tiempoCarga <= :endDate`, {
					endDate: params.endDate.toISOString(),
				})
				.andWhere(
					`${this.batchLoadTableAlias}.cantidadRegistrosFallidos > :cantidadRegistrosFallidos`,
					{
						cantidadRegistrosFallidos: 0,
					}
				)
				.groupBy(`${this.batchLoadTableAlias}.nombreArchivoCargado`)

		const filesWithLoadErrors: DianBatchLoad[] = await query.getRawMany()

		return filesWithLoadErrors
	}

	public async getFileNamesWithoutLoadErrorsInDatesRange(params: {
		startDate: Date
		endDate: Date
	}): Promise<DianBatchLoad[]> {
		const query: SelectQueryBuilder<DianBatchLoad> =
			this.shdCargueBatchRepository
				.createQueryBuilder(`${this.batchLoadTableAlias}`)
				.select([
					`${this.batchLoadTableAlias}.nombreArchivoCargado AS "nombreArchivoCargado"`,
				])
				.where(`${this.batchLoadTableAlias}.tiempoCarga >= :startDate`, {
					startDate: params.startDate.toISOString(),
				})
				.andWhere(`${this.batchLoadTableAlias}.tiempoCarga <= :endDate`, {
					endDate: params.endDate.toISOString(),
				})
				.andWhere(
					`${this.batchLoadTableAlias}.cantidadRegistrosFallidos = :cantidadRegistrosFallidos`,
					{
						cantidadRegistrosFallidos: 0,
					}
				)
				.groupBy(`${this.batchLoadTableAlias}.nombreArchivoCargado`)

		const filesWithoutLoadErrors: DianBatchLoad[] = await query.getRawMany()

		return filesWithoutLoadErrors
	}
}
