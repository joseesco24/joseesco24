/** @format */

// ** info: nest commons imports
import { ServiceUnavailableException } from "@nestjs/common"
import { BadRequestException } from "@nestjs/common"
import { Injectable } from "@nestjs/common"

// ** info: nest typeorm imports
import { InjectRepository } from "@nestjs/typeorm"

// ** info: class transformer imports
import { instanceToPlain } from "class-transformer"

import { DianDomainService } from "@common-modules/dian-database/services/dian-domain.service"

// ** info: dtos imports
import { NotNullishPaymentMethod } from "@common-modules/dian-database/dtos/notNullishPaymentMethod.dto"
import { FoundDomainDescription } from "@common-modules/dian-database/dtos/foundDomainDescription.dto"
import { MovsTableByAdhesiveResponse } from "@core-modules/movements/dtos/mov-by-adhesive-or-ref.dto"
import { MovementsByMonth } from "@common-modules/dian-database/dtos/movementsByMonth.dto"
import { NotNullishForm } from "@common-modules/dian-database/dtos/notNullishForm.dto"
import { NotNullishForm2 } from "@common-modules/dian-database/dtos/notNullishForm.dto"
import { MovsTableResponse } from "@core-modules/movements/dtos/movs-table-response.dto"
import { DataResponse } from "@core-modules/movements/dtos/movs-table-response.dto"
import { ChannelFilter } from "@core-modules/consolidated/dtos/channelFilter.dto"

// ** info: entities imports
import { DianMovements } from "@common-modules/dian-database/entities/dian-movements.entity"

// ** info: type orm imports
import { SelectQueryBuilder } from "typeorm"
import { Repository } from "typeorm"
import { Not } from "typeorm"

// ** info: moment import
import * as moment from "moment"

// ** info: artifacts imports
import { DataTreatementService } from "@common-modules/data-treatement/data-treatement.service"
import { ValidationException } from "@common-artifacts/decorators/validation.filter"
import { databaseErrorMessage } from "@common-artifacts/constants/constants"
import { columnRefListQuery } from "@common-artifacts/constants/constants"

@Injectable()
export class DianMovementsService {
	private readonly movTableAlias: string = "movements"
	private readonly domainTableAlias: string = "domain"
	private readonly taxTableAlias: string = "tax"

	public constructor(
		@InjectRepository(DianMovements)
		private readonly dianMovementsRepository: Repository<DianMovements>,
		private readonly dataTreatementService: DataTreatementService,
		private readonly dianDomainService: DianDomainService
	) {}

	public async summaryTablePaymentMethods(params: {
		earId: number
		start: Date
		end: Date
	}): Promise<NotNullishPaymentMethod[]> {
		// ** info: creating main query
		const sqlQuery: SelectQueryBuilder<DianMovements> =
			this.dianMovementsRepository
				.createQueryBuilder(`${this.movTableAlias}`)
				.leftJoinAndSelect(
					`${this.movTableAlias}.paymentFormDomain`,
					`${this.domainTableAlias}`
				)
				.leftJoinAndSelect(
					`${this.movTableAlias}.taxId`,
					`${this.taxTableAlias}`
				)
				.select([
					`${this.domainTableAlias}.description AS paymentMethod`,
					`${this.movTableAlias}.realDate AS realDate`,
					`${this.taxTableAlias}.taxName AS taxName`,
				])
				.addSelect(
					`SUM(${this.movTableAlias}.paymentValuePesos)`,
					"paymentsValue"
				)
				.addSelect(`COUNT(*)`, "paymentsCount")
				.addGroupBy(`${this.movTableAlias}.realDate`)
				.addGroupBy(`${this.taxTableAlias}.taxName`)
				.addGroupBy(`${this.domainTableAlias}.description`)
				.where(
					`(DATE_TRUNC('day',(${this.movTableAlias}.realDate))) >= :startDate`,
					{ startDate: params.start.toISOString() }
				)
				.andWhere(
					`(DATE_TRUNC('day',(${this.movTableAlias}.realDate))) <= :endDate`,
					{ endDate: params.end.toISOString() }
				)

		// ** info: appending ear filter if needed
		// todo: replace burned parametrization by params table call
		// ! warning: burned parametrization here [99999]
		if (params.earId !== 99999) {
			sqlQuery.andWhere(`${this.movTableAlias}.earId = :earId`, {
				earId: params.earId,
			})
		}

		const notNullishPaymentMethods: NotNullishPaymentMethod[] = []

		// todo: move this interface
		interface QueryResult {
			paymentmethod: string
			paymentsValue: string
			paymentsCount: string
			taxname: string
			realdate: Date
		}

		const results: QueryResult[] = await sqlQuery.getRawMany()

		results.map((result: QueryResult) => {
			const notNullishPaymentMethod: NotNullishPaymentMethod =
				new NotNullishPaymentMethod()

			// todo: make this operation with a global artifact
			notNullishPaymentMethod.realDate = moment(result.realdate).format(
				"YYYY-MM-DD"
			)

			notNullishPaymentMethod.paymentsCount = Number(result.paymentsCount)
			notNullishPaymentMethod.paymentsValue = Number(result.paymentsValue)
			notNullishPaymentMethod.paymentMethod = result.paymentmethod
			notNullishPaymentMethod.taxName = result.taxname

			notNullishPaymentMethods.push(notNullishPaymentMethod)
		})

		return notNullishPaymentMethods
	}

	public async summaryTableForms(params: {
		earId: number
		start: Date
		end: Date
	}): Promise<NotNullishForm[]> {
		// ** info: creating main query
		const sqlQuery: SelectQueryBuilder<DianMovements> =
			this.dianMovementsRepository
				.createQueryBuilder(`${this.movTableAlias}`)
				.leftJoinAndSelect(
					`${this.movTableAlias}.typeFormDomain`,
					`${this.domainTableAlias}`
				)
				.leftJoinAndSelect(
					`${this.movTableAlias}.taxId`,
					`${this.taxTableAlias}`
				)
				.select([
					`${this.domainTableAlias}.description AS paymentForm`,
					`${this.movTableAlias}.realDate AS realDate`,
					`${this.taxTableAlias}.taxName AS taxName`,
				])
				.addSelect(
					`SUM(${this.movTableAlias}.paymentValuePesos)`,
					"paymentsValue"
				)
				.addSelect("COUNT(*)", "paymentsCount")
				.addGroupBy(`${this.movTableAlias}.realDate`)
				.addGroupBy(`${this.taxTableAlias}.taxName`)
				.addGroupBy(`${this.domainTableAlias}.description`)
				.where(
					`(DATE_TRUNC('day',(${this.movTableAlias}.realDate))) >= :startDate`,
					{ startDate: params.start.toISOString() }
				)
				.andWhere(
					`(DATE_TRUNC('day',(${this.movTableAlias}.realDate))) <= :endDate`,
					{ endDate: params.end.toISOString() }
				)

		// ** info: appending ear filter if needed
		// todo: replace burned parametrization by params table call
		// ! warning: burned parametrization here [99999]
		if (params.earId !== 99999) {
			sqlQuery.andWhere(`${this.movTableAlias}.earId = :earId`, {
				earId: params.earId,
			})
		}

		const notNullishForms: NotNullishForm[] = []

		interface QueryResult {
			paymentsValue: string
			paymentsCount: string
			paymentform: string
			taxname: string
			realdate: Date
		}

		const results: QueryResult[] = await sqlQuery.getRawMany()

		results.map((result: QueryResult) => {
			const notNullishForm: NotNullishForm = new NotNullishForm()

			// todo: make this operation with a global artifact
			notNullishForm.realDate = moment(result.realdate).format("YYYY-MM-DD")

			notNullishForm.paymentsCount = Number(result.paymentsCount)
			notNullishForm.paymentsValue = Number(result.paymentsValue)
			notNullishForm.paymentForm = result.paymentform
			notNullishForm.taxName = result.taxname

			notNullishForms.push(notNullishForm)
		})

		return notNullishForms
	}

	public async summaryTableForms2(params: {
		earId: number
		start: Date
		end: Date
	}): Promise<NotNullishForm2[]> {
		// ** info: creating main query
		const sqlQuery: SelectQueryBuilder<DianMovements> =
			this.dianMovementsRepository
				.createQueryBuilder(`${this.movTableAlias}`)
				.leftJoinAndSelect(
					`${this.movTableAlias}.typeFormDomain`,
					`${this.domainTableAlias}`
				)
				.leftJoinAndSelect(
					`${this.movTableAlias}.taxId`,
					`${this.taxTableAlias}`
				)
				.select([
					`${this.movTableAlias}.paymentFormDomain AS "paymentFormDomain"`,
					`${this.movTableAlias}.typeFormDomain AS "typeFormDomain"`,
					`${this.movTableAlias}.realDate AS realDate`,
					`${this.taxTableAlias}.taxName AS taxName`,
				])
				.addSelect(
					`SUM(${this.movTableAlias}.paymentValuePesos)`,
					"paymentsValue"
				)
				.addSelect("COUNT(*)", "paymentsCount")
				.addGroupBy(`${this.movTableAlias}.realDate`)
				.addGroupBy(`${this.movTableAlias}.paymentFormDomain`)
				.addGroupBy(`${this.movTableAlias}.typeFormDomain`)
				.addGroupBy(`${this.taxTableAlias}.taxName`)
				.where(
					`(DATE_TRUNC('day',(${this.movTableAlias}.realDate))) >= :startDate`,
					{ startDate: params.start.toISOString() }
				)
				.andWhere(
					`(DATE_TRUNC('day',(${this.movTableAlias}.realDate))) <= :endDate`,
					{ endDate: params.end.toISOString() }
				)

		// ** info: appending ear filter if needed
		// todo: replace burned parametrization by params table call
		// ! warning: burned parametrization here [99999]
		if (params.earId !== 99999) {
			sqlQuery.andWhere(`${this.movTableAlias}.earId = :earId`, {
				earId: params.earId,
			})
		}

		const notNullishForms: NotNullishForm2[] = []

		interface QueryResult {
			paymentsValue: string
			paymentsCount: string
			typeFormDomain: number
			paymentFormDomain: number
			taxname: string
			realdate: Date
		}

		const results: QueryResult[] = await sqlQuery.getRawMany()
		const domainsCache: object = {}

		for (const result of results) {
			const notNullishForm: NotNullishForm2 = new NotNullishForm2()

			// todo: make this operation with a global artifact
			notNullishForm.realDate = moment(result.realdate).format("YYYY-MM-DD")

			const paymentFormKey: string = `k${result.typeFormDomain}`
			const paymentsMethodmKey: string = `k${result.paymentFormDomain}`

			let paymentFormDescription: string
			let paymentsMethodDescription: string

			if (paymentFormKey in domainsCache) {
				paymentFormDescription = domainsCache[paymentFormKey]
			} else {
				paymentFormDescription =
					await this.dianDomainService.getDescriptionByDomainId({
						domainId: result.typeFormDomain,
					})
				domainsCache[paymentFormKey] = paymentFormDescription
			}

			if (paymentsMethodmKey in domainsCache) {
				paymentsMethodDescription = domainsCache[paymentsMethodmKey]
			} else {
				paymentsMethodDescription =
					await this.dianDomainService.getDescriptionByDomainId({
						domainId: result.paymentFormDomain,
					})
				domainsCache[paymentsMethodmKey] = paymentsMethodDescription
			}

			notNullishForm.paymentsCount = Number(result.paymentsCount)
			notNullishForm.paymentsValue = Number(result.paymentsValue)
			notNullishForm.paymentForm = paymentFormDescription
			notNullishForm.paymentsMethod = paymentsMethodDescription
			notNullishForm.taxName = result.taxname

			notNullishForms.push(notNullishForm)
		}

		return notNullishForms
	}

	public async findConsolidatedMovements(
		channelFilter: ChannelFilter,
		year: number = new Date().getFullYear()
	): Promise<MovementsByMonth[]> {
		try {
			const currentYear: number = year

			const movementsByMonth: SelectQueryBuilder<DianMovements> =
				this.dianMovementsRepository
					.createQueryBuilder(`${this.movTableAlias}`)
					.where(`DATE_PART('year',(${this.movTableAlias}.realDate)) = :year`, {
						year: currentYear,
					})
					.andWhere({
						exclude: Not(true),
					})

			if (channelFilter.column != "undefined") {
				movementsByMonth.andWhere(
					`${this.movTableAlias}.${channelFilter.column} IN (:...channel)`,
					{ channel: channelFilter.channelInd }
				)
			}

			movementsByMonth
				.select([
					`SUM(${this.movTableAlias}.paymentValuePesos) AS "paymentValueSum"`,
				])
				.addSelect([`COUNT(*) AS "count"`])

				.addSelect([
					`to_char(date_trunc('month',(${this.movTableAlias}.realDate)), 'FMMM') AS "month"`,
				])
				.groupBy("month")

			return await movementsByMonth.getRawMany()
		} catch (e) {
			try {
				const errorMessage: string =
					await this.dianDomainService.getRealValueByDomainId(
						databaseErrorMessage
					)

				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (err: any) {
				throw new ServiceUnavailableException(e)
			}
		}
	}

	public async getTableMovements(params: {
		referenceNumber: string
		referenceType: number
		year: number
		offset: number
		limit: number
	}): Promise<MovsTableResponse> {
		const initialISODate: string = `${params.year}-01-01`
		const finalISODate: string = `${params.year}-12-31`

		const query: SelectQueryBuilder<DianMovements> =
			this.dianMovementsRepository
				.createQueryBuilder(`${this.movTableAlias}`)
				.select([
					`${this.movTableAlias}.nitOrId`,
					`${this.movTableAlias}.adhesiveOrCus`,
					`${this.movTableAlias}.declarationNumber`,
					`${this.movTableAlias}.paymentValuePesos`,
					`${this.movTableAlias}.formId`,
					`${this.movTableAlias}.conceptId`,
					`${this.movTableAlias}.earId`,
					`${this.movTableAlias}.realDate`,
				])
				.andWhere(`${this.movTableAlias}.realDate >= :startDate`, {
					startDate: initialISODate,
				})
				.andWhere(`${this.movTableAlias}.realDate <= :endDate`, {
					endDate: finalISODate,
				})

		const typeColumn: FoundDomainDescription[] =
			await this.dianDomainService.getDescriptionsByDomain(columnRefListQuery)
		if (!typeColumn) {
			throw new BadRequestException(
				// eslint-disable-next-line @typescript-eslint/restrict-template-expressions
				`Could not get any value from domain for ${columnRefListQuery}`
			)
		}
		const getColumByFilter: string[] = typeColumn
			.filter(
				(item: FoundDomainDescription) =>
					Number(item.realValue) === params.referenceType
			)
			.map((item: FoundDomainDescription) => item.domainDescription)

		const getColumnName: string[] =
			getColumByFilter.length > 0
				? getColumByFilter[0].split("|").flatMap((item: string) => item)
				: []

		if (getColumnName.length === 0) {
			throw new BadRequestException(`Column name to search is not found`)
		}

		let fixedReferenceNumber: string = ""
		let desiredLenght: number = 0

		for (const [index, item] of getColumnName.entries()) {
			if (item === "adhesiveOrCus") {
				desiredLenght = 16
				fixedReferenceNumber = this.dataTreatementService.fillWithCharacter({
					string: params.referenceNumber,
					desiredLenght: desiredLenght,
					character: "0",
					right: false,
				})
			}
			if (index === 0) {
				query.andWhere(`${this.movTableAlias}.${item} = :adhesiveNumber`, {
					adhesiveNumber:
						item === "adhesiveOrCus"
							? fixedReferenceNumber
							: Number(params.referenceNumber),
				})
			}
			if (index > 0) {
				query.orWhere(`${this.movTableAlias}.${item} = :adhesiveNumber2`, {
					adhesiveNumber2:
						item === "adhesiveOrCus"
							? fixedReferenceNumber
							: Number(params.referenceNumber),
				})
			}
		}

		const [dianMovements, count]: [DianMovements[], number] = await Promise.all(
			[
				query.offset(params.offset).limit(params.limit).getMany(),
				query.getCount(),
			]
		)

		const plainResults: object[] = []

		for (const movement of dianMovements) {
			const plainData: object = instanceToPlain(movement)
			plainResults.push(plainData)
		}
		const result: MovsTableResponse = {
			data: plainResults as DataResponse[],
			count,
		}
		return result
	}

	public async getTableMovementsByAdhesiveOrRef(params: {
		adhesiveOrRef: string
	}): Promise<MovsTableByAdhesiveResponse> {
		const query: SelectQueryBuilder<DianMovements> =
			this.dianMovementsRepository
				.createQueryBuilder(`${this.movTableAlias}`)
				.innerJoinAndSelect(
					"DianDomain",
					"dd",
					`dd.id = ${this.movTableAlias}.dominio_tipo_formulario`
				)
				.select([
					`${this.movTableAlias}.nitOrId as "nitOrId"`,
					`${this.movTableAlias}.declarationNumber as "declarationNumber"`,
					`${this.movTableAlias}.adhesiveOrCus as "adhesiveOrCus"`,
					`dd.description as "formType"`,
					`${this.movTableAlias}.paymentValuePesos as "paymentValue"`,
					`${this.movTableAlias}.formId as "formId"`,
					`${this.movTableAlias}.conceptId as "conceptId"`,
					`${this.movTableAlias}.earId as "earId"`,
					`${this.movTableAlias}.realDate as "realDate"`,
					`${this.movTableAlias}.movementId as "movementId"`,
				])

		const getColumnName: string[] = ["adhesiveOrCus", "declarationNumber"]

		let fixedReferenceNumber: string = ""
		let desiredLenght: number = 0

		for (const [index, item] of getColumnName.entries()) {
			if (item === "adhesiveOrCus") {
				desiredLenght = 16
				fixedReferenceNumber = this.dataTreatementService.fillWithCharacter({
					string: params.adhesiveOrRef,
					desiredLenght: desiredLenght,
					character: "0",
					right: false,
				})
			}
			if (index === 0) {
				query.andWhere(`${this.movTableAlias}.${item} = :adhesiveNumber`, {
					adhesiveNumber: fixedReferenceNumber,
				})
			}
			if (index > 0) {
				query.orWhere(`${this.movTableAlias}.${item} = :adhesiveNumber2`, {
					adhesiveNumber2: params.adhesiveOrRef,
				})
			}
			console.log(query.getQueryAndParameters())
		}

		const [dianMovements, count]: [DianMovements[], number] = await Promise.all(
			[query.getRawMany(), query.getCount()]
		)

		const plainResults: object[] = []

		for (const movement of dianMovements) {
			const plainData: object = instanceToPlain(movement)
			plainResults.push(plainData)
		}
		const result: MovsTableResponse = {
			data: plainResults as DataResponse[],
			count,
		}
		return result
	}

	public async getTableMovementsById(params: {
		movementId: number
	}): Promise<any> {
		try {
			const query: SelectQueryBuilder<DianMovements> =
				this.dianMovementsRepository
					.createQueryBuilder(`${this.movTableAlias}`)
					.select([
						`${this.movTableAlias}.declarationNumber as "declarationNumber"`,
						`${this.movTableAlias}.adhesiveOrCus as "adhesiveOrCus"`,
						`${this.movTableAlias}.earId as "earId"`,
						`${this.movTableAlias}.realDate as "realDate"`,
						`${this.movTableAlias}.typeFormDomain as "formType"`,
						`${this.movTableAlias}.nitOrId as "nitOrId"`,
						`${this.movTableAlias}.paymentFormDomain as "paymentFormId"`,
						`${this.movTableAlias}.paymentValuePesos as "paymentValuePesos"`,
						`${this.movTableAlias}.dianModeDomain as "dianModeId"`,
						`${this.movTableAlias}.formId as "formId"`,
						`${this.movTableAlias}.conceptId as "conceptId"`,
						`${this.movTableAlias}.dayTypeDomainId as "dayTypeId"`,
						`${this.movTableAlias}.limitPaymentDate as "limitPaymentDate"`,
						`${this.movTableAlias}.operationNumber as "operationNumber"`,
						`${this.movTableAlias}.hashCode as "hashNumber"`,
						`${this.movTableAlias}.authorizationNumber as "authorizationNumber"`,
						`${this.movTableAlias}.tellerCode as "tellerCode"`,
						`${this.movTableAlias}.movementId as "movementId"`,
					])
					.where(`${this.movTableAlias}.movementId = :movementId`, {
						movementId: params.movementId,
					})

			const dianMovements: DianMovements[] = await query.getRawMany()

			const plainResults: object[] = []

			for (const movement of dianMovements) {
				const plainData: object = instanceToPlain(movement)
				plainResults.push(plainData)
			}
			return plainResults[0]
		} catch (error) {
			try {
				const errorMessage: string =
					await this.dianDomainService.getRealValueByDomainId(
						databaseErrorMessage
					)
				throw new ValidationException(`${errorMessage}`)
			} catch (err: any) {
				throw new ServiceUnavailableException(err)
			}
		}
	}
	public async getContraintKeys(params: {
		adhesiveOrCus: number | string
		declarationNumber: number
	}): Promise<any> {
		try {
			const query: SelectQueryBuilder<DianMovements> =
				this.dianMovementsRepository
					.createQueryBuilder(`${this.movTableAlias}`)
					.select([`${this.movTableAlias}.movementId as "movementId"`])
					.where(`${this.movTableAlias}.adhesiveOrCus = :adhesiveOrCus`, {
						adhesiveOrCus: params.adhesiveOrCus,
					})
					.andWhere(
						`${this.movTableAlias}.declarationNumber = :declarationNumber`,
						{
							declarationNumber: params.declarationNumber,
						}
					)

			const dianMovements: any[] = await query.getRawMany()

			const plainResults: object[] = []

			for (const movement of dianMovements) {
				const plainData: object = instanceToPlain(movement)
				plainResults.push(plainData)
			}
			return plainResults[0]
		} catch (error) {
			try {
				const errorMessage: string =
					await this.dianDomainService.getRealValueByDomainId(
						databaseErrorMessage
					)
				throw new ValidationException(`${errorMessage}`)
			} catch (err: any) {
				throw new ServiceUnavailableException(err)
			}
		}
	}
}
