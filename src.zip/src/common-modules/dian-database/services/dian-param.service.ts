/** @format */

import { InjectRepository } from "@nestjs/typeorm"
import { Injectable, ServiceUnavailableException } from "@nestjs/common"
import { Repository } from "typeorm"
import { DianParam } from "../entities/dian-param.entity"

import { databaseErrorMessage } from "@common-artifacts/constants/constants"
import { ParameterResponse } from "@core-modules/transversal/dtos/parameter-response.dto"
import { DianDomainService } from "./dian-domain.service"

@Injectable()
export class DianParamService {
	private readonly tableAlias: string = "param"

	public constructor(
		@InjectRepository(DianParam)
		private readonly dianParamRepository: Repository<DianParam>,
		private readonly dianDomainService: DianDomainService
	) {}

	public async getParameterValue(
		parameter: string
	): Promise<ParameterResponse> {
		try {
			const queryResult: ParameterResponse = await this.dianParamRepository
				.createQueryBuilder(`${this.tableAlias}`)
				.select([`${this.tableAlias}.value AS "value"`])
				.addSelect([`${this.tableAlias}.parameterCode AS "parameterCode"`])
				.where(`${this.tableAlias}.parameterCode = :parameter`, {
					parameter: parameter,
				})
				.andWhere(`${this.tableAlias}.state = :state`, {
					state: true,
				})
				.getRawOne()

			if (queryResult === undefined) {
				try {
					const errorMessage: string =
						await this.dianDomainService.getRealValueByDomainId(
							databaseErrorMessage
						)
					throw new ServiceUnavailableException(`${errorMessage}`)
				} catch (e: any) {
					throw new ServiceUnavailableException(e.message)
				}
			} else {
				return queryResult
			}
		} catch (e) {
			try {
				const errorMessage: string =
					await this.dianDomainService.getRealValueByDomainId(
						databaseErrorMessage
					)
				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (e: any) {
				throw new ServiceUnavailableException(e.message)
			}
		}
	}

	public async getParameterValArray(
		parameters: string[]
	): Promise<ParameterResponse[]> {
		try {
			return await this.dianParamRepository
				.createQueryBuilder(`${this.tableAlias}`)
				.select([`${this.tableAlias}.value AS "value"`])
				.addSelect([`${this.tableAlias}.parameterCode AS "parameterCode"`])
				.where(`${this.tableAlias}.parameterCode IN (:...params)`, {
					params: parameters,
				})
				.andWhere(`${this.tableAlias}.state = :state`, {
					state: true,
				})
				.getRawMany()
		} catch (e) {
			try {
				const errorMessage: string =
					await this.dianDomainService.getRealValueByDomainId(
						databaseErrorMessage
					)
				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (e: any) {
				throw new ServiceUnavailableException(e.message)
			}
		}
	}
}
