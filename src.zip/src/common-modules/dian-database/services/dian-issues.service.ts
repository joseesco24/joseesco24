/** @format */

// ** info: constants imports
import { inclusionTypeDomainId } from "@common-artifacts/constants/constants"
import { databaseErrorMessage } from "@common-artifacts/constants/constants"

// ** info: core module dtos imports
import { ExcludeIssueRequest } from "@core-modules/issues/dtos/excludeIssueRequest.dto"
import { IssuesTableRequest } from "@core-modules/issues/dtos/issuesTableRequest.dto"
import { ModifyIssueRequest } from "@core-modules/issues/dtos/modifyIssueRequest.dto"

// ** info: common module dtos imports
import { FoundIssueByIdMod } from "@common-modules/dian-database/dtos/foundIssueByIdMod.dto"
import { FoundIssueByIdExc } from "@common-modules/dian-database/dtos/foundIssueByIdExc.dto"
import { IssuesDataCount } from "@common-modules/dian-database/dtos/issuesDataCount.dto"

// ** info: nest imports
import { ServiceUnavailableException } from "@nestjs/common"
import { BadRequestException } from "@nestjs/common"
import { Injectable } from "@nestjs/common"
import { Logger } from "@nestjs/common"

// ** info: nest typeorm imports
import { InjectRepository } from "@nestjs/typeorm"

// ** info: typeorm imports
import { SelectQueryBuilder } from "typeorm"
import { QueryRunner } from "typeorm"
import { DataSource } from "typeorm"
import { Repository } from "typeorm"

// ** info: entites imports
import { DianMovements } from "@common-modules/dian-database/entities/dian-movements.entity"
import { DianIssues } from "@common-modules/dian-database/entities/dian-issues.entity"

// ** info: services imports
import { DianDomainService } from "@common-modules/dian-database/services/dian-domain.service"

import { CreateIssues } from "@core-modules/issues/models/create-issues.interface"

@Injectable()
export class DianIssuesService {
	private readonly logger: Logger = new Logger(DianIssuesService.name)

	private readonly issuesTableAlias: string = "issues"
	private readonly movTableAlias: string = "movements"
	private readonly taxTableAlias: string = "dianTax"
	private readonly domainIssueTableAlias: string = "dianDomainIssueType"
	private readonly domainDayTypeTableAlias: string = "dianDomainDayType"
	private readonly domainFormTypeTableAlias: string = "dianDomainFormType"

	public constructor(
		@InjectRepository(DianIssues)
		private readonly dianIssuesRepository: Repository<DianIssues>,

		@InjectRepository(DianMovements)
		private readonly dianMovementsRepository: Repository<DianMovements>,

		private readonly dianDomainService: DianDomainService,

		private readonly dataSource: DataSource
	) {}

	public async filterIssues(
		issuesTableRequest: IssuesTableRequest
	): Promise<IssuesDataCount> {
		try {
			const issuesFoundQuery: SelectQueryBuilder<DianIssues> =
				this.dianIssuesRepository
					.createQueryBuilder(`${this.issuesTableAlias}`)
					.leftJoinAndSelect(
						`${this.issuesTableAlias}.dianMovements`,
						`${this.movTableAlias}`
					)
					.leftJoinAndSelect(
						`${this.movTableAlias}.dianTax`,
						`${this.taxTableAlias}`
					)
					.leftJoinAndSelect(
						`${this.issuesTableAlias}.dianDomainIssueType`,
						`${this.domainIssueTableAlias}`
					)
					.leftJoinAndSelect(
						`${this.movTableAlias}.dianDomainDayType`,
						`${this.domainDayTypeTableAlias}`
					)
					.leftJoinAndSelect(
						`${this.movTableAlias}.dianDomainFormType`,
						`${this.domainFormTypeTableAlias}`
					)
					.where(`${this.movTableAlias}.movementId IS NOT NULL`)

			if (issuesTableRequest.issueType !== undefined) {
				issuesFoundQuery.andWhere(
					`lower(unaccent(${this.domainIssueTableAlias}.description)) like lower(unaccent(:issueType))`,
					{ issueType: `${issuesTableRequest.issueType}%` }
				)
			}

			if (issuesTableRequest.formId !== undefined) {
				issuesFoundQuery.andWhere(
					`CAST(${this.movTableAlias}.formId as text) like :form`,
					{ form: `%${issuesTableRequest.formId}%` }
				)
			}

			if (issuesTableRequest.conceptId !== undefined) {
				issuesFoundQuery.andWhere(
					`CAST(${this.movTableAlias}.conceptId as text) like :concept`,
					{ concept: `%${issuesTableRequest.conceptId}%` }
				)
			}
			if (issuesTableRequest.earId !== undefined) {
				issuesFoundQuery.andWhere(
					`CAST(${this.movTableAlias}.earId as text) like :earId`,
					{ earId: `${issuesTableRequest.earId}%` }
				)
			}

			if (issuesTableRequest.declarationNumber !== undefined) {
				issuesFoundQuery.andWhere(
					`CAST(${this.movTableAlias}.declarationNumber as text) like :declarationNumber`,
					{ declarationNumber: `%${issuesTableRequest.declarationNumber}%` }
				)
			}
			if (issuesTableRequest.adhesiveOrCus !== undefined) {
				issuesFoundQuery.andWhere(
					`CAST(${this.movTableAlias}.adhesiveOrCus as text) like :adhesiveOrCus`,
					{ adhesiveOrCus: `%${issuesTableRequest.adhesiveOrCus}%` }
				)
			}
			if (issuesTableRequest.formType !== undefined) {
				issuesFoundQuery.andWhere(
					`lower(unaccent(${this.domainFormTypeTableAlias}.description)) like lower(unaccent(:formType))`,
					{ formType: `${issuesTableRequest.formType}%` }
				)
			}
			if (issuesTableRequest.realDate !== undefined) {
				issuesFoundQuery.andWhere(
					`CAST(${this.movTableAlias}.realDate as text) like :realDate`,
					{ realDate: `${issuesTableRequest.realDate}%` }
				)
			}
			issuesFoundQuery
				.select([`${this.domainIssueTableAlias}.description AS "issueType"`])
				.addSelect([`${this.movTableAlias}.formId AS "formId"`])
				.addSelect([`${this.movTableAlias}.conceptId AS "conceptId"`])
				//! warning:  Should the value be taken from the movement table or from the inconsistency table?
				.addSelect([
					`${this.issuesTableAlias}.paymentValuePesos AS "paymentValue"`,
				])
				.addSelect([`${this.movTableAlias}.earId AS "earId"`])
				.addSelect([
					`${this.issuesTableAlias}.declarationNumber AS "declarationNumber"`,
				])
				.addSelect([`${this.movTableAlias}.adhesiveOrCus AS "adhesiveOrCus"`])
				.addSelect([
					`${this.domainFormTypeTableAlias}.description AS "formType"`,
				])

				.addSelect([`${this.movTableAlias}.realDate AS "realDate"`])
				.addSelect([`${this.domainDayTypeTableAlias}.description AS "dayType"`])
				.addSelect([
					`${this.issuesTableAlias}.creationUser AS "modificationUser"`,
				])
				.addSelect([
					`${this.issuesTableAlias}.creationDate AS "lastModificationDate"`,
				])
				.addSelect([`${this.movTableAlias}.movementId AS "movementId"`])
				.addSelect([`${this.movTableAlias}.reportId1188 AS "reportId1188"`])
				.addSelect([`${this.movTableAlias}.reportId1740 AS "reportId1740"`])
				.addSelect([`${this.movTableAlias}.exclude AS "exclude"`])
				//.distinctOn([`${this.movTableAlias}.movementId`])
				.orderBy(`${this.movTableAlias}.movementId`, "ASC")
				.addOrderBy(`${this.issuesTableAlias}.creationDate`, "DESC")

			const [data, count]: [any[], number] = await Promise.all([
				issuesFoundQuery
					.limit(issuesTableRequest.limit)
					.offset(issuesTableRequest.offset)
					.getRawMany(),
				issuesFoundQuery.getCount(),
			])

			return {
				count,
				data,
			}
		} catch (e) {
			try {
				const errorMessage: string =
					await this.dianDomainService.getRealValueByDomainId(
						databaseErrorMessage
					)
				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (e: any) {
				throw new ServiceUnavailableException(e.message)
			}
		}
	}

	public async getIssueByIdMod(movementId: number): Promise<FoundIssueByIdMod> {
		try {
			return await this.dianMovementsRepository
				.createQueryBuilder(`${this.movTableAlias}`)
				.leftJoinAndSelect(
					`${this.movTableAlias}.dianTax`,
					`${this.taxTableAlias}`
				)
				.leftJoinAndSelect(
					`${this.movTableAlias}.dianDomainDayType`,
					`${this.domainDayTypeTableAlias}`
				)

				.where(`${this.movTableAlias}.movementId = :id`, { id: movementId })
				.andWhere(`${this.movTableAlias}.reportId1188 IS NULL`)
				.andWhere(`${this.movTableAlias}.reportId1740 IS NULL`)
				.andWhere(`${this.movTableAlias}.exclude = :exclude`, {
					exclude: false,
				})

				.select([`${this.taxTableAlias}.taxName AS "taxName"`])
				.addSelect([`${this.movTableAlias}.adhesiveOrCus AS "adhesiveOrCus"`])
				.addSelect([
					`${this.movTableAlias}.declarationNumber AS "declarationNumber"`,
				])
				.addSelect([`${this.movTableAlias}.accountNumber AS "accountNumber"`])
				.addSelect([
					`${this.movTableAlias}.paymentValuePesos AS "paymentValuePesos"`,
				])
				.addSelect([
					`${this.domainDayTypeTableAlias}.description AS "dayTypeDescription"`,
				])
				.addSelect([`${this.movTableAlias}.earId AS "earId"`])
				.addSelect([`${this.movTableAlias}.paymentMethod AS "paymentMethod"`])
				.addSelect([
					`${this.movTableAlias}.authorizationNumber AS "authorizationNumber"`,
				])
				.addSelect([
					`${this.movTableAlias}.limitPaymentDate AS "limitPaymentDate"`,
				])
				.addSelect([`${this.movTableAlias}.movementId AS "movementId"`])
				.getRawOne()
		} catch (e: any) {
			try {
				const errorMessage: string =
					await this.dianDomainService.getRealValueByDomainId(
						databaseErrorMessage
					)
				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (e: any) {
				throw new ServiceUnavailableException(e.message)
			}
		}
	}

	public async updateIssue(
		modifyIssueRequest: ModifyIssueRequest,
		ip: any,
		issueTypeParam: number,
		issueFoundRaw: FoundIssueByIdMod
	): Promise<DianIssues> {
		const queryRunner: QueryRunner = this.dataSource.createQueryRunner()
		await queryRunner.connect()
		await queryRunner.startTransaction()

		const date: Date = new Date()
		try {
			const dataIssues: object = {
				movementId: issueFoundRaw.movementId,
				nitOrId: modifyIssueRequest.nitOrId,
				paymentValuePesos: modifyIssueRequest.paymentValue,
				declarationNumber: modifyIssueRequest.declarationNumber.toString(),
				justification: modifyIssueRequest.justification,
				creationDate: date,
				creationUser: modifyIssueRequest.generationUser,
				creationIp: ip,
				issueTypeDomain: issueTypeParam,
			}

			const issue: object = queryRunner.manager.create(DianIssues, dataIssues)

			await Promise.all([
				await queryRunner.manager.save(issue),

				await queryRunner.manager
					.createQueryBuilder()
					.update(DianMovements)
					.set({
						paymentValuePesos: modifyIssueRequest.paymentValue,
						declarationNumber: modifyIssueRequest.declarationNumber,
						nitOrId: modifyIssueRequest.nitOrId,
					})
					.where(`dian_movimientos.codigo_movimiento = :id`, {
						id: modifyIssueRequest.movementId,
					})
					.execute(),
			])

			await queryRunner.commitTransaction()
			return issue as DianIssues
		} catch (err: any) {
			await queryRunner.rollbackTransaction()
			throw new BadRequestException(err.message)
		} finally {
			await queryRunner.release()
		}
	}

	public async getIssueByIdExc(movementId: number): Promise<FoundIssueByIdExc> {
		try {
			return await this.dianMovementsRepository
				.createQueryBuilder(`${this.movTableAlias}`)

				.where(`${this.movTableAlias}.movementId = :id`, { id: movementId })
				.andWhere(`${this.movTableAlias}.reportId1188 IS NULL`)
				.andWhere(`${this.movTableAlias}.reportId1740 IS NULL`)
				.andWhere(`${this.movTableAlias}.exclude = :exclude`, {
					exclude: false,
				})

				.select([
					`${this.movTableAlias}.declarationNumber AS "declarationNumber"`,
				])
				.addSelect([
					`${this.movTableAlias}.paymentValuePesos AS "paymentValuePesos"`,
				])
				.addSelect([`${this.movTableAlias}.nitOrId AS "nitOrId"`])
				.addSelect([`${this.movTableAlias}.exclude AS "exclude"`])
				.addSelect([`${this.movTableAlias}.movementId AS "movementId"`])
				.getRawOne()
		} catch (e) {
			try {
				const errorMessage: string =
					await this.dianDomainService.getRealValueByDomainId(
						databaseErrorMessage
					)
				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (e: any) {
				throw new ServiceUnavailableException(e.message)
			}
		}
	}

	public async excludeIssue(
		excludeIssueRequest: ExcludeIssueRequest,
		ip: any,
		issueTypeParam: number,
		issueFoundRaw: FoundIssueByIdExc
	): Promise<DianIssues> {
		const queryRunner: QueryRunner = this.dataSource.createQueryRunner()
		await queryRunner.connect()
		await queryRunner.startTransaction()

		const date: Date = new Date()
		try {
			const dataIssues: object = {
				movementId: excludeIssueRequest.movementId,
				nitOrId: issueFoundRaw.nitOrId,
				paymentValuePesos: issueFoundRaw.paymentValuePesos,
				declarationNumber: issueFoundRaw.declarationNumber.toString(),
				justification: excludeIssueRequest.justification,
				creationDate: date,
				creationUser: excludeIssueRequest.generationUser,
				creationIp: ip,
				issueTypeDomain: issueTypeParam,
			}
			const issue: object = queryRunner.manager.create(DianIssues, dataIssues)

			Promise.all([
				await queryRunner.manager.save(issue),
				queryRunner.manager
					.createQueryBuilder()
					.update(DianMovements)
					.set({ exclude: true })
					.where(`dian_movimientos.codigo_movimiento = :id`, {
						id: excludeIssueRequest.movementId,
					})
					.execute(),
			])

			await queryRunner.commitTransaction()
			return issue as DianIssues
		} catch (err: any) {
			await queryRunner.rollbackTransaction()

			throw new BadRequestException(err.message)
		} finally {
			await queryRunner.release()
		}
	}

	public async saveIssue(createIssue: CreateIssues): Promise<DianMovements> {
		const queryRunner: QueryRunner = this.dataSource.createQueryRunner()
		await queryRunner.connect()
		await queryRunner.startTransaction()

		const date: Date = new Date()
		try {
			const data: object = {
				declarationNumber: createIssue.declarationNumber,
				dayTypeDomainId: createIssue.dayTypeId,
				dianModeDomain: createIssue.dianModeId,
				issueTypeDomain: inclusionTypeDomainId,
				typeFormDomain: createIssue.formType,
				paymentFormDomain: createIssue.paymentFormId,
				taxId: createIssue.taxId,
				earId: createIssue.earId,
				adhesiveOrCus: createIssue.adhesiveOrCus,
				realDate: createIssue.realDate,
				realHour: createIssue.realHour,
				nitOrId: createIssue.nitOrId,
				formId: createIssue.formId,
				conceptId: createIssue.conceptId,
				paymentValuePesos: createIssue.paymentValue,
				limitPaymentDate: createIssue.limitPaymentDate,
				tellerCode: createIssue.tellerCode,
				operationNumber: createIssue.operationNumber,
				hashCode: createIssue.hashCode,
				exclude: false,
			}

			const movement: DianMovements = queryRunner.manager.create(
				DianMovements,
				data
			) as DianMovements

			await Promise.all([queryRunner.manager.save(movement)])

			const dataIssues: object = {
				movementId: movement.movementId,
				nitOrId: createIssue.nitOrId,
				paymentValuePesos: createIssue.paymentValue,
				declarationNumber: createIssue.declarationNumber.toString(),
				justification: createIssue.justification,
				creationDate: date,
				creationUser: createIssue.generationUser,
				creationIp: createIssue.ip,
				issueTypeDomain: inclusionTypeDomainId,
			}
			await Promise.all([
				queryRunner.manager.save(
					queryRunner.manager.create(DianIssues, dataIssues)
				),
			])

			await queryRunner.commitTransaction()
			return movement
		} catch (err: any) {
			await queryRunner.rollbackTransaction()
			throw new BadRequestException(err.stack)
		} finally {
			await queryRunner.release()
		}
	}
}
