/** @format */

// ** info: nest commons imports
import { Injectable, ServiceUnavailableException } from "@nestjs/common"

// ** info: nest type orm imports
import { InjectRepository } from "@nestjs/typeorm"

// ** info: type orm imports
import { SelectQueryBuilder } from "typeorm"
import { Repository } from "typeorm"

// ** info: entites repositorioes imports
import { DianOffice } from "@common-modules/dian-database/entities/dian-office.entity"
import { databaseErrorMessage } from "@common-artifacts/constants/constants"
import { DianDomainService } from "./dian-domain.service"

@Injectable()
export class DianOfficesService {
	private readonly tableAlias: string = "DianOfficesTable"

	public constructor(
		@InjectRepository(DianOffice)
		private readonly dianOfficeRepository: Repository<DianOffice>,
		private readonly dianDomainService: DianDomainService
	) {}

	public async officesTable(params: {
		earDianId: number | undefined
		earType: number | undefined
		earName: string | undefined
		earId: number | undefined
		city: string | undefined
		offset: number
		limit: number
	}): Promise<[DianOffice[], number]> {
		// ** info: creating main query
		const sqlQuery: SelectQueryBuilder<DianOffice> = this.dianOfficeRepository
			.createQueryBuilder(`${this.tableAlias}`)
			.select([
				`${this.tableAlias}.earId`,
				`${this.tableAlias}.earDomainType`,
				`${this.tableAlias}.earDianId`,
				`${this.tableAlias}.name`,
				`${this.tableAlias}.city`,
				`${this.tableAlias}.creationDate`,
			])

		// ** info: appending ear id filter if exist
		if (!(params.earId === undefined)) {
			sqlQuery.andWhere(`${this.tableAlias}.earId = :earId`, {
				earId: params.earId,
			})
		}

		// ** info: appending ear id domain type filter if exist
		if (!(params.earType === undefined)) {
			sqlQuery.andWhere(`${this.tableAlias}.earDomainType = :earDomainType`, {
				earDomainType: params.earType,
			})
		}

		// ** info: appending ear dian id filter if exist
		if (!(params.earDianId === undefined)) {
			sqlQuery.andWhere(`${this.tableAlias}.earDianId = :earDianId`, {
				earDianId: params.earDianId,
			})
		}

		// ** info: appending name filter if exist
		if (!(params.earName === undefined)) {
			sqlQuery.andWhere(
				`lower(unaccent(${this.tableAlias}.name)) ^@ lower(unaccent(:name))`,
				{
					name: params.earName,
				}
			)
		}

		// ** info: appending city filter if exist
		if (!(params.city === undefined)) {
			sqlQuery.andWhere(
				`lower(unaccent(${this.tableAlias}.city)) ^@ lower(unaccent(:city))`,
				{
					city: params.city,
				}
			)
		}

		// ** info: executing and saving main query and count cuery at the same time
		const [dianOffices, count]: [DianOffice[], number] = await Promise.all([
			sqlQuery.offset(params.offset).limit(params.limit).getMany(),
			sqlQuery.getCount(),
		])

		return [dianOffices, count]
	}

	public async officesList(params: {
		search: number | undefined
	}): Promise<DianOffice[]> {
		// ** info: creating main query
		const sqlQuery: SelectQueryBuilder<DianOffice> = this.dianOfficeRepository
			.createQueryBuilder(`${this.tableAlias}`)
			.select([`${this.tableAlias}.earId`, `${this.tableAlias}.name`])

		// ** info: executing and saving main query
		const dianOffices: DianOffice[] = await sqlQuery.getMany()

		if (params.search !== undefined) {
			// ** info: filtering the response array
			const dianFilteredOffices: DianOffice[] = dianOffices.filter(
				(dianOffice: DianOffice): boolean => {
					const filterRegexString: string = `^${String(params.search)}`
					const filterRegex: RegExp = new RegExp(filterRegexString)
					const officeIdString: string = String(dianOffice.earId)

					if (filterRegex.test(officeIdString)) {
						return true
					} else {
						return false
					}
				}
			)

			// todo: replace burned parametrization by params table call
			// ! warning: burned parametrization here [0, 7]
			return dianFilteredOffices.slice(0, 7)
		} else {
			// todo: replace burned parametrization by params table call
			// ! warning: burned parametrization here [0, 7]
			return dianOffices.slice(0, 7)
		}
	}

	public async findOfficeById(earId: number): Promise<any[]> {
		try {
			return await this.dianOfficeRepository
				.createQueryBuilder(`${this.tableAlias}`)
				.select([`${this.tableAlias}.earId AS "earId"`])
				.addSelect([`${this.tableAlias}.name AS "name"`])
				.where(`${this.tableAlias}.earId  = :id`, {
					id: earId,
				})
				.getRawOne()
		} catch (e) {
			try {
				const errorMessage: string =
					await this.dianDomainService.getRealValueByDomainId(
						databaseErrorMessage
					)
				throw new ServiceUnavailableException(`${errorMessage}`)
			} catch (e: any) {
				throw new ServiceUnavailableException(e.message)
			}
		}
	}
}
