/** @format */

export interface ItaxById {
	taxId: number
	taxName?: string
	formId?: number
	conceptId?: number
	status?: number
	dianMode?: number
}
