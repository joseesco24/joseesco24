/** @format */

// ** info: nest commons imports
import { Module } from "@nestjs/common"

// ** info: nest type orm imports
import { TypeOrmModule } from "@nestjs/typeorm"

// ** info: common entities imports
import { DianReport1188 } from "@common-modules/dian-database/entities/dian-reports-1188.entity"
import { DianReport1740 } from "@common-modules/dian-database/entities/dian-reports-1740.entity"
import { DianLoadError } from "@common-modules/dian-database/entities/dian-load-errors.entity"
import { DianBatchLoad } from "@common-modules/dian-database/entities/dian-batch-load.entity"
import { DianMovements } from "@common-modules/dian-database/entities/dian-movements.entity"
import { DianOffice } from "@common-modules/dian-database/entities/dian-office.entity"
import { DianIssues } from "@common-modules/dian-database/entities/dian-issues.entity"
import { DianDomain } from "@common-modules/dian-database/entities/dian-domain.entity"
import { DianParam } from "@common-modules/dian-database/entities/dian-param.entity"
import { DianTax } from "@common-modules/dian-database/entities/dian-tax.entity"

// ** info: common services imports
import { DianMovementsService } from "@common-modules/dian-database/services/dian-movements.service"
import { LoadAlertsDbService } from "@common-modules/dian-database/services/load-alerts.db-service"
import { DianReportsService } from "@common-modules/dian-database/services/dian-reports.service"
import { DianOfficesService } from "@common-modules/dian-database/services/dian-offices.service"
import { DianDomainService } from "@common-modules/dian-database/services/dian-domain.service"
import { DianIssuesService } from "@common-modules/dian-database/services/dian-issues.service"
import { DianParamService } from "@common-modules/dian-database/services/dian-param.service"
import { DianTaxService } from "@common-modules/dian-database/services/dian-tax.service"

// ** info: common database provider import
import { dataBaseProviders } from "@common-modules/dian-database/services/database.service"

@Module({
	imports: [
		...dataBaseProviders,
		TypeOrmModule.forFeature([
			DianReport1188,
			DianReport1740,
			DianBatchLoad,
			DianLoadError,
			DianMovements,
			DianIssues,
			DianDomain,
			DianOffice,
			DianParam,
			DianTax,
		]),
	],
	exports: [
		...dataBaseProviders,
		DianMovementsService,
		LoadAlertsDbService,
		DianReportsService,
		DianOfficesService,
		DianDomainService,
		DianParamService,
		DianTaxService,
		DianMovementsService,
		DianIssuesService,
	],
	providers: [
		DianMovementsService,
		LoadAlertsDbService,
		DianReportsService,
		DianOfficesService,
		DianDomainService,
		DianParamService,
		DianTaxService,
		DianMovementsService,
		DianIssuesService,
	],
})
export class DianDatabaseModule {}
