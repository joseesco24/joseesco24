/** @format */

export interface FilesWithoutLoadErrorsDetails {
	codigoCargue: number
	nombrearchivocargado: string
	tiempocarga: Date
	cantidadregistros: number
	cantidadregistrosexitosos: number
	cantidadregistrosfallidos: number
}
