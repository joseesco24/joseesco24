/** @format */

export interface DianReports1740TableDataInterface {
	realDate: string
	reportName: string
	reportType: number
	consecutive: number
	news: boolean
	generationDate: Date
	generationUser: string
	reportId1740: number
}
