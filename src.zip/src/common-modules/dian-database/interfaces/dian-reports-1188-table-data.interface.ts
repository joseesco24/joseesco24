/** @format */

export interface DianReports1188TableDataInterface {
	realDate: string
	reportName: string
	reportType: number
	consecutive: number
	news: boolean
	generationDate: Date
	generationUser: string
	reportId1188: number
}
