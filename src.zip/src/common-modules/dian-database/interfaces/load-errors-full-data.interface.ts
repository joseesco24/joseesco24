/** @format */

export interface LoadErrorsFullData {
	codigocargue: number
	codigocargueerror: number
	descripcionerror: string
	numeroregistroerror: number
	nombrearchivocargado: string
	tiempocarga: Date
	cantidadregistros: number
	cantidadregistrosexitosos: number
	cantidadregistrosfallidos: number
}
