/** @format */

import { DianDatabaseModule } from "@common-modules/dian-database/dian-database.module"
import { HttpModule } from "@nestjs/axios"
import { Module } from "@nestjs/common"
import { AuthenticationService } from "./authentication.service"

@Module({
	imports: [HttpModule, DianDatabaseModule],
	providers: [AuthenticationService],
	exports: [AuthenticationService],
})
export class AuthenticationModule {}
