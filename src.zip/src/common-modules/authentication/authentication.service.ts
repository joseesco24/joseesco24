/** @format */

// ** info: nest imports
import { HttpService } from "@nestjs/axios"
import { Injectable } from "@nestjs/common"
import { Logger } from "@nestjs/common"

// ** info: rxjs imports
import { Observable } from "rxjs"
import { map } from "rxjs"

import { AxiosResponse } from "axios"

// ** info: nest config imports
import { ConfigService } from "@nestjs/config"

@Injectable()
export class AuthenticationService {
	private readonly logger: Logger = new Logger(AuthenticationService.name)

	private readonly authServiceUrl: string

	public constructor(
		private readonly httpService: HttpService,
		private readonly configService: ConfigService
	) {
		this.authServiceUrl = this.configService.get(
			"URL_AUTH_SERVICE_VALIDATE" as string
		)
	}

	// ! warning: callback hell here
	// todo: solve this callback hell
	public checkAuth(
		jwt: string | string[],
		iv: string | string[]
	): Observable<AxiosResponse<any>> {
		return this.httpService
			.post(`${this.authServiceUrl}`, { jwt: jwt, iv: iv })
			.pipe(
				map((data: any) => {
					return data
				})
			)
	}
}
