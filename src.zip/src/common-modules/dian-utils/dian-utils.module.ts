/** @format */

import { Module } from "@nestjs/common"
import { DianUtilsService } from "./services/dian-utils.service"

@Module({
	providers: [DianUtilsService],
	exports: [DianUtilsService],
})
export class DianUtilsModule {}
