/**
 * @format
 */

import { Injectable, InternalServerErrorException } from "@nestjs/common"

@Injectable()
export class DianUtilsService {
	// eslint-disable-next-line @typescript-eslint/no-empty-function
	public constructor() {}

	// eslint-disable-next-line @typescript-eslint/require-await
	public async formatDateHour(
		date: Date,
		isTimeRequired: boolean
	): Promise<string> {
		try {
			// eslint-disable-next-line @typescript-eslint/typedef
			let month = `${date.getMonth() + 1}`
			// eslint-disable-next-line @typescript-eslint/typedef
			let day = `${date.getDate()}`
			// eslint-disable-next-line @typescript-eslint/typedef
			const year = date.getFullYear()
			// eslint-disable-next-line @typescript-eslint/typedef
			let hour = String(date.getHours())
			// eslint-disable-next-line @typescript-eslint/typedef
			let minutes = String(date.getMinutes())
			// eslint-disable-next-line @typescript-eslint/typedef
			let seconds = String(date.getSeconds())

			if (month.length < 2) month = "0" + month
			if (day.length < 2) day = "0" + day
			if (hour.length < 2) hour = "0" + hour
			if (minutes.length < 2) minutes = "0" + minutes
			if (seconds.length < 2) seconds = "0" + seconds

			if (isTimeRequired) {
				return (
					[day, month, year].join("-") +
					" " +
					[hour, minutes, seconds].join(":")
				)
			} else {
				return [day, month, year].join("-")
			}
		} catch (e: any) {
			throw new InternalServerErrorException(e.message)
		}
	}
}
