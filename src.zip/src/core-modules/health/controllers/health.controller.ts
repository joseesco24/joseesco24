/** @format */

import { Controller, Get } from "@nestjs/common"
import {
	HealthCheck,
	HealthCheckResult,
	HealthCheckService,
	HealthIndicatorResult,
	MemoryHealthIndicator,
} from "@nestjs/terminus"

@Controller("health")
export class HealthController {
	public constructor(
		private readonly health: HealthCheckService,
		private readonly memory: MemoryHealthIndicator
	) {}

	// eslint-disable-next-line @typescript-eslint/require-await
	@Get()
	@HealthCheck()
	public async check(): Promise<HealthCheckResult> {
		return this.health.check([
			async (): Promise<HealthIndicatorResult> =>
				await this.memory.checkHeap("memory_heap", 150 * 1024 * 1024),
		])
	}
}
