/** @format */

// ** info: nest commons imports
import { InternalServerErrorException } from "@nestjs/common"
import { BadRequestException } from "@nestjs/common"
import { Injectable } from "@nestjs/common"

// ** info: response dto's imports
import { TaxesTableResponseDto } from "@core-modules/taxes/dtos/module/taxes-table-response.dto"
import { FindTaxByIdResponseDto } from "@core-modules/taxes/dtos/module/find-tax-by-id-response.dto"

// ** info: request dto's imports
import { TaxesTableRequestDto } from "@core-modules/taxes/dtos/module/taxes-table-request.dto"
import { CreateRequestDto } from "@core-modules/taxes/dtos/module/create-request.dto"
import { UpdateRequestDto } from "@core-modules/taxes/dtos/module/update-request.dto"

// ** info: common services imports
import { TaxesDataCount } from "@common-modules/dian-database/dtos/taxesDataCount.dto"
import { DianDomainService } from "@common-modules/dian-database/services/dian-domain.service"
import { DianParamService } from "@common-modules/dian-database/services/dian-param.service"
import { DianUtilsService } from "@common-modules/dian-utils/services/dian-utils.service"
import { DianTaxService } from "@common-modules/dian-database/services/dian-tax.service"

// ** info: common constants imports
import { maxLimitTaxTableParam } from "@common-artifacts/constants/constants"
import { taxStatusDomain } from "@common-artifacts/constants/constants"
import { cancelado } from "@common-artifacts/constants/constants"
import { vigente } from "@common-artifacts/constants/constants"

// ** info: common artifacts imports
import { ValidationException } from "@common-artifacts/decorators/validation.filter"

// ** info: dian database entites repositorioes imports
import { DianTax } from "@common-modules/dian-database/entities/dian-tax.entity"

// ** info: third party library imports
import * as requestIp from "request-ip"

@Injectable()
export class TaxesService {
	public constructor(
		private readonly dianDomainService: DianDomainService,
		private readonly dianParamService: DianParamService,
		private readonly dianTaxService: DianTaxService,
		private readonly dianUtils: DianUtilsService
	) {}

	public async filtertaxes(
		taxesTableRequest: TaxesTableRequestDto
	): Promise<TaxesTableResponseDto> {
		//get maxLimit from DB
		// eslint-disable-next-line @typescript-eslint/typedef
		const maxLimit = (
			await this.dianParamService.getParameterValue(maxLimitTaxTableParam)
		).value

		if (taxesTableRequest.limit > parseInt(maxLimit)) {
			throw new BadRequestException("limite excede el maximo predefinido")
		} else {
			//parse status string to boolean for db search
			let searchBool: boolean[] = []
			const vigenteStr: string = vigente
			const canceladoStr: string = cancelado
			const regexSearch: RegExp = new RegExp(taxesTableRequest.status, "i")
			if (
				vigenteStr.search(regexSearch) === -1 &&
				canceladoStr.search(regexSearch) == -1 &&
				taxesTableRequest.status !== ""
			) {
				return {
					count: 0,
					data: [],
				}
			} else if (
				vigenteStr.search(regexSearch) === -1 &&
				canceladoStr.search(regexSearch) === -1
			) {
				searchBool = [true, false]
			} else if (
				vigenteStr.search(regexSearch) !== -1 &&
				canceladoStr.search(regexSearch) === -1
			) {
				searchBool = [true]
			} else if (
				vigenteStr.search(regexSearch) === -1 &&
				canceladoStr.search(regexSearch) !== -1
			) {
				searchBool = [false]
			} else {
				searchBool = [true, false]
			}

			//get issue table data and count
			const dataCount: TaxesDataCount = await this.dianTaxService.filterTaxes(
				taxesTableRequest,
				searchBool
			)

			try {
				const dataResponseArray: any[] = []
				// eslint-disable-next-line @typescript-eslint/typedef
				const dataLength = dataCount.data.length
				let response: TaxesTableResponseDto

				//build response schema if no data
				if (dataLength === 0) {
					response = {
						count: dataCount.count,
						data: [],
					}
				} else {
					await Promise.all(
						dataCount.data.map(async (tax: any) => {
							//lastModification set
							// eslint-disable-next-line @typescript-eslint/typedef
							const lastModDateFormat = await this.dianUtils.formatDateHour(
								new Date(tax.lastModificationDate),
								true
							)

							//status set
							let stautsRes: string
							if (tax.status) {
								stautsRes = "Vigente"
							} else {
								stautsRes = "Cancelado"
							}

							let taxMode: string = ""
							if (tax.dianMode !== undefined) {
								await this.dianDomainService
									.getDescriptionByDomainId({
										domainId: tax.dianMode,
									})
									.then((resp: string) => (taxMode = resp))
							}

							//Build data Response schema
							const dataResponse: any = {
								taxName: tax.taxName,
								formId: tax.formId,
								conceptId: tax.conceptId,
								dianMode: taxMode,
								status: stautsRes,
								modificationUser: tax.modificationUser,
								lastModificationDate: lastModDateFormat,
								taxId: tax.taxId,
							}
							dataResponseArray.push(dataResponse)
						})
					)
					//build response schema if data
					response = {
						count: dataCount.count,
						data: dataResponseArray,
					}
				}
				return response
			} catch (e: any) {
				throw new InternalServerErrorException(e.message)
			}
		}
	}

	public async getTaxById(
		taxByIdRequest: number
	): Promise<FindTaxByIdResponseDto> {
		//find taxId in DB
		const taxFoundRaw: FindTaxByIdResponseDto =
			await this.dianTaxService.getTaxById(taxByIdRequest)

		if (taxFoundRaw === undefined) {
			throw new ValidationException(
				"Bad Request. Datos de entrada no validos: taxId"
			)
		}
		let statusDomainId: number
		if (taxFoundRaw.status !== undefined) {
			await this.dianDomainService
				.getIdbyDomainRealValue(taxFoundRaw.status.toString(), taxStatusDomain)
				.then((resp: any) => (statusDomainId = resp.id))
		}

		//Build data Response schema
		const dataResponse: FindTaxByIdResponseDto = {
			taxName: taxFoundRaw.taxName,
			formId: taxFoundRaw.formId,
			conceptId: taxFoundRaw.conceptId,
			status: statusDomainId,
			dianMode: taxFoundRaw.dianMode,
		}
		return dataResponse
	}
	public async addTax(
		addTaxRequest: CreateRequestDto,
		req: any
	): Promise<DianTax> {
		const errors: string[] = [
			"Bad Request. Datos de entrada no existen en Base de datos: ",
		]
		//taxId validation
		const taxFoundRaw: FindTaxByIdResponseDto =
			await this.dianTaxService.getduplicateContraint(
				addTaxRequest.taxName,
				addTaxRequest.formId,
				addTaxRequest.conceptId,
				addTaxRequest.dianMode
			)

		if (taxFoundRaw !== undefined) {
			throw new ValidationException("Código de Impuesto ya asignado")
		}
		//status validation and status assignation
		let realStatus: boolean
		try {
			const realStatusRaw: string =
				await this.dianDomainService.getRealValueByDomainId(
					addTaxRequest.status,
					taxStatusDomain
				)
			realStatus = Boolean(realStatusRaw)
		} catch (e) {
			errors.push("realStatus,")
		}

		if (errors.length === 1) {
			//obtain Ip
			const currentIp: string = requestIp
				.getClientIp(req)
				.toString()
				.replace("::ffff:", "")

			//save tax
			const newTax: any = await this.dianTaxService.addTax(
				addTaxRequest,
				currentIp,
				realStatus
			)
			return newTax
		} else {
			const message: string = errors.join("")
			const messagePrettier: string = message.substring(0, message.length - 1)
			throw new ValidationException(messagePrettier)
		}
	}

	public async updateTax(
		modifyTaxRequest: UpdateRequestDto,
		req: any
	): Promise<any> {
		const errors: string[] = [
			"Bad Request. Datos de entrada no existen en Base de datos: ",
		]
		//status validation and status assignation
		let realStatus: boolean
		try {
			const realStatusRaw: string =
				await this.dianDomainService.getRealValueByDomainId(
					modifyTaxRequest.status,
					taxStatusDomain
				)
			if (realStatusRaw === "true") {
				realStatus = true
			} else {
				realStatus = false
			}
		} catch (e) {
			errors.push("realStatus,")
		}

		const taxFoundRaw: FindTaxByIdResponseDto =
			await this.dianTaxService.getTaxById(modifyTaxRequest.taxId)

		if (taxFoundRaw === undefined) {
			throw new ValidationException(
				"Bad Request. Datos de entrada no validos: taxId"
			)
		}
		if (errors.length === 1) {
			//obtain Ip
			const currentIp: string = requestIp
				.getClientIp(req)
				.toString()
				.replace("::ffff:", "")

			//Update tax
			const newTax: string = await this.dianTaxService.modifyTax(
				modifyTaxRequest,
				currentIp,
				realStatus
			)
			return newTax
		} else {
			const message: string = errors.join("")
			const messagePrettier: string = message.substring(0, message.length - 1)
			throw new ValidationException(messagePrettier)
		}
	}
}
