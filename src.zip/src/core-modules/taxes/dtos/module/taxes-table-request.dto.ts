/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsOptional } from "class-validator"
import { IsString } from "class-validator"
import { IsInt } from "class-validator"

export class TaxesTableRequestDto {
	@IsOptional()
	@IsString()
	public taxName?: string

	@IsOptional()
	@IsString()
	public dianMode?: string

	@IsOptional()
	@IsString()
	public status?: string

	@IsOptional()
	@IsString()
	public modificationUser?: string

	@IsOptional()
	@IsString()
	public conceptId?: string

	@IsOptional()
	@IsString()
	public formId?: string

	@IsInt()
	@IsNotEmpty()
	public limit!: number

	@IsInt()
	@IsNotEmpty()
	public offset!: number
}
