/** @format */

// ** info: class validator imports
import { IsInt } from "class-validator"

// ** info: class transformer imports
import { Transform } from "class-transformer"

export class FindTaxByIdRequestDto {
	@Transform((param: any) => Number(param.value))
	@IsInt()
	public taxId!: number
}
