/** @format */

// ! warning: returning database entite literal
// todo: replace this by an interface
// ** info: dian databse module imports
import { TaxesFoundData } from "@common-modules/dian-database/dtos/taxesFoundData.dto"

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsNumber } from "class-validator"

// ** info: class transformer imports
import { Type } from "class-transformer"

export class TaxesTableResponseDto {
	@IsNumber()
	@IsNotEmpty()
	public count!: number

	@Type(() => TaxesFoundData)
	@IsNotEmpty()
	public data!: TaxesFoundData[]
}
