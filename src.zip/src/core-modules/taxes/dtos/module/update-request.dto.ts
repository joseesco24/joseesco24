/** @format */

// ** info: inheritable dtos imports
import { TaxEntiteBaseRequestDto } from "@core-modules/taxes/dtos/inheritables/tax-entite-base-request.dto"

export class UpdateRequestDto extends TaxEntiteBaseRequestDto {}
