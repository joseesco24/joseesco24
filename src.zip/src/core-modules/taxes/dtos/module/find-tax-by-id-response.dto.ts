/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsString } from "class-validator"
import { IsInt } from "class-validator"

export class FindTaxByIdResponseDto {
	@IsString()
	@IsNotEmpty()
	public taxName!: string

	@IsInt()
	@IsNotEmpty()
	public formId!: number

	@IsInt()
	@IsNotEmpty()
	public conceptId!: number

	@IsInt()
	@IsNotEmpty()
	public status!: number

	@IsInt()
	@IsNotEmpty()
	public dianMode!: number
}
