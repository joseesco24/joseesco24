/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsOptional } from "class-validator"
import { MaxLength } from "class-validator"
import { IsString } from "class-validator"
import { IsInt } from "class-validator"

export class TaxEntiteBaseRequestDto {
	@IsNotEmpty()
	@IsString()
	@MaxLength(50)
	public taxName!: string

	@IsNotEmpty()
	@IsInt()
	public formId!: number

	@IsNotEmpty()
	@IsInt()
	public status!: number

	@IsNotEmpty()
	@IsInt()
	public conceptId!: number

	@IsNotEmpty()
	@IsInt()
	public dianMode!: number

	@IsOptional()
	@IsInt()
	public taxId?: number

	@IsNotEmpty()
	@IsString()
	public generationUser: string
}
