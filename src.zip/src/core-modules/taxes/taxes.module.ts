/** @format */

// ** info: nest commons imports
import { Module } from "@nestjs/common"

// ** info: dian databse module import
import { DianDatabaseModule } from "@common-modules/dian-database/dian-database.module"

// ** info: dian utils module import
import { DianUtilsModule } from "@common-modules/dian-utils/dian-utils.module"

// ** info: this module services controllers imports
import { TaxesService } from "@core-modules/taxes/services/taxes.service"

// ** info: this module controllers imports
import { TaxesController } from "@core-modules/taxes/controllers/taxes.controller"

@Module({
	imports: [DianDatabaseModule, DianUtilsModule],
	providers: [TaxesService],
	controllers: [TaxesController],
})
export class TaxesModule {}
