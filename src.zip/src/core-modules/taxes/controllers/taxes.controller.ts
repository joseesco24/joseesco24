/** @format */

// ** info: nest commons imports
import { UseFilters } from "@nestjs/common"
import { Controller } from "@nestjs/common"
import { HttpCode } from "@nestjs/common"
import { Request } from "@nestjs/common"
import { Body } from "@nestjs/common"
import { Post } from "@nestjs/common"
import { Put } from "@nestjs/common"
import { Req } from "@nestjs/common"

import { FindTaxByIdResponseDto } from "@core-modules/taxes/dtos/module/find-tax-by-id-response.dto"
import { TaxesTableResponseDto } from "@core-modules/taxes/dtos/module/taxes-table-response.dto"
import { TaxesTableRequestDto } from "@core-modules/taxes/dtos/module/taxes-table-request.dto"
import { FindTaxByIdRequestDto } from "@core-modules/taxes/dtos/module/find-tax-by-id-request.dto"
import { CreateRequestDto } from "@core-modules/taxes/dtos/module/create-request.dto"
import { UpdateRequestDto } from "@core-modules/taxes/dtos/module/update-request.dto"

// ** info: module service providers imports
import { TaxesService } from "@core-modules/taxes/services/taxes.service"

// ** info: dian database entites imports
import { DianTax } from "@common-modules/dian-database/entities/dian-tax.entity"

// ** info: common artifacts imports
import { AllExceptionsFilter } from "@common-artifacts/decorators/all-exceptions.filter"

// ** info: third party library imports
import { posix } from "path"

import { LoggingService } from "@common-artifacts/logger-service/logging.service"

@UseFilters(AllExceptionsFilter)
@Controller("taxes")
export class TaxesController {
	public constructor(
		private readonly taxesService: TaxesService,
		private readonly loggingService: LoggingService
	) {}

	@Post(posix.join("taxes-table"))
	@HttpCode(200)
	public async filterTaxes(
		@Body() taxesTableRequest: TaxesTableRequestDto,
		@Req() request: Request
	): Promise<TaxesTableResponseDto> {
		this.loggingService.log(undefined, request)
		return await this.taxesService.filtertaxes(taxesTableRequest)
	}

	@HttpCode(200)
	@Post(posix.join("find-tax-by-id"))
	public async findTaxById(
		@Body() taxByIdRequest: FindTaxByIdRequestDto,
		@Req() request: Request
	): Promise<FindTaxByIdResponseDto> {
		this.loggingService.log(undefined, request)
		return await this.taxesService.getTaxById(taxByIdRequest.taxId)
	}

	// ! warning: returning database entite literal here
	// todo: replace this by a dedicated interface
	@HttpCode(201)
	@Post(posix.join("create"))
	public async addTax(
		@Body() addTaxRequest: CreateRequestDto,
		@Request() req: Request
	): Promise<DianTax> {
		this.loggingService.log(undefined, req)
		return await this.taxesService.addTax(addTaxRequest, req)
	}

	@HttpCode(200)
	@Put(posix.join("update"))
	public async updateTax(
		@Body() modifyTaxRequest: UpdateRequestDto,
		@Request() req: Request
	): Promise<any> {
		this.loggingService.log(undefined, req)
		return await this.taxesService.updateTax(modifyTaxRequest, req)
	}
}
