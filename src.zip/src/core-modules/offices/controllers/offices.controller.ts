/** @format */

// ** info: node imports
import { posix } from "path"

// ** info: nest commons imports
import { BadRequestException } from "@nestjs/common"
import { Controller } from "@nestjs/common"
import { HttpStatus } from "@nestjs/common"
import { HttpCode } from "@nestjs/common"
import { Body } from "@nestjs/common"
import { Post } from "@nestjs/common"
import { Req } from "@nestjs/common"

// ** info: offices service import
import { OfficesService } from "@core-modules/offices/services/offices.service"

// ** info: response dto's imports
import { OfficesTableResponseDto } from "@core-modules/offices/dtos/offices-table-response.dto"
import { OfficesListResponseDto } from "@core-modules/offices/dtos/offices-list-response.dto"

// ** info: request dto's imports
import { OfficesTableRequestDto } from "@core-modules/offices/dtos/offices-table-request.dto"
import { OfficesListRequestDto } from "@core-modules/offices/dtos/offices-list-request.dto"

import { LoggingService } from "@common-artifacts/logger-service/logging.service"

import { Request } from "express"

@Controller("offices")
export class OfficesController {
	public constructor(
		private readonly officesService: OfficesService,
		private readonly loggingService: LoggingService
	) {}

	@HttpCode(HttpStatus.OK)
	@Post(posix.join("offices-table"))
	public async officesTable(
		@Body() officesTableRequest: OfficesTableRequestDto,
		@Req() request: Request
	): Promise<{
		data: OfficesTableResponseDto[]
		count: number
	}> {
		this.loggingService.log(undefined, request)
		// ** info: parsing request values manually due to problems with class transformer
		const earDianId: number | undefined =
			officesTableRequest.earDianId !== undefined
				? Number(officesTableRequest.earDianId)
				: undefined

		const earType: string | undefined =
			officesTableRequest.earType !== undefined
				? String(officesTableRequest.earType)
				: undefined

		const earName: string | undefined =
			officesTableRequest.earName !== undefined
				? String(officesTableRequest.earName)
				: undefined

		const earId: number | undefined =
			officesTableRequest.earId !== undefined
				? Number(officesTableRequest.earId)
				: undefined

		const city: string | undefined =
			officesTableRequest.city !== undefined
				? String(officesTableRequest.city)
				: undefined

		const offset: number = Number(officesTableRequest.offset)

		const limit: number = Number(officesTableRequest.limit)

		// ! warning: burned domains restriction
		// todo: change this by domain parametrization
		if (
			!(earType === undefined) &&
			earType !== "oficina" &&
			earType !== "corresponsal"
		) {
			throw new BadRequestException("the earType is not valid")
		}

		let earTypeTransale: number

		if (earType === "oficina") {
			earTypeTransale = 25
		} else if (earType === "corresponsal") {
			earTypeTransale = 26
		}

		// ** info: calling the offices service method
		const [officesTableContent, count]: [OfficesTableResponseDto[], number] =
			await this.officesService.officesTable({
				earDianId: earDianId,
				earType: earTypeTransale,
				earName: earName,
				earId: earId,
				city: city,
				offset: offset,
				limit: limit,
			})

		// ** info: adjusting the response format after validations
		const officesTableResponse: {
			data: OfficesTableResponseDto[]
			count: number
		} = { data: officesTableContent, count: count }
		return officesTableResponse
	}

	@HttpCode(HttpStatus.OK)
	@Post(posix.join("offices-list"))
	public async officesList(
		@Body() officesListRequest: OfficesListRequestDto,
		@Req() request: Request
	): Promise<OfficesListResponseDto[]> {
		this.loggingService.log(undefined, request)
		// ** info: parsing request values manually due to problems with class transformer
		let search: number | undefined = undefined

		if (officesListRequest.search !== "") {
			search = Number(officesListRequest.search)
			if (isNaN(search)) {
				throw new BadRequestException("invalid search value")
			}
			if (search > 99999 || search < 0) {
				throw new BadRequestException("invalid search range value")
			}
		}

		// ** info: calling the offices service method
		const officesListContent: OfficesListResponseDto[] =
			await this.officesService.officesList({
				search: search,
			})

		// ** info: adjusting the response format after validations
		const officesListResponse: OfficesListResponseDto[] = officesListContent
		return officesListResponse
	}
}
