/** @format */

// ** info: class validator imports
import { IsNumberString } from "class-validator"
import { IsNotEmpty } from "class-validator"
import { IsOptional } from "class-validator"
import { IsString } from "class-validator"
import { IsInt } from "class-validator"

// todo: implement class transformer transformations here
export class OfficesTableRequestDto {
	@IsNumberString({ length: 3 })
	@IsOptional()
	public readonly earDianId: number | undefined = undefined

	@IsString()
	@IsOptional()
	public readonly earType: string | undefined = undefined

	@IsString()
	@IsOptional()
	public readonly earName: string | undefined = undefined

	@IsNumberString({ length: 4 })
	@IsOptional()
	public readonly earId: number | undefined = undefined

	@IsString()
	@IsOptional()
	public readonly city: string | undefined = undefined

	@IsInt()
	@IsNotEmpty()
	public readonly offset!: number

	@IsInt()
	@IsNotEmpty()
	public readonly limit!: number
}
