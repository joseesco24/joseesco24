/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsString } from "class-validator"
import { IsInt } from "class-validator"

export class OfficesListResponseDto {
	@IsInt()
	@IsNotEmpty()
	public readonly value!: number

	@IsString()
	@IsNotEmpty()
	public readonly viewValue!: string
}
