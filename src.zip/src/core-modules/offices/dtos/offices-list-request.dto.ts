/** @format */

// ** info: class validator imports
import { IsDefined } from "class-validator"
import { IsString } from "class-validator"

// todo: implement class transformer transformations here
export class OfficesListRequestDto {
	@IsString()
	@IsDefined()
	public readonly search!: string
}
