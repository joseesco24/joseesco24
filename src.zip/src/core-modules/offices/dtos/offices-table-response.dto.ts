/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsString } from "class-validator"
import { IsInt } from "class-validator"

export class OfficesTableResponseDto {
	@IsInt()
	@IsNotEmpty()
	public readonly earId!: number

	@IsString()
	@IsNotEmpty()
	public readonly earCreationDate!: Date

	@IsString()
	@IsNotEmpty()
	public readonly earName!: string

	@IsInt()
	@IsNotEmpty()
	public readonly earDianId!: number

	@IsString()
	@IsNotEmpty()
	public readonly city!: string

	@IsInt()
	@IsNotEmpty()
	public readonly earType!: string
}
