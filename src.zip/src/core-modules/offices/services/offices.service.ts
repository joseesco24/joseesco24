/** @format */

// ** info: nest commons imports
import { Injectable } from "@nestjs/common"

// ** info: response dto's imports
import { OfficesTableResponseDto } from "@core-modules/offices/dtos/offices-table-response.dto"
import { OfficesListResponseDto } from "@core-modules/offices/dtos/offices-list-response.dto"

// ** info: dian database module imports
import { DianOfficesService } from "@common-modules/dian-database/services/dian-offices.service"
import { DianDomainService } from "@common-modules/dian-database/services/dian-domain.service"

// ** info: entites repositorioes imports
import { DianOffice } from "@common-modules/dian-database/entities/dian-office.entity"

@Injectable()
export class OfficesService {
	private earTypeDescriptionDomainCache: object = {}

	public constructor(
		private readonly dianOfficesService: DianOfficesService,
		private readonly dianDomainService: DianDomainService
	) {
		this.earTypeDescriptionDomainCache = {}
	}

	public async officesTable(params: {
		earDianId: number | undefined
		earType: number | undefined
		earName: string | undefined
		earId: number | undefined
		city: string | undefined
		offset: number
		limit: number
	}): Promise<[OfficesTableResponseDto[], number]> {
		const officesTableContent: OfficesTableResponseDto[] = []
		this.earTypeDescriptionDomainCache = {}

		const [dianOffices, count]: [DianOffice[], number] =
			await this.dianOfficesService.officesTable({
				earDianId: params.earDianId,
				earType: params.earType,
				earName: params.earName,
				offset: params.offset,
				earId: params.earId,
				limit: params.limit,
				city: params.city,
			})

		// ** info: parsing office entity to dto
		for (const dianOffice of dianOffices) {
			officesTableContent.push(
				await this.officeEntity2TableResponseDto({
					dianOffice: dianOffice,
				})
			)
		}

		this.earTypeDescriptionDomainCache = {}
		return [officesTableContent, count]
	}

	private async officeEntity2TableResponseDto(params: {
		dianOffice: DianOffice
	}): Promise<OfficesTableResponseDto> {
		const cacheKey: string = String(params.dianOffice.earDomainType)
		let earType: string

		if (cacheKey in this.earTypeDescriptionDomainCache) {
			earType = this.earTypeDescriptionDomainCache[cacheKey]
		} else {
			earType = await this.dianDomainService.getDescriptionByDomainId({
				domainId: params.dianOffice.earDomainType,
			})
			this.earTypeDescriptionDomainCache[cacheKey] = earType
		}

		const officeTableContent: OfficesTableResponseDto = {
			earCreationDate: params.dianOffice.creationDate,
			earDianId: params.dianOffice.earDianId,
			earName: params.dianOffice.name,
			earId: params.dianOffice.earId,
			city: params.dianOffice.city,
			earType: earType,
		}

		return officeTableContent
	}

	public async officesList(params: {
		search: number | undefined
	}): Promise<OfficesListResponseDto[]> {
		// todo: replace burned parametrization by params table call
		// ! warning: burned parametrization here [ officesListContent ]
		const officesListContent: OfficesListResponseDto[] = [
			{ value: 99999, viewValue: "Todas las oficinas" },
		]

		const dianOffices: DianOffice[] = await this.dianOfficesService.officesList(
			{ search: params.search }
		)

		// ** info: parsing office entity to dto
		dianOffices.map((dianOffice: DianOffice): void => {
			officesListContent.push(
				this.officeEntity2ListResponseDto({ dianOffice: dianOffice })
			)
		})

		return officesListContent
	}

	private officeEntity2ListResponseDto(params: {
		dianOffice: DianOffice
	}): OfficesListResponseDto {
		const officeTableContent: OfficesListResponseDto = {
			value: params.dianOffice.earId,
			viewValue: `${params.dianOffice.earId} - ${params.dianOffice.name}`,
		}

		return officeTableContent
	}
}
