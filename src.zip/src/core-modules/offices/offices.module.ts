/** @format */

// ** info: nest imports
import { Module } from "@nestjs/common"

// ** info: dian database module import
import { DianDatabaseModule } from "@common-modules/dian-database/dian-database.module"

// ** info: controller and service import
import { OfficesController } from "@core-modules/offices/controllers/offices.controller"
import { OfficesService } from "@core-modules/offices/services/offices.service"

@Module({
	imports: [DianDatabaseModule],
	controllers: [OfficesController],
	providers: [OfficesService],
})
export class OfficesModule {}
