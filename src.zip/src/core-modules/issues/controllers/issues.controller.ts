/** @format */
import {
	Body,
	Controller,
	HttpCode,
	Post,
	Put,
	Req,
	Request,
	UseFilters,
} from "@nestjs/common"

import { posix } from "path"

/**Custom Imports */
import { AllExceptionsFilter } from "@common-artifacts/decorators/all-exceptions.filter"
import { IssuesTableRequest } from "../dtos/issuesTableRequest.dto"
import { IssuesTableResponse } from "../dtos/issuesTableResponse.dto"
import { IssuesService } from "../services/issues.service"
import { DianMovements } from "@common-modules/dian-database/entities/dian-movements.entity"
import { AddIssueRequest } from "../dtos/addIssueRequest.dto"
import { ModifyIssueRequest } from "../dtos/modifyIssueRequest.dto"
import { DianIssues } from "@common-modules/dian-database/entities/dian-issues.entity"
import { ExcludeIssueRequest } from "../dtos/excludeIssueRequest.dto"

// ** info: logger service imports
import { LoggingService } from "@common-artifacts/logger-service/logging.service"

@UseFilters(AllExceptionsFilter)
@Controller("issues")
export class IssuesController {
	public constructor(
		private readonly issuesService: IssuesService,
		private readonly loggingService: LoggingService
	) {}

	@Post(posix.join("issues-table"))
	@HttpCode(200)
	public async filterIssues(
		@Body() issuesTableRequest: IssuesTableRequest,
		@Req() request: Request
	): Promise<IssuesTableResponse> {
		this.loggingService.log(undefined, request)
		return await this.issuesService.filterIssues(issuesTableRequest)
	}

	@HttpCode(201)
	@Post(posix.join("create"))
	public async addIssue(
		@Body() addIssueRequest: AddIssueRequest,
		@Request() req: Request
	): Promise<DianMovements> {
		this.loggingService.log(undefined, req)
		return await this.issuesService.addIssue(addIssueRequest, req)
	}

	@HttpCode(200)
	@Put(posix.join("update"))
	public async modifyIssueById(
		@Body() modifyIssueRequest: ModifyIssueRequest,
		@Request() req: Request
	): Promise<DianIssues> {
		this.loggingService.log(undefined, req)
		return await this.issuesService.updateIssueById(modifyIssueRequest, req)
	}

	@HttpCode(200)
	@Put(posix.join("exclude"))
	public async excludeIssueById(
		@Body() excludeIssueRequest: ExcludeIssueRequest,
		@Request() req: Request
	): Promise<DianIssues> {
		this.loggingService.log(undefined, req)
		return await this.issuesService.excludeIssueById(excludeIssueRequest, req)
	}
}
