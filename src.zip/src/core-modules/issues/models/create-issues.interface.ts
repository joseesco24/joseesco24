/** @format */

export interface CreateIssues {
	issueTypeId: number
	formType: number
	earId: number
	realDate: string
	realHour: string
	declarationNumber: number
	adhesiveOrCus: string
	paymentFormId: number
	paymentValue: number
	formId: number
	conceptId: number
	dayTypeId: number
	nitOrId: number
	operationNumber: number
	hashCode?: number
	tellerCode: string
	limitPaymentDate?: Date
	justification: string
	generationUser: string
	dianModeId: number
	taxId: number
	ip: string
}
