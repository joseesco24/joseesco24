/** @format */
import * as requestIp from "request-ip"

// ** info: Custom Imports */
import {
	consolidatedtypeFormDomain,
	dayTypeIssuesDomain,
	dianModeDomain,
	excludeTypeDomainId,
	maxLimitIssuesDomain,
	maxLimitIssuesDomainId,
	modificationTypeDomainId,
} from "@common-artifacts/constants/constants"
import { IssuesDataCount } from "@common-modules/dian-database/dtos/issuesDataCount.dto"
import { DianDomainService } from "@common-modules/dian-database/services/dian-domain.service"
import { DianIssuesService } from "@common-modules/dian-database/services/dian-issues.service"
import { DianUtilsService } from "@common-modules/dian-utils/services/dian-utils.service"
import {
	BadRequestException,
	Injectable,
	InternalServerErrorException,
} from "@nestjs/common"
import { IssuesFoundDataRes } from "../dtos/issuesFoundDataRes.dto"
import { IssuesTableRequest } from "../dtos/issuesTableRequest.dto"
import { IssuesTableResponse } from "../dtos/issuesTableResponse.dto"
import { AddIssueRequest } from "../dtos/addIssueRequest.dto"
import { DianMovements } from "@common-modules/dian-database/entities/dian-movements.entity"
import { DianOfficesService } from "@common-modules/dian-database/services/dian-offices.service"
import { ValidationException } from "@common-artifacts/decorators/validation.filter"
import { DianTaxService } from "@common-modules/dian-database/services/dian-tax.service"
import { CreateIssues } from "../models/create-issues.interface"
import { DianMovementsService } from "@common-modules/dian-database/services/dian-movements.service"
import { ModifyIssueRequest } from "../dtos/modifyIssueRequest.dto"
import { FoundIssueByIdMod } from "@common-modules/dian-database/dtos/foundIssueByIdMod.dto"
import { DianIssues } from "@common-modules/dian-database/entities/dian-issues.entity"
import { ExcludeIssueRequest } from "../dtos/excludeIssueRequest.dto"
import { FoundIssueByIdExc } from "@common-modules/dian-database/dtos/foundIssueByIdExc.dto"

@Injectable()
export class IssuesService {
	public constructor(
		private readonly dianDomainService: DianDomainService,
		private readonly dianIssuesService: DianIssuesService,
		private readonly dianUtils: DianUtilsService,
		private readonly dianEarService: DianOfficesService,
		private readonly dianTaxService: DianTaxService,
		private readonly dianMovService: DianMovementsService
	) {}

	public async filterIssues(
		issuesTableRequest: IssuesTableRequest
	): Promise<IssuesTableResponse> {
		const maxLimit: number = Number(
			(
				await this.dianDomainService.getValueDescriptionByDomain(
					maxLimitIssuesDomainId,
					maxLimitIssuesDomain
				)
			).realValue
		)

		if (issuesTableRequest.limit > maxLimit) {
			throw new BadRequestException("limit exceeded")
		} else {
			//get issue table data and count
			const dataCount: IssuesDataCount =
				await this.dianIssuesService.filterIssues(issuesTableRequest)

			try {
				const dataResponseArray: IssuesFoundDataRes[] = []
				const dataLength: number = dataCount.data.length
				let response: IssuesTableResponse

				if (dataLength === 0) {
					//build response schema if no data
					response = {
						count: dataCount.count,
						data: [],
					}
				} else {
					//parse reportId to modifiable boolean
					dataCount.data.map(async (issue: any, index: any) => {
						let modifiableRes: boolean
						//modifiable set
						if (
							issue.reportId1188 !== null ||
							issue.reportId1740 !== null ||
							issue.exclude
						) {
							modifiableRes = false
						} else {
							modifiableRes = true
						}

						//systemDate set
						const systemDateFormat: string =
							await this.dianUtils.formatDateHour(
								new Date(issue.realDate),
								false
							)

						//lastModification set
						const lastModDateFormat: string =
							await this.dianUtils.formatDateHour(
								new Date(issue.lastModificationDate),
								true
							)

						const paymentValue: string = issue.paymentValue

						const dataResponse: IssuesFoundDataRes = {
							issueType: issue.issueType,
							formId: issue.formId,
							conceptId: issue.conceptId,
							paymentValue: `$${paymentValue}`,
							earId: String(issue.earId),
							declarationNumber: issue.declarationNumber,
							adhesiveOrCus: issue.adhesiveOrCus,
							formType: issue.formType,
							realDate: systemDateFormat,
							dayType: issue.dayType,
							modificationUser: issue.modificationUser,
							lastModificationDate: lastModDateFormat,
							movementId: issue.movementId,
							modifiable: modifiableRes,
						}
						dataResponseArray.push(dataResponse)

						//sort to show modifieble true first
						if (index === dataLength - 1) {
							dataResponseArray.sort(
								(a: any, b: any) => Number(b.modifiable) - Number(a.modifiable)
							)
						}
					})

					//build response schema if data
					response = {
						count: dataCount.count,
						data: dataResponseArray,
					}
				}
				return response
			} catch (e: any) {
				throw new InternalServerErrorException(e.message)
			}
		}
	}

	public async addIssue(
		addIssueRequest: AddIssueRequest,
		request: any
	): Promise<DianMovements> {
		//data validation
		const saveIssueRequest: CreateIssues = await this.addIssueDataValidation(
			addIssueRequest
		)

		//obtain Ip
		const currentIp: string = requestIp
			.getClientIp(request)
			.toString()
			.replace("::ffff:", "")
		//update movement and obtain movement saved
		saveIssueRequest["ip"] = currentIp
		const movementResponse: DianMovements =
			await this.dianIssuesService.saveIssue(saveIssueRequest)

		return movementResponse
	}

	public async updateIssueById(
		modifyIssueRequest: ModifyIssueRequest,
		request: any
	): Promise<DianIssues> {
		//validate if movement id is already included in mov table
		const issueFoundRaw: FoundIssueByIdMod =
			await this.dianIssuesService.getIssueByIdMod(
				modifyIssueRequest.movementId
			)
		let parsedPaymentValue: number

		if (issueFoundRaw === undefined) {
			throw new ValidationException(
				"Bad Request. Datos de entrada no validos: movementId"
			)
		} else {
			parsedPaymentValue = Number(issueFoundRaw.paymentValuePesos)
			//Verify if any of the values is different from those in DB

			modifyIssueRequest.paymentValue = Number(modifyIssueRequest.paymentValue)

			if (
				modifyIssueRequest.declarationNumber ==
					issueFoundRaw.declarationNumber &&
				modifyIssueRequest.paymentValue == parsedPaymentValue
			) {
				throw new BadRequestException(
					"Los datos enviados no modifican los datos en Base de datos"
				)
			}
		}
		const currentIp: string = requestIp
			.getClientIp(request)
			.toString()
			.replace("::ffff:", "")

		return await this.dianIssuesService.updateIssue(
			modifyIssueRequest,
			currentIp,
			modificationTypeDomainId,
			issueFoundRaw
		)
	}

	public async excludeIssueById(
		excludeIssueRequest: ExcludeIssueRequest,
		request: any
	): Promise<DianIssues> {
		const issueFoundRaw: FoundIssueByIdExc =
			await this.dianIssuesService.getIssueByIdExc(
				excludeIssueRequest.movementId
			)

		if (issueFoundRaw === undefined) {
			throw new BadRequestException(
				"El movimiento no puede ser excluido o ya se encuentra excluido"
			)
		} else {
			if (issueFoundRaw.exclude) {
				throw new BadRequestException(
					"Los datos enviados no modifican los datos en Base de datos"
				)
			}
		}

		const currentIp: string = requestIp
			.getClientIp(request)
			.toString()
			.replace("::ffff:", "")

		return await this.dianIssuesService.excludeIssue(
			excludeIssueRequest,
			currentIp,
			excludeTypeDomainId,
			issueFoundRaw
		)
	}

	public async addIssueDataValidation(
		addIssueRequest: AddIssueRequest
	): Promise<CreateIssues> {
		const errors: string[] = ["Datos inválidos: "]

		const response: object = {}

		// ** info: duplicate key validation
		try {
			const realDayType: any = await this.dianMovService.getContraintKeys({
				adhesiveOrCus: addIssueRequest.adhesiveOrCus
					? addIssueRequest.adhesiveOrCus
					: null,
				declarationNumber: Number(addIssueRequest.declarationNumber),
			})
			if (realDayType) {
				errors.push("Movimiento ya ha sido creado,")
			}
		} catch (e) {
			errors.push("Movimiento ya ha sido creado,")
		}

		response["adhesiveOrCus"] = addIssueRequest.adhesiveOrCus
			? addIssueRequest.adhesiveOrCus
			: null
		response["generationUser"] = addIssueRequest.generationUser
		response["justification"] = addIssueRequest.justification

		response["formId"] = addIssueRequest.formId ? addIssueRequest.formId : null

		response["conceptId"] = addIssueRequest.conceptId
			? addIssueRequest.conceptId
			: null
		response["tellerCode"] = addIssueRequest.tellerCode
			? addIssueRequest.tellerCode
			: null

		// ** info: nit or id Validation
		try {
			response["nitOrId"] = Number(addIssueRequest.nitOrId)
		} catch (e) {
			errors.push("Nit o Id no válido,")
		}
		// ** info: Operation Number Validation
		try {
			response["operationNumber"] = Number(addIssueRequest.operationNumber)
		} catch (e) {
			errors.push("Numero de Operación no válido,")
		}
		// ** info: Hash Code Validation
		try {
			response["hashCode"] = Number(addIssueRequest.hashNumber)
		} catch (e) {
			errors.push("Número hash  no valido,")
		}
		// ** Payment Value Validation
		try {
			response["paymentValue"] = Number(addIssueRequest.paymentValue)
		} catch (e) {
			errors.push("Valor recaudado no válido,")
		}

		// ** Declaration Number Validation
		try {
			response["declarationNumber"] = Number(addIssueRequest.declarationNumber)
		} catch (e) {
			errors.push("Número declaración no válido,")
		}

		// ** Payment Date Limit Validation
		try {
			if (addIssueRequest.limitPaymentDate !== undefined) {
				response["limitPaymentDate"] = new Date(
					addIssueRequest.limitPaymentDate
				)
			}
		} catch (e) {
			errors.push("Fecha limite de pago no válido,")
		}
		// ** info: dayType validation and realValue assignation
		try {
			const realDayType: string =
				await this.dianDomainService.getRealValueByDomainId(
					addIssueRequest.dayTypeId,
					dayTypeIssuesDomain
				)
			response["dayTypeId"] = Number(realDayType)
		} catch (e) {
			errors.push("Fecha de recaudo no válido,")
		}

		// ** info: Tax Validation */
		try {
			const taxFoundRaw: any = await this.dianTaxService.getTaxIdByIndexes(
				addIssueRequest.formId,
				addIssueRequest.conceptId,
				addIssueRequest.dianModeId
			)
			if (taxFoundRaw === undefined) {
				errors.push(
					"impuesto no existe. Motivo ó concepto ó modalidad dian no válido,"
				)
			}
			response["taxId"] = taxFoundRaw.dian_impuestos_codigo_impuesto
		} catch (e) {
			errors.push(" Motivo ó concepto ó modalidad dian no válido,")
		}

		// ** info: dianModeId validation
		try {
			const dianModeValidator: string =
				await this.dianDomainService.getRealValueByDomainId(
					addIssueRequest.dianModeId,
					dianModeDomain
				)
			response["dianModeId"] = Number(dianModeValidator)
		} catch (e) {
			errors.push("modalidad dian no válido,")
		}

		//earId validation
		const officeRaw: any[] = await this.dianEarService.findOfficeById(
			addIssueRequest.earId
		)
		if (officeRaw === undefined) {
			errors.push("Código oficina no válido,")
		}
		response["earId"] = addIssueRequest.earId

		// ** info: Form Type validation */
		try {
			const formTypeValidation: string =
				await this.dianDomainService.getRealValueByDomainId(
					addIssueRequest.formType,
					consolidatedtypeFormDomain
				)
			response["formType"] = Number(formTypeValidation)
		} catch (e) {
			errors.push("Tipo formulario No valido,")
		}

		// ** info: Payment method validation */
		try {
			response["paymentFormId"] = Number(addIssueRequest.paymentFormId)
		} catch (e) {
			errors.push("Forma de pago no válido,")
		}

		// ** info: RealDate validation */
		try {
			const realDateValidation: Date = new Date(addIssueRequest.realDate)
			response["realDate"] = realDateValidation.toISOString()
			response["realHour"] = realDateValidation.toLocaleTimeString("it-IT")
		} catch (e) {
			errors.push("Fecha no válida,")
		}

		// ** info: build response
		if (errors.length === 1) {
			return response as CreateIssues
		} else {
			const message: string = errors.join("")
			const messagePrettier: string = message.substring(0, message.length - 1)
			throw new ValidationException(messagePrettier)
		}
	}
}
