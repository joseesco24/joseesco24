/** @format */

import {
	IsInt,
	IsNotEmpty,
	IsNumberString,
	IsOptional,
	IsString,
	MaxLength,
} from "class-validator"

export class AddIssueRequest {
	@IsNotEmpty()
	@IsInt()
	public formType: number

	@IsNotEmpty()
	@IsInt()
	public earId!: number

	@IsNotEmpty()
	@IsString()
	public realDate!: string

	@IsNotEmpty()
	@IsString()
	public declarationNumber: string

	@IsOptional()
	@IsString()
	@MaxLength(16)
	public adhesiveOrCus!: string

	@IsNotEmpty()
	@IsInt()
	public paymentFormId!: number

	@IsOptional()
	@IsNumberString()
	public paymentValue!: string | number

	@IsNotEmpty()
	@IsInt()
	public formId!: number

	@IsNotEmpty()
	@IsInt()
	public conceptId!: number

	@IsNotEmpty()
	@IsInt()
	public dayTypeId!: number

	@IsNotEmpty()
	@IsNumberString()
	@MaxLength(16)
	public nitOrId!: string | number

	@IsOptional()
	@IsNotEmpty()
	@IsNumberString()
	public operationNumber!: string | number

	@IsOptional()
	@IsNotEmpty()
	@IsNumberString()
	@MaxLength(8)
	public hashNumber?: string

	@IsNotEmpty()
	@IsString()
	public tellerCode: string

	@IsString()
	@IsNotEmpty()
	@IsOptional()
	public limitPaymentDate?: string

	@IsNotEmpty()
	@IsString()
	@MaxLength(100)
	public justification!: string

	@IsNotEmpty()
	@IsString()
	@MaxLength(60)
	public generationUser!: string

	@IsNotEmpty()
	@IsInt()
	public dianModeId!: number
}
