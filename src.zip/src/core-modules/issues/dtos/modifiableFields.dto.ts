/** @format */

import { IsBoolean } from "class-validator"

export class ModifiableFields {
	@IsBoolean()
	public taxName!: boolean

	@IsBoolean()
	public adhesiveNumber!: boolean

	@IsBoolean()
	public referenceNumber!: boolean

	@IsBoolean()
	public accountNumber!: boolean

	@IsBoolean()
	public paymentValue!: boolean

	@IsBoolean()
	public dayTypeDescription!: boolean

	@IsBoolean()
	public earId!: boolean

	@IsBoolean()
	public contributionIndicator!: boolean

	@IsBoolean()
	public channelInd!: boolean

	@IsBoolean()
	public paymentMethod!: boolean

	@IsBoolean()
	public systemDate!: boolean

	@IsBoolean()
	public operationNumber!: boolean

	@IsBoolean()
	public authorizationNumber!: boolean

	@IsBoolean()
	public contributorId!: boolean

	@IsBoolean()
	public limitPaymentDate!: boolean

	@IsBoolean()
	public hashNumber!: boolean

	@IsBoolean()
	public iacCode!: boolean

	@IsBoolean()
	public terminalId!: boolean

	@IsBoolean()
	public movementId!: number
}
