/** @format */

import { Transform } from "class-transformer"
import { IsInt } from "class-validator"

export class IssuesByIdRequest {
	@Transform((param: any) => Number(param.value))
	@IsInt()
	public movementId!: number
}
