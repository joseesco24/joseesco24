/** @format */

import { IsBoolean, IsNotEmpty, IsString } from "class-validator"

export class TitleTableColumns {
	@IsString()
	@IsNotEmpty()
	public columnDef!: string

	@IsString()
	@IsNotEmpty()
	public header!: string

	@IsBoolean()
	@IsNotEmpty()
	public filter!: boolean
}
