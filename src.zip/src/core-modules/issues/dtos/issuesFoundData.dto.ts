/** @format */

import {
	IsBoolean,
	IsInt,
	IsNotEmpty,
	IsNumber,
	IsNumberString,
	IsString,
} from "class-validator"

export class IssuesFoundData {
	@IsNotEmpty()
	@IsString()
	public issueType!: string

	@IsNotEmpty()
	@IsInt()
	public formId!: number

	@IsNotEmpty()
	@IsInt()
	public conceptId!: number

	@IsNotEmpty()
	@IsString()
	public paymentValue!: string

	@IsNotEmpty()
	@IsNumberString()
	public earId!: string | number

	@IsNotEmpty()
	@IsNumberString()
	public declarationNumber!: string | number

	@IsNotEmpty()
	@IsNumberString()
	public adhesiveOrCus!: string | number

	@IsNotEmpty()
	@IsString()
	public formType!: string

	@IsNotEmpty()
	@IsString()
	public realDate!: string

	@IsNotEmpty()
	@IsString()
	public dayType!: string

	@IsNotEmpty()
	@IsString()
	public modificationUser!: string

	@IsNotEmpty()
	@IsString()
	public lastModificationDate!: string

	@IsNotEmpty()
	@IsNumber()
	public movementId!: number

	@IsNotEmpty()
	@IsBoolean()
	public modifiable!: boolean

	@IsNumber()
	@IsBoolean()
	public reportId1188!: number

	@IsNumber()
	@IsBoolean()
	public reportId1740!: number

	@IsNotEmpty()
	@IsBoolean()
	public exclude!: boolean
}
