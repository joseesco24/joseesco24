/** @format */

import { Type } from "class-transformer"
import { IsNotEmpty } from "class-validator"
import { FindIssueDataRes } from "./findIssueDataRes.dto"
import { TitleTableColumns } from "./titleTableColumns.dto"

export class FindIssueResponse {
	@Type(() => FindIssueDataRes)
	@IsNotEmpty()
	public data!: FindIssueDataRes[]

	@Type(() => TitleTableColumns)
	@IsNotEmpty()
	public columns!: TitleTableColumns[]
}
