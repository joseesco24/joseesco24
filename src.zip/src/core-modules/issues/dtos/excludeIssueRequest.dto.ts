/** @format */

import { IsInt, IsNotEmpty, IsString } from "class-validator"

export class ExcludeIssueRequest {
	@IsNotEmpty()
	@IsString()
	public justification: string

	@IsNotEmpty()
	@IsInt()
	public movementId: number

	@IsNotEmpty()
	@IsString()
	public generationUser: string
}
