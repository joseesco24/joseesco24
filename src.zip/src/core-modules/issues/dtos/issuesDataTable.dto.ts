/** @format */

import {
	IsBoolean,
	IsNotEmpty,
	IsNumber,
	IsNumberString,
	IsString,
} from "class-validator"

export class IssuesDataTable {
	@IsNotEmpty()
	@IsString()
	public inconsistencyType!: string

	@IsNotEmpty()
	@IsString()
	public adhesiveNumber!: string

	@IsNotEmpty()
	@IsString()
	public referenceNumber!: string

	@IsNotEmpty()
	@IsString()
	public paymentValue!: string

	@IsNotEmpty()
	@IsNumberString()
	public earId!: string | number

	@IsNotEmpty()
	@IsString()
	public systemDate!: string

	@IsNotEmpty()
	@IsString()
	public taxName!: string

	@IsNotEmpty()
	@IsString()
	public dayTypeDescription!: string

	@IsNotEmpty()
	@IsString()
	public generationUser!: string

	@IsNotEmpty()
	@IsString()
	public justification!: string

	@IsNotEmpty()
	@IsString()
	public lastModificationDate!: string

	@IsNotEmpty()
	@IsNumber()
	public movementId!: number

	@IsNotEmpty()
	@IsBoolean()
	public modifiable!: boolean
}
