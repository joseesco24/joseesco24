/** @format */

import {
	IsInt,
	IsNotEmpty,
	IsNumberString,
	IsOptional,
	IsString,
	MaxLength,
} from "class-validator"

export class ModifyIssueRequest {
	@IsNotEmpty()
	@IsNumberString()
	@MaxLength(16)
	public nitOrId!: string | number

	@IsNotEmpty()
	@IsNumberString()
	@MaxLength(19)
	public declarationNumber!: string

	@IsOptional()
	@IsNumberString()
	public paymentValue!: string | number

	@IsNotEmpty()
	@IsString()
	@MaxLength(100)
	public justification!: string

	@IsNotEmpty()
	@IsInt()
	public movementId!: number

	@IsNotEmpty()
	@IsString()
	@MaxLength(60)
	public generationUser!: string

	@IsNotEmpty()
	@IsInt()
	@IsOptional()
	public formType: number

	@IsNotEmpty()
	@IsInt()
	@IsOptional()
	public earId!: number

	@IsNotEmpty()
	@IsString()
	@IsOptional()
	public realDate!: string

	@IsNotEmpty()
	@IsString()
	@IsOptional()
	public referenceNumber: string

	@IsOptional()
	@IsNumberString()
	@MaxLength(16)
	public adhesiveOrCus!: string | number

	@IsNotEmpty()
	@IsInt()
	@IsOptional()
	public paymentFormId!: number

	@IsNotEmpty()
	@IsInt()
	@IsOptional()
	public formId!: number

	@IsNotEmpty()
	@IsInt()
	@IsOptional()
	public conceptId!: number

	@IsNotEmpty()
	@IsInt()
	@IsOptional()
	public dayTypeId!: number

	@IsOptional()
	public operationNumber!: string | number

	@IsOptional()
	@IsNotEmpty()
	@IsNumberString()
	@MaxLength(8)
	public hashNumber?: string

	@IsNotEmpty()
	@IsString()
	@IsOptional()
	public tellerCode: string

	@IsString()
	@IsOptional()
	public limitPaymentDate?: string

	@IsNotEmpty()
	@IsInt()
	@IsOptional()
	public dianModeId!: number

	@IsString()
	@IsOptional()
	public authorizationNumber: string
}
