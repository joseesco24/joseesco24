/** @format */

import { IsNotEmpty, IsString } from "class-validator"

export class FindIssueRequest {
	@IsNotEmpty()
	@IsString()
	public search!: string
}
