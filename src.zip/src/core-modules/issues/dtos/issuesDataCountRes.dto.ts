/** @format */

import { Type } from "class-transformer"
import { IsNotEmpty, IsNumber } from "class-validator"
import { IssuesFoundDataRes } from "./issuesFoundDataRes.dto"

export class IssuesDataCountRes {
	@IsNumber()
	@IsNotEmpty()
	public count!: number

	@Type(() => IssuesFoundDataRes)
	@IsNotEmpty()
	public data!: IssuesFoundDataRes[]
}
