/** @format */

import { IsBoolean, IsNotEmpty, IsNumber, IsString } from "class-validator"

export class FindIssueDataRes {
	@IsNotEmpty()
	@IsString()
	public adhesiveNumber!: string

	@IsNotEmpty()
	@IsString()
	public referenceNumber!: string

	@IsNotEmpty()
	@IsString()
	public accountNumber!: string

	@IsNotEmpty()
	@IsString()
	public paymentValue!: string

	@IsNotEmpty()
	@IsString()
	public channelInd!: string

	@IsNotEmpty()
	@IsString()
	public systemDate!: string

	@IsNotEmpty()
	@IsString()
	public dayTypeDescription!: string

	@IsNotEmpty()
	@IsBoolean()
	public modifiable!: boolean

	@IsNotEmpty()
	@IsNumber()
	public movementId!: number
}
