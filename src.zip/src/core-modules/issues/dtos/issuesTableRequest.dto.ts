/** @format */

import { IsInt, IsNotEmpty, IsOptional, IsString } from "class-validator"

export class IssuesTableRequest {
	@IsOptional()
	@IsString()
	public issueType?: string

	@IsOptional()
	@IsString()
	public formId?: string

	@IsOptional()
	@IsString()
	public conceptId?: string

	@IsOptional()
	@IsString()
	public earId?: string

	@IsOptional()
	@IsString()
	public declarationNumber?: string

	@IsOptional()
	@IsString()
	public adhesiveOrCus?: string

	@IsOptional()
	@IsString()
	public formType?: string

	@IsOptional()
	@IsString()
	public realDate?: string

	@IsInt()
	@IsNotEmpty()
	public limit!: number

	@IsInt()
	@IsNotEmpty()
	public offset!: number
}
