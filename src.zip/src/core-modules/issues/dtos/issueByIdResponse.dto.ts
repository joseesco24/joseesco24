/** @format */

import { FoundIssueByIdMod } from "@common-modules/dian-database/dtos/foundIssueByIdMod.dto"
import { Type } from "class-transformer"
import { IsNotEmpty } from "class-validator"
import { ModifiableFields } from "./modifiableFields.dto"

export class IssuesByIdResponse {
	@Type(() => FoundIssueByIdMod)
	@IsNotEmpty()
	public data!: FoundIssueByIdMod

	public modifiableFields!: ModifiableFields
}
