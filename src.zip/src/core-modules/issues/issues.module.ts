/** @format */
import { Module } from "@nestjs/common"

/** Custom Imports */
import { DianDatabaseModule } from "@common-modules/dian-database/dian-database.module"
import { DianUtilsModule } from "@common-modules/dian-utils/dian-utils.module"
import { IssuesController } from "./controllers/issues.controller"
import { IssuesService } from "./services/issues.service"

@Module({
	imports: [DianDatabaseModule, DianUtilsModule],
	controllers: [IssuesController],
	providers: [IssuesService],
})
export class IssuesModule {}
