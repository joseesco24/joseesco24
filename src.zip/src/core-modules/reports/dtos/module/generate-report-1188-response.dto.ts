/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsBoolean } from "class-validator"
import { IsDefined } from "class-validator"
import { IsString } from "class-validator"
import { IsArray } from "class-validator"
import { IsInt } from "class-validator"
import { Min } from "class-validator"

// todo: implement class transformer transformations here
export class GenerateReport1188ResponseDto {
	@IsDefined()
	@IsArray()
	public data!: Report1188ResponsedataDto[]
}

export class Report1188ResponsedataDto {
	@IsString()
	@IsNotEmpty()
	public reportType!: string

	@IsString()
	@IsNotEmpty()
	public realDate!: string

	@IsBoolean()
	@IsNotEmpty()
	public status!: boolean

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public reciprocityDays!: number

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public consignedInterests!: number

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public consignedSanctions!: number

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public notConsignedInterests!: number

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public notConsignedSanctions!: number

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public reportId1188!: number
}
