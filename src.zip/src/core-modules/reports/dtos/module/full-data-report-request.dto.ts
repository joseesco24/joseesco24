/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsString } from "class-validator"
import { Matches } from "class-validator"

// todo: implement class transformer transformations here
export class FullDataReportRequetDto {
	@IsString()
	@Matches(RegExp("^[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}$"))
	@IsNotEmpty()
	public readonly start!: string
}
