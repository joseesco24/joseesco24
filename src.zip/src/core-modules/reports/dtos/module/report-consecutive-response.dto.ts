/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsInt } from "class-validator"
import { Min } from "class-validator"

export class ReportConsecutiveResponseDto {
	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public consecutive!: number
}
