/** @format */

// ** info: inheritable dtos imports
import { ReportsHistoricalsTableBaseRequestDto } from "@core-modules/reports/dtos/inheritables/reports-historicals-table-base-request.dto"

// todo: implement class transformer transformations here
export class ReportsHistoricalsTable1188RequestDto extends ReportsHistoricalsTableBaseRequestDto {}
