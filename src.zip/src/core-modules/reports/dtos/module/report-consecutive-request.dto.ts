/** @format */

// ** info: class validator imports
import { IsNumberString } from "class-validator"
import { IsNotEmpty } from "class-validator"
import { IsString } from "class-validator"

export class ReportConsecutiveRequestDto {
	@IsString()
	@IsNumberString()
	@IsNotEmpty()
	public reportId!: number
}
