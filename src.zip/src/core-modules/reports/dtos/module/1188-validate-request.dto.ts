/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsString } from "class-validator"
import { IsNumber } from "class-validator"
import { Matches } from "class-validator"
import { IsInt } from "class-validator"
import { Min } from "class-validator"

// todo: implement class transformer transformations here
export class Validate1188RequestDto {
	@IsString()
	@Matches(RegExp("^[0-9]{4}-[0-9]{1,2}$"))
	@IsNotEmpty()
	public readonly reportDate!: string

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public readonly consecutive!: number

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public readonly reciprocityDays!: number

	@IsNumber()
	@Min(0)
	@IsNotEmpty()
	public readonly consignedInterests!: number

	@IsNumber()
	@Min(0)
	@IsNotEmpty()
	public readonly consignedSanctions!: number

	@IsNumber()
	@Min(0)
	@IsNotEmpty()
	public readonly notConsignedInterests!: number

	@IsNumber()
	@Min(0)
	@IsNotEmpty()
	public readonly notConsignedSanctions!: number
}
