/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsBoolean } from "class-validator"
import { IsDefined } from "class-validator"
import { IsString } from "class-validator"
import { IsArray } from "class-validator"
import { IsInt } from "class-validator"
import { Min } from "class-validator"

// todo: implement class transformer transformations here
export class GenerateReport1740ResponseDto {
	@IsDefined()
	@IsArray()
	public data!: Report1740ResponsedataDto[]
}

export class Report1740ResponsedataDto {
	@IsString()
	@IsNotEmpty()
	public reportType!: string

	@IsString()
	@IsNotEmpty()
	public realDate!: string

	@IsString()
	@IsNotEmpty()
	public generationDate!: string

	@IsString()
	@IsNotEmpty()
	public news!: string

	@IsBoolean()
	@IsNotEmpty()
	public status!: boolean

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public consecutive!: number

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public reportId1740!: number
}
