/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsString } from "class-validator"
import { IsInt } from "class-validator"

export class ExcelColumn {
	@IsString()
	@IsNotEmpty()
	public header!: string

	@IsInt()
	@IsNotEmpty()
	public width!: number
}
