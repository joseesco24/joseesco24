/** @format */

// ** info: inheritable dtos imports
import { DownloadReportByIdBaseRequestDto } from "@core-modules/reports/dtos/inheritables/download-report-by-id-base-request.dto"

// todo: implement class transformer transformations here
export class DownloadReport1188ByRequestDto extends DownloadReportByIdBaseRequestDto {}
