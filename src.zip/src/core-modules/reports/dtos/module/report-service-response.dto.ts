/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsNumber } from "class-validator"
import { IsString } from "class-validator"

export class ReportServiceResponseDto {
	@IsNumber()
	@IsNotEmpty()
	public id!: number

	@IsString()
	@IsNotEmpty()
	public report!: string

	@IsString()
	@IsNotEmpty()
	public name!: string
}
