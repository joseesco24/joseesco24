/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsString } from "class-validator"
import { Matches } from "class-validator"
import { IsInt } from "class-validator"
import { Min } from "class-validator"

// ** info: inheritable dtos imports
import { GenerateReportBaseRequestDto } from "@core-modules/reports/dtos/inheritables/generate-report-base-request.dto"

// todo: implement class transformer transformations here
export class GenerateReport1188RequestDto extends GenerateReportBaseRequestDto {
	@IsString()
	@Matches(RegExp("^[0-9]{4}-[0-9]{1,2}$"))
	@IsNotEmpty()
	public reportDate!: string

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public reciprocityDays!: number

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public consignedInterests!: number

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public consignedSanctions!: number

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public notConsignedInterests!: number

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public notConsignedSanctions!: number
}
