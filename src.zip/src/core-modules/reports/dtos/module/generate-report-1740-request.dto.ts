/** @format */

// ** info: inheritable dtos imports
import { GenerateReportBaseRequestDto } from "@core-modules/reports/dtos/inheritables/generate-report-base-request.dto"

// todo: implement class transformer transformations here
export class GenerateReport1740RequestDto extends GenerateReportBaseRequestDto {}
