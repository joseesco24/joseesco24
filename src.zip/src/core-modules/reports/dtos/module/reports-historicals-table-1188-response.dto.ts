/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsDefined } from "class-validator"
import { IsString } from "class-validator"
import { IsArray } from "class-validator"
import { IsInt } from "class-validator"
import { Min } from "class-validator"

// ** info: inheritable dtos imports
import { ReportsHistoricalsTableBaseResponseDto } from "@core-modules/reports/dtos/inheritables/reports-historicals-table-base-response.dto"
import { ReportsHistoricalsTableBaseDataDto } from "@core-modules/reports/dtos/inheritables/reports-historicals-table-base-response.dto"

// todo: implement class transformer transformations here
export class ReportsHistoricalsTable1188ResponseDto extends ReportsHistoricalsTableBaseResponseDto {
	@IsDefined()
	@IsArray()
	public data!: ReportsHistoricalsTable1188DataDto[]
}

export class ReportsHistoricalsTable1188DataDto extends ReportsHistoricalsTableBaseDataDto {
	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public reportId1188!: number

	@IsString()
	@IsNotEmpty()
	public correction!: string
}
