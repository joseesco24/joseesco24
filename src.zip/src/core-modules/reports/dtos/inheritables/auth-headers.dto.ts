/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsString } from "class-validator"

// todo: implement class transformer transformations here
export class AuthHeadersDto {
	@IsString()
	@IsNotEmpty()
	public jwt!: string

	@IsString()
	@IsNotEmpty()
	public iv!: string
}
