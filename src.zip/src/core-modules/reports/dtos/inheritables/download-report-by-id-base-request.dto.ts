/** @format */

// ** info: class validator imports
import { IsNumberString } from "class-validator"
import { IsNotEmpty } from "class-validator"
import { IsString } from "class-validator"

// todo: implement class transformer transformations here
export class DownloadReportByIdBaseRequestDto {
	@IsString()
	@IsNumberString()
	@IsNotEmpty()
	public reportId!: number
}
