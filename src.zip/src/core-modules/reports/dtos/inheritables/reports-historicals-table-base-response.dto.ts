/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsDefined } from "class-validator"
import { IsString } from "class-validator"
import { IsArray } from "class-validator"
import { Matches } from "class-validator"
import { IsInt } from "class-validator"
import { Min } from "class-validator"

// todo: implement class transformer transformations here
export class ReportsHistoricalsTableBaseResponseDto {
	@IsDefined()
	@IsArray()
	public data!: ReportsHistoricalsTableBaseDataDto[]

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public count!: number
}

// todo: implement class transformer transformations here
export class ReportsHistoricalsTableBaseDataDto {
	@IsString()
	@Matches(RegExp("^[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}$"))
	@IsNotEmpty()
	public realDate!: string

	@IsString()
	@IsNotEmpty()
	public reportName!: string

	@IsString()
	@IsNotEmpty()
	public reportType!: string

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public consecutive!: number

	@IsString()
	@IsNotEmpty()
	public news!: string

	@IsString()
	@Matches(
		RegExp("^[0-9]{1,2}/[0-9]{1,2}/[0-9]{4} [0-9]{2}:[0-9]{2}:[0-9]{2}$")
	)
	@IsNotEmpty()
	public generationDate!: string

	@IsString()
	@IsNotEmpty()
	public generationUser!: string
}
