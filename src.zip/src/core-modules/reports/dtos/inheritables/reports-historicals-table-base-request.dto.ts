/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsOptional } from "class-validator"
import { IsString } from "class-validator"
import { Matches } from "class-validator"
import { IsInt } from "class-validator"
import { Min } from "class-validator"

// todo: implement class transformer transformations here
export class ReportsHistoricalsTableBaseRequestDto {
	@IsString()
	@Matches(RegExp("^[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}$"))
	@IsOptional()
	public readonly startDate: string | undefined = undefined

	@IsString()
	@Matches(RegExp("^[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}$"))
	@IsOptional()
	public readonly endDate: string | undefined = undefined

	@IsInt()
	@Min(0)
	@IsOptional()
	public readonly consecutive: number | undefined = undefined

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public readonly limit!: number

	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public readonly offset!: number
}
