/** @format */

// ** info: nest imports
import { Module } from "@nestjs/common"

// ** info: dian database module import
import { DianDatabaseModule } from "@common-modules/dian-database/dian-database.module"

// ** info: controller and service import
import { ReportsController } from "@core-modules/reports/controllers/reports.controller"
import { ReportsService } from "@core-modules/reports/services/reports.service"

// ** info: dian storage module import
import { DianStorageModule } from "@common-modules/dian-storage/dian-storage.module"

// ** info: nest axios
import { HttpModule } from "@nestjs/axios"

@Module({
	imports: [
		HttpModule.register({
			timeout: 5000,
			maxRedirects: 5,
		}),
		DianDatabaseModule,
		DianStorageModule,
	],
	controllers: [ReportsController],
	providers: [ReportsService],
})
export class ReportsModule {}
