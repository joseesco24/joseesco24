/** @format */

// ** info: node imports
import { posix } from "path"

// ** info: nest commons imports
import { BadRequestException } from "@nestjs/common"
import { Controller } from "@nestjs/common"
import { HttpStatus } from "@nestjs/common"
import { HttpCode } from "@nestjs/common"
import { Headers } from "@nestjs/common"
import { Logger } from "@nestjs/common"
import { Query } from "@nestjs/common"
import { Param } from "@nestjs/common"
import { Body } from "@nestjs/common"
import { Post } from "@nestjs/common"
import { Get } from "@nestjs/common"
import { Res } from "@nestjs/common"
import { Req } from "@nestjs/common"

// ** info: express imports
import { Response } from "express"

// ** info: reports service import
import { ReportsService } from "@core-modules/reports/services/reports.service"

// ** info: response dto's imports
import { ReportsHistoricalsTable1188ResponseDto } from "@core-modules/reports/dtos/module/reports-historicals-table-1188-response.dto"
import { ReportsHistoricalsTable1740ResponseDto } from "@core-modules/reports/dtos/module/reports-historicals-table-1740-response.dto"
import { SummaryReportValidateResponseDto } from "@core-modules/reports/dtos/module/summary-report-validate-response.dto"
import { GenerateReport1188ResponseDto } from "@core-modules/reports/dtos/module/generate-report-1188-response.dto"
import { GenerateReport1740ResponseDto } from "@core-modules/reports/dtos/module/generate-report-1740-response.dto"
import { ReportConsecutiveResponseDto } from "@core-modules/reports/dtos/module/report-consecutive-response.dto"
import { Validate1188ResponseDto } from "@core-modules/reports/dtos/module/1188-validate-response.dto"

// ** info: request dto's imports
import { ReportsHistoricalsTable1188RequestDto } from "@core-modules/reports/dtos/module/reports-historicals-table-1188-request.dto"
import { ReportsHistoricalsTable1740RequestDto } from "@core-modules/reports/dtos/module/reports-historicals-table-1740-request.dto"
import { DownloadReport1188ByRequestDto } from "@core-modules/reports/dtos/module/download-report-1188-by-id-base-request.dto"
import { DownloadReport1740ByRequestDto } from "@core-modules/reports/dtos/module/download-report-1740-by-id-base-request.dto"
import { SummaryReportValidateRequestDto } from "@core-modules/reports/dtos/module/summary-report-validate-request.dto"
import { GenerateReport1188RequestDto } from "@core-modules/reports/dtos/module/generate-report-1188-request.dto"
import { GenerateReport1740RequestDto } from "@core-modules/reports/dtos/module/generate-report-1740-request.dto"
import { ReportConsecutiveRequestDto } from "@core-modules/reports/dtos/module/report-consecutive-request.dto"
import { FullDataReportRequetDto } from "@core-modules/reports/dtos/module/full-data-report-request.dto"
import { SummaryReportRequestDto } from "@core-modules/reports/dtos/module/summary-report-request.dto"
import { Validate1188RequestDto } from "@core-modules/reports/dtos/module/1188-validate-request.dto"
import { AuthHeadersDto } from "@core-modules/reports/dtos/inheritables/auth-headers.dto"

// ** info: exceljs import
import { Buffer } from "exceljs"

// ** info: class traosnformer imports
import { instanceToPlain } from "class-transformer"

import { LoggingService } from "@common-artifacts/logger-service/logging.service"

import { Request } from "express"

@Controller("reports")
export class ReportsController {
	private readonly logger: Logger = new Logger(ReportsController.name)

	// todo: replace burned parametrization by params table call
	// ! warning: burned parametrization here [ maxSummaryDatesRange ]
	private readonly maxSummaryDatesRange: number = 7
	private readonly maxCsvDatesRange: number = 1

	public constructor(
		private readonly reportsService: ReportsService,
		private readonly loggingService: LoggingService
	) {}

	@HttpCode(HttpStatus.OK)
	@Post(posix.join("reports-historicals-table-1188"))
	public async reportsHistoricalTable1188(
		@Body()
		reportsHistoricalsTable1188Request: ReportsHistoricalsTable1188RequestDto,
		@Req() request: Request
	): Promise<ReportsHistoricalsTable1188ResponseDto> {
		this.loggingService.log(undefined, request)

		if (
			reportsHistoricalsTable1188Request.startDate === undefined &&
			reportsHistoricalsTable1188Request.endDate === undefined &&
			reportsHistoricalsTable1188Request.consecutive === undefined
		) {
			throw new BadRequestException(
				"the body request need at least on atribute of startDate and endDate or consecutive"
			)
		}

		// todo: replace burned parametrization by params table call
		// ! warning: burned parametrization here [ maxDaysRange ]
		const maxDaysRange: number = 360

		let consecutive: number | undefined = undefined
		let startDate: Date | undefined = undefined
		let endDate: Date | undefined = undefined

		if (reportsHistoricalsTable1188Request.consecutive !== undefined) {
			consecutive = reportsHistoricalsTable1188Request.consecutive
		}

		// ** info: parsing request values manually due to problems with class transformer
		if (
			reportsHistoricalsTable1188Request.startDate !== undefined &&
			reportsHistoricalsTable1188Request.endDate != undefined
		) {
			startDate = this.isoDateString2Date({
				isoDateString: reportsHistoricalsTable1188Request.startDate,
			})
			endDate = this.isoDateString2Date({
				isoDateString: reportsHistoricalsTable1188Request.endDate,
			})
			// ** info: valdaing dates range
			const isDatesRangeValid: boolean = this.isDatesRangeValid({
				start: startDate,
				end: endDate,
				maxDaysRange: maxDaysRange,
			})
			if (!isDatesRangeValid) {
				throw new BadRequestException(
					`the dates range is above the max allowed`
				)
			}
		}
		const offset: number = Number(reportsHistoricalsTable1188Request.offset)
		const limit: number = Number(reportsHistoricalsTable1188Request.limit)

		const reportsHistoricalTable1188Response: ReportsHistoricalsTable1188ResponseDto =
			await this.reportsService.reportsHistoricalTable1188({
				consecutive: consecutive,
				startDate: startDate,
				endDate: endDate,
				offset: offset,
				limit: limit,
			})

		const secureReportsHistoricalTable1188Response: ReportsHistoricalsTable1188ResponseDto =
			instanceToPlain(
				reportsHistoricalTable1188Response
			) as ReportsHistoricalsTable1188ResponseDto

		return secureReportsHistoricalTable1188Response
	}

	@HttpCode(HttpStatus.OK)
	@Post(posix.join("1188-validate"))
	public async validate1188(
		@Body() validate1188Request: Validate1188RequestDto,
		@Req() request: Request
	): Promise<Validate1188ResponseDto> {
		this.loggingService.log(undefined, request)
		// ** info: parsing request values manually due to problems with class transformer
		const reportDate: string = validate1188Request.reportDate

		const consecutive: number = Number(validate1188Request.consecutive)
		const reciprocityDays: number = Number(validate1188Request.reciprocityDays)

		const consignedInterests: number = Number(
			validate1188Request.consignedInterests
		)
		const consignedSanctions: number = Number(
			validate1188Request.consignedSanctions
		)
		const notConsignedInterests: number = Number(
			validate1188Request.notConsignedInterests
		)
		const notConsignedSanctions: number = Number(
			validate1188Request.notConsignedSanctions
		)

		const validate1188Response: Validate1188ResponseDto =
			await this.reportsService.validate1188({
				reportDate: reportDate,
				consecutive: consecutive,
				reciprocityDays: reciprocityDays,
				consignedInterests: consignedInterests,
				consignedSanctions: consignedSanctions,
				notConsignedInterests: notConsignedInterests,
				notConsignedSanctions: notConsignedSanctions,
			})

		const secureValidate1188Response: Validate1188ResponseDto = instanceToPlain(
			validate1188Response
		) as Validate1188ResponseDto

		return secureValidate1188Response
	}

	@HttpCode(HttpStatus.OK)
	@Get(posix.join(":reportId", "consecutive"))
	public async reportConsecutive(
		@Param() reportConsecutiveRequest: ReportConsecutiveRequestDto,
		@Req() request: Request
	): Promise<ReportConsecutiveResponseDto> {
		this.loggingService.log(undefined, request)
		// todo: replace burned parametrization by domain table call
		// ! warning: burned parametrization here [ allowedReportIds ]
		const allowedReportIds: Set<number> = new Set([1188, 1740])

		// ** info: parsing request values manually due to problems with class transformer
		const reportId: number = Number(reportConsecutiveRequest.reportId)

		if (!allowedReportIds.has(reportId)) {
			throw new BadRequestException(
				"The required report consecutive id doesn't match with a valid report id"
			)
		}

		const reportConsecutiveResponse: ReportConsecutiveResponseDto =
			await this.reportsService.reportConsecutive({
				reportId: reportId,
			})

		const secureReportConsecutiveResponse: ReportConsecutiveResponseDto =
			instanceToPlain(reportConsecutiveResponse) as ReportConsecutiveResponseDto

		return secureReportConsecutiveResponse
	}

	@HttpCode(HttpStatus.OK)
	@Post(posix.join("reports-historicals-table-1740"))
	public async reportsHistoricalTable1740(
		@Body()
		reportsHistoricalsTable1740Request: ReportsHistoricalsTable1740RequestDto,
		@Req() request: Request
	): Promise<ReportsHistoricalsTable1740ResponseDto> {
		this.loggingService.log(undefined, request)

		if (
			reportsHistoricalsTable1740Request.startDate === undefined &&
			reportsHistoricalsTable1740Request.endDate === undefined &&
			reportsHistoricalsTable1740Request.consecutive === undefined
		) {
			throw new BadRequestException(
				"the body request need at least on atribute of startDate and endDate or consecutive"
			)
		}

		// todo: replace burned parametrization by params table call
		// ! warning: burned parametrization here [ maxDaysRange ]
		const maxDaysRange: number = 360

		let consecutive: number | undefined = undefined
		let startDate: Date | undefined = undefined
		let endDate: Date | undefined = undefined

		if (reportsHistoricalsTable1740Request.consecutive !== undefined) {
			consecutive = reportsHistoricalsTable1740Request.consecutive
		}

		// ** info: parsing request values manually due to problems with class transformer
		if (
			reportsHistoricalsTable1740Request.startDate !== undefined &&
			reportsHistoricalsTable1740Request.endDate !== undefined
		) {
			startDate = this.isoDateString2Date({
				isoDateString: reportsHistoricalsTable1740Request.startDate,
			})
			endDate = this.isoDateString2Date({
				isoDateString: reportsHistoricalsTable1740Request.endDate,
			})
			// ** info: valdaing dates range
			const isDatesRangeValid: boolean = this.isDatesRangeValid({
				start: startDate,
				end: endDate,
				maxDaysRange: maxDaysRange,
			})
			if (!isDatesRangeValid) {
				throw new BadRequestException(
					`the dates range is above the max allowed`
				)
			}
		}
		const offset: number = Number(reportsHistoricalsTable1740Request.offset)
		const limit: number = Number(reportsHistoricalsTable1740Request.limit)

		const reportsHistoricalTable1740Response: ReportsHistoricalsTable1740ResponseDto =
			await this.reportsService.reportsHistoricalTable1740({
				consecutive: consecutive,
				startDate: startDate,
				endDate: endDate,
				offset: offset,
				limit: limit,
			})

		const secureReportsHistoricalTable1740Response: ReportsHistoricalsTable1740ResponseDto =
			instanceToPlain(
				reportsHistoricalTable1740Response
			) as ReportsHistoricalsTable1740ResponseDto

		return secureReportsHistoricalTable1740Response
	}

	@HttpCode(HttpStatus.OK)
	@Post(posix.join("summary-report-validate"))
	public summaryReportValidate(
		@Body()
		summaryReportValidateRequest: SummaryReportValidateRequestDto,
		@Req() request: Request
	): SummaryReportValidateResponseDto {
		this.loggingService.log(undefined, request)
		const summaryReportValidateResponse: SummaryReportValidateResponseDto =
			new Object() as SummaryReportValidateResponseDto

		// ** info: parsing request values manually due to problems with class transformer
		const startDate: Date = this.isoDateString2Date({
			isoDateString: summaryReportValidateRequest.start,
		})
		const endDate: Date = this.isoDateString2Date({
			isoDateString: summaryReportValidateRequest.end,
		})

		// ** info: valdaing dates range
		summaryReportValidateResponse.isGenerable = this.isDatesRangeValid({
			maxDaysRange: this.maxSummaryDatesRange,
			start: startDate,
			end: endDate,
		})

		if (!summaryReportValidateResponse.isGenerable) {
			summaryReportValidateResponse.isGenerable = false
			return summaryReportValidateResponse
		}

		const secureSummaryReportValidateResponse: SummaryReportValidateResponseDto =
			instanceToPlain(
				summaryReportValidateResponse
			) as SummaryReportValidateResponseDto

		return secureSummaryReportValidateResponse
	}

	@HttpCode(HttpStatus.OK)
	@Post(posix.join("full-data-report-validate"))
	public async fullDataReportValidate(
		@Body()
		summaryReportValidateRequest: SummaryReportValidateRequestDto,
		@Req() request: Request
	): Promise<SummaryReportValidateResponseDto> {
		this.loggingService.log(undefined, request)
		const summaryReportValidateResponse: SummaryReportValidateResponseDto =
			new Object() as SummaryReportValidateResponseDto

		// ** info: parsing request values manually due to problems with class transformer
		const startDate: Date = this.isoDateString2Date({
			isoDateString: summaryReportValidateRequest.start,
		})
		const endDate: Date = this.isoDateString2Date({
			isoDateString: summaryReportValidateRequest.end,
		})

		// ** info: valdaing dates range
		summaryReportValidateResponse.isGenerable = this.isDatesRangeValid({
			maxDaysRange: this.maxCsvDatesRange,
			start: startDate,
			end: endDate,
		})

		if (!summaryReportValidateResponse.isGenerable) {
			summaryReportValidateResponse.isGenerable = false
			return summaryReportValidateResponse
		}

		const movementsCount: number =
			await this.reportsService.fullDataReportCount({ startDate: startDate })

		if (movementsCount === 0) {
			summaryReportValidateResponse.isGenerable = false
			return summaryReportValidateResponse
		}

		const secureSummaryReportValidateResponse: SummaryReportValidateResponseDto =
			instanceToPlain(
				summaryReportValidateResponse
			) as SummaryReportValidateResponseDto

		return secureSummaryReportValidateResponse
	}

	@HttpCode(HttpStatus.OK)
	@Get(posix.join("summary-report"))
	public async summaryReport(
		@Query() summaryReportRequest: SummaryReportRequestDto,
		@Res() response: Response,
		@Req() request: Request
	): Promise<void> {
		this.loggingService.log(undefined, request)
		// todo: replace burned parametrization by params table call
		// ! warning: burned parametrization here [ outputFileName ]
		const outputFileName: string = "summaryData"

		// ** info: parsing request values manually due to problems with class transformer
		const startDate: Date = this.isoDateString2Date({
			isoDateString: summaryReportRequest.start,
		})
		const endDate: Date = this.isoDateString2Date({
			isoDateString: summaryReportRequest.end,
		})

		// ** info: valdaing dates range
		const isDatesRangeValid: boolean = this.isDatesRangeValid({
			maxDaysRange: this.maxSummaryDatesRange,
			start: startDate,
			end: endDate,
		})

		if (!isDatesRangeValid) {
			throw new BadRequestException(`the dates range is above the max allowed`)
		}

		const earId: number = Number(summaryReportRequest.earId)

		// todo: replace burned parametrization by params table call
		// ! warning: burned parametrization here [ 0, 99999 ]
		if (!(earId >= 0 && earId <= 99999)) {
			throw new BadRequestException(`the earId param is not correct`)
		}

		const summaryReport: Buffer = await this.reportsService.summaryReport({
			startDate: startDate,
			endDate: endDate,
			earId: earId,
		})

		// ** info: setting up response content type
		response.set("Content-Type", "text/xlsx")

		response.set(
			"Content-disposition",
			`attachment; filename=${outputFileName}.xlsx`
		)

		// ** info: sending response
		response.end(summaryReport)

		return
	}

	@HttpCode(HttpStatus.OK)
	@Get(posix.join("download-report-1188-by-id"))
	public async downloadReport1188ById(
		@Query() downloadReportByIdRequet: DownloadReport1188ByRequestDto,
		@Res() response: Response,
		@Req() request: Request
	): Promise<void> {
		this.loggingService.log(undefined, request)
		// ** info: parsing request values manually due to problems with class transformer
		const reportId: number = Number(downloadReportByIdRequet.reportId)

		const [reportData, reportName]: [Buffer, string] =
			await this.reportsService.downloadReport1188ById({ reportId: reportId })

		// ** info: setting up response content type
		response.set("Content-Type", "text/csv")

		response.set(
			"Content-disposition",
			`attachment; filename=${reportName}.xlm`
		)

		// ** info: sending response
		response.end(reportData)

		return
	}

	@HttpCode(HttpStatus.OK)
	@Get(posix.join("download-report-1740-by-id"))
	public async downloadReport1740ById(
		@Query() downloadReportByIdRequet: DownloadReport1740ByRequestDto,
		@Res() response: Response,
		@Req() request: Request
	): Promise<void> {
		this.loggingService.log(undefined, request)
		// ** info: parsing request values manually due to problems with class transformer
		const reportId: number = Number(downloadReportByIdRequet.reportId)

		const [reportData, reportName]: [Buffer, string] =
			await this.reportsService.downloadReport1740ById({ reportId: reportId })

		// ** info: setting up response content type
		response.set("Content-Type", "text/plain")

		response.set(
			"Content-disposition",
			`attachment; filename=${reportName}.xml`
		)

		// ** info: sending response
		response.end(reportData)

		return
	}

	@HttpCode(HttpStatus.OK)
	@Get(posix.join("full-data-report"))
	public async fullDataReport(
		@Query() fullDataReportRequet: FullDataReportRequetDto,
		@Res() response: Response,
		@Req() request: Request
	): Promise<void> {
		this.loggingService.log(undefined, request)
		// todo: replace burned parametrization by params table call
		// ! warning: burned parametrization here [ outputFileName ]
		const outputFileName: string = "fullData"

		// ** info: parsing request values manually due to problems with class transformer
		const startDate: Date = this.isoDateString2Date({
			isoDateString: fullDataReportRequet.start,
		})

		const fullDataReport: Buffer = await this.reportsService.fullDataReport({
			startDate: startDate,
		})

		// ** info: setting up response content type
		response.set("Content-Type", "text/plain")

		response.set(
			"Content-disposition",
			`attachment; filename=${outputFileName}.xml`
		)

		// ** info: sending response
		response.end(fullDataReport)

		return
	}

	@HttpCode(HttpStatus.OK)
	@Post(posix.join("1188"))
	public async generateReport1188(
		@Headers() headers: AuthHeadersDto,
		@Body()
		generateReport1188Request: GenerateReport1188RequestDto,
		@Req() request: Request
	): Promise<GenerateReport1188ResponseDto> {
		this.loggingService.log(undefined, request)
		// ** info: parsing request values manually due to problems with class transformer
		const consecutive: number = Number(generateReport1188Request.consecutive)

		const reportDate: Date = this.isoDateString2Date({
			isoDateString: generateReport1188Request.reportDate,
		})

		const notConsignedInterests: number = Number(
			generateReport1188Request.notConsignedInterests
		)

		const notConsignedSanctions: number = Number(
			generateReport1188Request.notConsignedSanctions
		)

		const consignedInterests: number = Number(
			generateReport1188Request.consignedInterests
		)

		const consignedSanctions: number = Number(
			generateReport1188Request.consignedSanctions
		)

		const reciprocityDays: number = Number(
			generateReport1188Request.reciprocityDays
		)

		const report1188MetaData: GenerateReport1188ResponseDto =
			await this.reportsService.generateReport1188({
				iv: headers.iv,
				jwt: headers.jwt,
				notConsignedSanctions: notConsignedSanctions,
				notConsignedInterests: notConsignedInterests,
				consignedInterests: consignedInterests,
				consignedSanctions: consignedSanctions,
				reciprocityDays: reciprocityDays,
				consecutive: consecutive,
				reportDate: reportDate,
			})

		return report1188MetaData
	}

	@HttpCode(HttpStatus.OK)
	@Post(posix.join("1740"))
	public async generateReport1740(
		@Headers() headers: AuthHeadersDto,
		@Body()
		generateReport1740Request: GenerateReport1740RequestDto,
		@Req() request: Request
	): Promise<GenerateReport1740ResponseDto> {
		this.loggingService.log(undefined, request)
		// ** info: parsing request values manually due to problems with class transformer
		const consecutive: number = Number(generateReport1740Request.consecutive)

		const reportDate: Date = this.isoDateString2Date({
			isoDateString: generateReport1740Request.reportDate,
		})

		const report1740MetaData: GenerateReport1740ResponseDto =
			await this.reportsService.generateReport1740({
				iv: headers.iv,
				jwt: headers.jwt,
				consecutive: consecutive,
				reportDate: reportDate,
			})

		return report1740MetaData
	}

	private isoDateString2Date(params: { isoDateString: string }): Date {
		// ** info: parsig iso string to Date class object
		const date: Date = new Date(params.isoDateString)

		// ** if Date class object time is NaN the initial iso string is not a valid date
		if (isNaN(date.getTime())) {
			throw new BadRequestException("invalid date")
		}

		if (!this.isDateBeforeCurrentDate({ date: date })) {
			throw new BadRequestException(
				`the requested date can't be after todays date`
			)
		}

		return date
	}

	private isDateBeforeCurrentDate(params: { date: Date }): boolean {
		// ** info: getting Date class object time
		const dateTime: number = params.date.getTime()

		// ** info: todays date
		const todaysDateTime: number = Date.now()

		if (dateTime > todaysDateTime) {
			return false
		}

		return true
	}

	private isDatesRangeValid(params: {
		start: Date
		end: Date
		maxDaysRange: number
	}): boolean {
		// ** info: milliseconds of a day
		const oneDay: number = 24 * 60 * 60 * 1000

		// ** info: extracting date time in milliseconds
		const startTime: number = params.start.getTime()
		const endTime: number = params.end.getTime()

		if (startTime > endTime) {
			throw new BadRequestException(
				`the start date can't be after the end date`
			)
		}

		// ** info: checking dates range to be above max
		const diffDays: number = Math.round(Math.abs(endTime - startTime) / oneDay)

		const maxDaysRange: number = params.maxDaysRange

		if (diffDays < maxDaysRange) {
			return true
		}

		return false
	}
}
