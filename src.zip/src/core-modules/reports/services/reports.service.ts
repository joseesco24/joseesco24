/** @format */

// ** info: nest commons imports
import { BadRequestException } from "@nestjs/common"
import { HttpException } from "@nestjs/common"
import { Injectable } from "@nestjs/common"
import { HttpStatus } from "@nestjs/common"
import { Logger } from "@nestjs/common"

// ** info: nest axios
import { HttpService } from "@nestjs/axios"

// ** info: axios
import { AxiosResponse } from "@nestjs/axios/node_modules/axios"
import { AxiosError } from "@nestjs/axios/node_modules/axios"

// ** info: rxjs imports
import { firstValueFrom } from "rxjs"
import { catchError } from "rxjs"
import { map } from "rxjs"

// ** info: response dto's imports
import { ReportsHistoricalsTable1188ResponseDto } from "@core-modules/reports/dtos/module/reports-historicals-table-1188-response.dto"
import { ReportsHistoricalsTable1188DataDto } from "@core-modules/reports/dtos/module/reports-historicals-table-1188-response.dto"
import { ReportsHistoricalsTable1740ResponseDto } from "@core-modules/reports/dtos/module/reports-historicals-table-1740-response.dto"
import { ReportsHistoricalsTable1740DataDto } from "@core-modules/reports/dtos/module/reports-historicals-table-1740-response.dto"
import { GenerateReport1188ResponseDto } from "@core-modules/reports/dtos/module/generate-report-1188-response.dto"
import { Report1188ResponsedataDto } from "@core-modules/reports/dtos/module/generate-report-1188-response.dto"
import { GenerateReport1740ResponseDto } from "@core-modules/reports/dtos/module/generate-report-1740-response.dto"
import { Report1740ResponsedataDto } from "@core-modules/reports/dtos/module/generate-report-1740-response.dto"
import { ReportConsecutiveResponseDto } from "@core-modules/reports/dtos/module/report-consecutive-response.dto"
import { Validate1188ResponseDto } from "@core-modules/reports/dtos/module/1188-validate-response.dto"
import { ReportServiceResponseDto } from "@core-modules/reports/dtos/module/report-service-response.dto"
import { ExcelColumn } from "@core-modules/reports/dtos/module/excel-column.dto"

// ** info: dian database module imports
import { DianMovementsService } from "@common-modules/dian-database/services/dian-movements.service"
import { DianReportsService } from "@common-modules/dian-database/services/dian-reports.service"
import { DianDomainService } from "@common-modules/dian-database/services/dian-domain.service"
import { DianTaxService } from "@common-modules/dian-database/services/dian-tax.service"

// ** info: entites interfaces imports
import { DianReports1188TableDataInterface } from "@common-modules/dian-database/interfaces/dian-reports-1188-table-data.interface"
import { DianReports1740TableDataInterface } from "@common-modules/dian-database/interfaces/dian-reports-1740-table-data.interface"

// ** info: dian database entites repositorioes imports
import { DianTax } from "@common-modules/dian-database/entities/dian-tax.entity"

// ** info: dian database dtos imports
import { FoundDomainDescription } from "@common-modules/dian-database/dtos/foundDomainDescription.dto"
import { NotNullishForm2 } from "@common-modules/dian-database/dtos/notNullishForm.dto"
import { NotNullishForm } from "@common-modules/dian-database/dtos/notNullishForm.dto"

// ** info: exceljs import
import { Worksheet } from "exceljs"
import { Workbook } from "exceljs"
import { Buffer } from "exceljs"
import { Cell } from "exceljs"
import { Row } from "exceljs"

// ** info: dian databse entities
import { DianReport1188 } from "@common-modules/dian-database/entities/dian-reports-1188.entity"
import { DianReport1740 } from "@common-modules/dian-database/entities/dian-reports-1740.entity"
import { DianMovements } from "@common-modules/dian-database/entities/dian-movements.entity"

// ** info: dian storage imports
import { DianStorageService } from "@common-modules/dian-storage/services/dian-storage.service"

// ** info: moment import
import * as moment from "moment"

// ** info: nest config imports
import { ConfigService } from "@nestjs/config"

@Injectable()
export class ReportsService {
	private readonly logger: Logger = new Logger(ReportsService.name)

	private readonly reportsServiceUrl: string

	public constructor(
		private readonly dianMovementsService: DianMovementsService,
		private readonly dianStorageService: DianStorageService,
		private readonly dianReportsService: DianReportsService,
		private readonly dianDomainService: DianDomainService,
		private readonly dianTaxService: DianTaxService,
		private readonly configService: ConfigService,
		private readonly httpService: HttpService
	) {
		this.reportsServiceUrl = this.configService.get(
			"URL_REPORT_SERVICE_REPORTS" as string
		)
	}

	public async reportsHistoricalTable1188(params: {
		consecutive: number | undefined
		startDate: Date | undefined
		endDate: Date | undefined
		offset: number
		limit: number
	}): Promise<ReportsHistoricalsTable1188ResponseDto> {
		const reportsHistoricalTable1188Response: ReportsHistoricalsTable1188ResponseDto =
			new Object() as ReportsHistoricalsTable1188ResponseDto

		const reportsHistoricalsTable1188DataDto: ReportsHistoricalsTable1188DataDto[] =
			[] as ReportsHistoricalsTable1188DataDto[]

		const [dataRegisters, count]: [
			DianReports1188TableDataInterface[],
			number
		] = await this.dianReportsService.reportsHistoricalTable1188({
			consecutive: params.consecutive,
			startDate: params.startDate,
			endDate: params.endDate,
			offset: params.offset,
			limit: params.limit,
		})

		const discriptionsCache: { string: string } = new Object() as {
			string: string
		}

		for (const data of dataRegisters) {
			const dataOutRegister: ReportsHistoricalsTable1188DataDto =
				new Object() as ReportsHistoricalsTable1188DataDto

			// ** info: assignations with special treatements
			dataOutRegister.generationDate = moment(data.generationDate).format(
				"YYYY-MM-DD"
			)

			dataOutRegister.news = data.news ? "Si" : "No"

			// todo: make a real treatement here
			// ! warning: burned response value here [ "No" ]
			dataOutRegister.correction = "No"

			if (data.reportType in discriptionsCache) {
				dataOutRegister.reportType = discriptionsCache[data.reportType]
			} else {
				const description: string =
					await this.dianDomainService.getDescriptionByDomainId({
						domainId: data.reportType,
					})
				discriptionsCache[data.reportType] = description
				dataOutRegister.reportType = description
			}

			// ** info: direct assignations
			dataOutRegister.consecutive = data.consecutive
			dataOutRegister.generationUser = data.generationUser
			dataOutRegister.realDate = data.realDate
			dataOutRegister.reportId1188 = data.reportId1188
			dataOutRegister.reportName = data.reportName

			reportsHistoricalsTable1188DataDto.push(dataOutRegister)
		}

		reportsHistoricalTable1188Response.data = reportsHistoricalsTable1188DataDto
		reportsHistoricalTable1188Response.count = count

		return reportsHistoricalTable1188Response
	}

	public async validate1188(params: {
		reportDate: string
		consecutive: number
		reciprocityDays: number
		consignedInterests: number
		consignedSanctions: number
		notConsignedInterests: number
		notConsignedSanctions: number
	}): Promise<Validate1188ResponseDto> {
		const validate1188Response: Validate1188ResponseDto =
			new Object() as Validate1188ResponseDto

		const month: number = Number(params.reportDate.split("-")[1]) - 1
		const year: number = Number(params.reportDate.split("-")[0])

		const nextInitDate: number = new Date(year, month + 1, 1).getTime()
		const oneDay: number = 24 * 60 * 60 * 1000

		const endDate: Date = new Date(nextInitDate - oneDay)
		const initDate: Date = new Date(year, month, 1)

		validate1188Response.allreadyGenerated =
			await this.dianReportsService.validate1188({
				endDate: endDate,
				initDate: initDate,
				consecutive: params.consecutive,
				reciprocityDays: params.reciprocityDays,
				consignedInterests: params.consignedInterests,
				consignedSanctions: params.consignedSanctions,
				notConsignedInterests: params.notConsignedInterests,
				notConsignedSanctions: params.notConsignedSanctions,
			})

		return validate1188Response
	}

	public async generateReport1188(params: {
		iv: string
		jwt: string
		reportDate: Date
		consecutive: number
		reciprocityDays: number
		consignedInterests: number
		consignedSanctions: number
		notConsignedInterests: number
		notConsignedSanctions: number
	}): Promise<GenerateReport1188ResponseDto> {
		const report1188MetaDataWrapper: GenerateReport1188ResponseDto =
			new Object() as GenerateReport1188ResponseDto
		const report1188MetaData: Report1188ResponsedataDto =
			new Object() as Report1188ResponsedataDto

		// ** info: burned parametrization here [ reportId ]
		const reportId: number = 1188

		const reportConsecutiveResponse: ReportConsecutiveResponseDto =
			await this.reportConsecutive({
				reportId: reportId,
			})
		const reportCurrentConsecutive: number =
			reportConsecutiveResponse.consecutive

		if (reportCurrentConsecutive !== params.consecutive) {
			throw new BadRequestException(
				"mismatch between required consecutive and current consecutive"
			)
		}

		const reportServiceUrl: string = `${this.reportsServiceUrl}/${String(
			reportId
		)}`

		const reportServiceResponse: ReportServiceResponseDto =
			await firstValueFrom(
				this.httpService
					.post(
						reportServiceUrl,
						{
							consecutive: String(reportCurrentConsecutive),
							init: params.reportDate.toISOString().split("T")[0],
							end: params.reportDate.toISOString().split("T")[0],
						},
						{
							headers: {
								// eslint-disable-next-line @typescript-eslint/naming-convention
								"content-type": "application/json",
								"jwt": params.jwt,
								"iv": params.iv,
							},
							timeout: Number(
								this.configService.get("REPORT_GENERATION_TIMEOUT")
							),
						}
					)
					.pipe(
						map((response: AxiosResponse) => {
							if (response === undefined) {
								throw new HttpException(
									`error while requesting report 1188`,
									HttpStatus.INTERNAL_SERVER_ERROR
								)
							}
							return response.data
						}),
						catchError(async (error: AxiosError) => {
							if (error.response.status === HttpStatus.NOT_FOUND) {
								const reportsCount: number =
									await this.dianReportsService.countReportsInHistoricalTable1188(
										{
											startDate: this.formatDateToDayStart({
												date: params.reportDate,
											}),
											endDate: this.formatDateToDayEnd({
												date: params.reportDate,
											}),
										}
									)
								if (reportsCount > 0) {
									throw new HttpException(
										`Ya hay un reporte generado para la fecha solicitada, por favor revise el panel de histórico de reportes`,
										HttpStatus.NOT_FOUND
									)
								}
								throw new HttpException(
									`No hay recaudos para generar el reporte en la fecha seleccionada`,
									HttpStatus.NOT_FOUND
								)
							}
							throw new HttpException(
								`error while requesting report 1188: ${error.message}`,
								HttpStatus.INTERNAL_SERVER_ERROR
							)
						})
					)
			)

		const reportMetadata: DianReport1188 =
			await this.dianReportsService.getReport1188MetadataById({
				reportId: reportServiceResponse.id,
			})

		// ** info: filling response object
		report1188MetaData.reportType = reportServiceResponse.report
		report1188MetaData.realDate = reportMetadata.systemDate
		// ! warning: burned response here [ report1188MetaData.status ]
		report1188MetaData.status = true
		report1188MetaData.reciprocityDays = reportMetadata.reciprocityDays
		report1188MetaData.consignedInterests = reportMetadata.consignedInterests
		report1188MetaData.consignedSanctions = reportMetadata.consignedSanctions
		report1188MetaData.notConsignedInterests =
			reportMetadata.notConsignedInterests
		report1188MetaData.notConsignedSanctions =
			reportMetadata.notConsignedSanctions
		report1188MetaData.reportId1188 = reportServiceResponse.id

		report1188MetaDataWrapper.data = []

		report1188MetaDataWrapper.data.push(
			JSON.parse(JSON.stringify(report1188MetaData))
		)

		return report1188MetaDataWrapper
	}

	public async generateReport1740(params: {
		iv: string
		jwt: string
		reportDate: Date
		consecutive: number
	}): Promise<GenerateReport1740ResponseDto> {
		const report1740MetaDataWrapper: GenerateReport1740ResponseDto =
			new Object() as GenerateReport1740ResponseDto
		const report1740MetaData: Report1740ResponsedataDto =
			new Object() as Report1740ResponsedataDto

		// ** info: burned parametrization here [ reportId ]
		const reportId: number = 1740

		const reportConsecutiveResponse: ReportConsecutiveResponseDto =
			await this.reportConsecutive({
				reportId: reportId,
			})
		const reportCurrentConsecutive: number =
			reportConsecutiveResponse.consecutive

		if (reportCurrentConsecutive !== params.consecutive) {
			throw new BadRequestException(
				"mismatch between required consecutive and current consecutive"
			)
		}

		const reportServiceUrl: string = `${this.reportsServiceUrl}/${String(
			reportId
		)}`

		const reportServiceResponse: ReportServiceResponseDto =
			await firstValueFrom(
				this.httpService
					.post(
						reportServiceUrl,
						{
							consecutive: String(reportCurrentConsecutive),
							init: params.reportDate.toISOString().split("T")[0],
							end: params.reportDate.toISOString().split("T")[0],
						},
						{
							headers: {
								// eslint-disable-next-line @typescript-eslint/naming-convention
								"content-type": "application/json",
								"jwt": params.jwt,
								"iv": params.iv,
							},
							timeout: Number(
								this.configService.get("REPORT_GENERATION_TIMEOUT")
							),
						}
					)
					.pipe(
						map((response: AxiosResponse) => {
							if (response === undefined) {
								throw new HttpException(
									`error while requesting report 1740`,
									HttpStatus.INTERNAL_SERVER_ERROR
								)
							}
							return response.data
						}),
						catchError(async (error: AxiosError) => {
							if (error.response.status === HttpStatus.NOT_FOUND) {
								const reportsCount: number =
									await this.dianReportsService.countReportsInHistoricalTable1740(
										{
											startDate: this.formatDateToDayStart({
												date: params.reportDate,
											}),
											endDate: this.formatDateToDayEnd({
												date: params.reportDate,
											}),
										}
									)
								if (reportsCount > 0) {
									throw new HttpException(
										`Ya hay un reporte generado para la fecha solicitada, por favor revise el panel de histórico de reportes`,
										HttpStatus.NOT_FOUND
									)
								}
								throw new HttpException(
									`No hay recaudos para generar el reporte en la fecha seleccionada`,
									HttpStatus.NOT_FOUND
								)
							}
							throw new HttpException(
								`error while requesting report 1740: ${error.message}`,
								HttpStatus.INTERNAL_SERVER_ERROR
							)
						})
					)
			)

		const reportMetadata: DianReport1740 =
			await this.dianReportsService.getReport1740MetadataById({
				reportId: reportServiceResponse.id,
			})

		// ** info: filling response object
		report1740MetaData.reportType = reportServiceResponse.report
		report1740MetaData.realDate = reportMetadata.reportDate.toISOString()
		report1740MetaData.generationDate = reportMetadata.systemDate
		report1740MetaData.news = reportMetadata.news ? "si" : "no"
		// ! warning: burned response here [ report1740MetaData.status ]
		report1740MetaData.status = true
		report1740MetaData.consecutive = reportCurrentConsecutive
		report1740MetaData.reportId1740 = reportServiceResponse.id

		report1740MetaDataWrapper.data = []

		report1740MetaDataWrapper.data.push(
			JSON.parse(JSON.stringify(report1740MetaData))
		)

		return report1740MetaDataWrapper
	}

	public async reportConsecutive(params: {
		reportId: number
	}): Promise<ReportConsecutiveResponseDto> {
		const reportConsecutiveResponse: ReportConsecutiveResponseDto =
			new Object() as ReportConsecutiveResponseDto

		const getReportFunction: CallableFunction = {
			// eslint-disable-next-line @typescript-eslint/unbound-method
			f1740: this.dianReportsService.report1740Consecutive,
			// eslint-disable-next-line @typescript-eslint/unbound-method
			f1188: this.dianReportsService.report1188Consecutive,
		}[`f${params.reportId}`]

		const currentConsecutive: number = await getReportFunction.bind(
			this.dianReportsService
		)()

		reportConsecutiveResponse.consecutive = currentConsecutive + 1

		return reportConsecutiveResponse
	}

	// todo: test this buisines logic
	public async downloadReport1188ById(params: {
		reportId: number
	}): Promise<[Buffer, string]> {
		// todo: enable tls certification here
		// ! warnig: tls certification unabled here
		process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0"

		const [reportPath, reportName]: [string, string] =
			await this.dianReportsService.getReport1188PathNameById({
				reportId: params.reportId,
			})

		const reportData: Buffer = await this.dianStorageService.getReportByPath({
			reportPath: reportPath,
		})

		return [reportData, reportName]
	}

	public async downloadReport1740ById(params: {
		reportId: number
	}): Promise<[Buffer, string]> {
		// todo: enable tls certification here
		// ! warnig: tls certification unabled here
		process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0"

		const [reportPath, reportName]: [string, string] =
			await this.dianReportsService.getReport1740PathNameById({
				reportId: params.reportId,
			})

		const reportData: Buffer = await this.dianStorageService.getReportByPath({
			reportPath: reportPath,
		})

		return [reportData, reportName]
	}

	public async summaryReport(params: {
		startDate: Date
		endDate: Date
		earId: number
	}): Promise<Buffer> {
		// todo: replace burned parametrization by params table call
		// ! warning: burned parametrization here [ sheetTittle, columnWidth, taxesRowTittle, cantTittle, valueTittle, totalTittles ]
		const taxesRowTittle: string = "medio de pago"
		const sheetTittle: string = "summary data"
		const cantTittle: string = "cantidad"
		const valueTittle: string = "valor"
		const columnWidth: number = 40

		// ** info: creatig excel book
		const workbook: Workbook = new Workbook()

		const titlesReportColumns: ExcelColumn[] = [
			{
				header: taxesRowTittle,
				width: 30,
			},
		]

		const taxes: Set<string> = new Set()
		const subTitles: string[] = [""]

		// ** info: mapping result dates
		// todo: make this map operations async
		const dates: Set<string> = new Set()

		// ** info: appending aditional dates
		const startDate: moment.Moment = moment(params.startDate).add(1, "day")
		const endDate: moment.Moment = moment(params.endDate).add(1, "day")

		const diff: number = endDate.diff(startDate, "day")

		const finalDatesFormat: string = "YYYY-MM-DD"

		dates.add(startDate.format(finalDatesFormat))
		dates.add(endDate.format(finalDatesFormat))

		for (let i: number = 0; i < diff; i++) {
			dates.add(moment(startDate).add(i, "day").format(finalDatesFormat))
		}

		// ** info: fetching not null consolidated by form and payment method, all taxes names, all payment methods names and all forms names at the same time
		const [allTaxNames, rawForms, paymentMethods]: [
			DianTax[],
			FoundDomainDescription[],
			FoundDomainDescription[]
		] = await Promise.all([
			this.dianTaxService.allTaxNames(),
			this.dianDomainService.getDescriptionsByDomain("tipo_formulario"),
			this.dianDomainService.getDescriptionsByDomain(
				"forma_de_pago_impuestos_dian"
			),
		])

		// ** info: the length needs to be multiplied by two cause every tax have a value and a quantity
		const zerosArray: number[] = new Array(allTaxNames.length * 2).fill(0)

		allTaxNames.map((tax: DianTax) => {
			taxes.add(tax.taxName)
		})

		// ** info: building titles and subtitles rows
		for (const title of taxes) {
			const cleanTitle: string = title.toLowerCase().trim()

			subTitles.push(cantTittle)
			subTitles.push(valueTittle)

			titlesReportColumns.push({
				header: cleanTitle,
				width: columnWidth,
			})
			titlesReportColumns.push({
				header: cleanTitle,
				width: columnWidth,
			})
		}

		for (const date of [...dates].sort()) {
			// ** getting date string as Date type
			const dateLiteral: Date = this.isoDateString2Date({ isoDateString: date })

			// ** info: generating th new sheet
			const worksheet: Worksheet = workbook.addWorksheet(
				`${sheetTittle} ${dateLiteral.toISOString().split("T")[0]}`
			)

			// ** info: fetching not null consolidated by form and payment method, all taxes names, all payment methods names and all forms names at the same time
			const [rawMovements]: [NotNullishForm2[]] = await Promise.all([
				this.dianMovementsService.summaryTableForms2({
					start: dateLiteral,
					end: dateLiteral,
					earId: params.earId,
				}),
			])

			worksheet.columns = titlesReportColumns
			worksheet.addRow(subTitles)

			// ** info: merging titles and subtitles first column
			worksheet.mergeCells("A1:A2")

			// ** info: changing titles and subtitles style
			worksheet.getRow(1).eachCell((cell: Cell) => {
				cell.font = { bold: true }
				cell.alignment = { horizontal: "center", vertical: "middle" }
			})
			worksheet.getRow(2).eachCell((cell: Cell) => {
				cell.font = { bold: true }
				cell.alignment = { horizontal: "center", vertical: "middle" }
			})

			// ** info: building rows initial values
			for (const form of rawForms) {
				const initialRowValues: (string | number)[] = [
					form.domainDescription.toLowerCase().trim(),
					...zerosArray,
				]
				worksheet.addRow(initialRowValues)
			}

			for (let rowIndex: number = 0; rowIndex < rawForms.length; rowIndex++) {
				// ** info: extracting payment form
				const currentPaymentForm: string = worksheet.getCell(`A${rowIndex + 3}`)
					.value as string

				worksheet.getRow(rowIndex + 3).eachCell((cell: Cell) => {
					cell.alignment = { horizontal: "center", vertical: "middle" }

					// ** info: changing column style
					if (worksheet.getColumn(cell.col).letter === "A") {
						cell.font = { bold: true }
					}

					if (worksheet.getColumn(cell.col).letter !== "A") {
						// ** info: extracting payment tax
						const currentTax: string = worksheet.getCell(
							`${worksheet.getColumn(cell.col).letter}1`
						).value as string

						// ** info: extracting quantity or value
						const currentType: string = worksheet.getCell(
							`${worksheet.getColumn(cell.col).letter}2`
						).value as string

						// ** info: searching coincidences in raw movements
						rawMovements.map((movement: NotNullishForm) => {
							const movementTax: string = movement.taxName.toLowerCase().trim()
							const movementPaymentForm: string = movement.paymentForm
								.toLowerCase()
								.trim()

							if (
								currentPaymentForm === movementPaymentForm &&
								currentTax === movementTax &&
								currentType === cantTittle
							) {
								cell.value = movement.paymentsCount
							}

							if (
								currentPaymentForm === movementPaymentForm &&
								currentTax === movementTax &&
								currentType === valueTittle
							) {
								cell.value = movement.paymentsValue
							}
						})
					}
				})
			}

			for (const paymentMethod of paymentMethods) {
				const paymentMethodName: string = paymentMethod.domainDescription
					.toLowerCase()
					.trim()

				// ** info: adding empty row
				worksheet.addRow([])

				// ** info: adding footer titles row
				const subtitiles2: Row = worksheet.addRow([
					paymentMethodName,
					cantTittle,
					valueTittle,
				])

				subtitiles2.eachCell((cell: Cell) => {
					cell.font = { bold: true }
					cell.alignment = { horizontal: "center", vertical: "middle" }
				})

				for (const paymentForm of rawForms) {
					const paymentFormName: string = paymentForm.domainDescription
						.toLowerCase()
						.trim()

					let totalValue: number = 0
					let totalCount: number = 0

					rawMovements.map((movement: NotNullishForm2) => {
						const movementPaymentForm: string = movement.paymentForm
							.toLowerCase()
							.trim()
						const movementPaymentMethod: string = movement.paymentsMethod
							.toLowerCase()
							.trim()

						if (
							paymentFormName === movementPaymentForm &&
							paymentMethodName === movementPaymentMethod
						) {
							totalCount += movement.paymentsCount
							totalValue += movement.paymentsValue
						}
					})

					const valuesRow: Row = worksheet.addRow([
						paymentFormName,
						totalCount,
						totalValue,
					])

					// ** info: applying styles to totals columns
					valuesRow.eachCell((cell: Cell) => {
						cell.alignment = { horizontal: "center", vertical: "middle" }

						// ** info: changing column style
						if (worksheet.getColumn(cell.col).letter === "A") {
							cell.font = { bold: true }
						}
					})
				}

				for (const tax of allTaxNames) {
					const taxName: string = tax.taxName.toLowerCase().trim()

					let totalValue: number = 0
					let totalCount: number = 0

					rawMovements.map((movement: NotNullishForm2) => {
						const movementTax: string = movement.taxName.toLowerCase().trim()
						const movementPaymentMethod: string = movement.paymentsMethod
							.toLowerCase()
							.trim()

						if (
							taxName === movementTax &&
							paymentMethodName === movementPaymentMethod
						) {
							totalCount += movement.paymentsCount
							totalValue += movement.paymentsValue
						}
					})

					const valuesRow: Row = worksheet.addRow([
						taxName,
						totalCount,
						totalValue,
					])

					// ** info: applying styles to totals columns
					valuesRow.eachCell((cell: Cell) => {
						cell.alignment = { horizontal: "center", vertical: "middle" }

						// ** info: changing column style
						if (worksheet.getColumn(cell.col).letter === "A") {
							cell.font = { bold: true }
						}
					})
				}
			}

			// ** info: adding empty row
			worksheet.addRow([])
		}

		const tmpResultExcel: Buffer = await workbook.xlsx.writeBuffer()

		return tmpResultExcel
	}

	public async fullDataReportCount(params: {
		startDate: Date
	}): Promise<number> {
		const dateMovementsCount: number =
			await this.dianReportsService.fullDataReportCount({
				startDate: params.startDate,
			})
		return dateMovementsCount
	}

	public async fullDataReport(params: { startDate: Date }): Promise<Buffer> {
		// todo: replace burned parametrization by params table call
		// ! warning: burned parametrization here [ sheetTittle, columnWidth ]
		const sheetTittle: string = "Full Data"
		const columnWidth: number = 30

		// ** info: creating csv init file here
		const workbook: Workbook = new Workbook()

		const worksheet: Worksheet = workbook.addWorksheet(sheetTittle)

		const titlesReportColumns: ExcelColumn[] = []
		const titles: string[] = []

		const dateMovements: DianMovements[] =
			await this.dianReportsService.fullDataReportMovements({
				startDate: params.startDate,
			})

		const sample: DianMovements = dateMovements[0]

		// ! warning: burned parametrization here [ movementsTableAlias ]
		const movementsTableAlias: string = "dianMovementsTable"

		// ** info: extracting and correcting titles here
		for (const title of Object.keys(sample)) {
			titles.push(title.replace(`${movementsTableAlias}_`, ""))
		}

		// ! warning: burned replacement values and operations here
		await Promise.all([
			this.replaceDomainByDescription({
				dateMovements: dateMovements,
				domainKey: `${movementsTableAlias}_dominio_tipo_archivo`,
			}),
			this.replaceDomainByRealValue({
				dateMovements: dateMovements,
				domainKey: `${movementsTableAlias}_dominio_ind_jornada`,
			}),
			this.replaceDomainByRealValue({
				dateMovements: dateMovements,
				domainKey: `${movementsTableAlias}_dominio_modalidad_dian`,
			}),
			this.replaceDomainByRealValue({
				dateMovements: dateMovements,
				domainKey: `${movementsTableAlias}_dominio_tipo_inconsistencia`,
			}),
			this.replaceDomainByDescription({
				dateMovements: dateMovements,
				domainKey: `${movementsTableAlias}_dominio_forma_pago`,
			}),
			this.replaceDomainByRealValue({
				dateMovements: dateMovements,
				domainKey: `${movementsTableAlias}_dominio_tipo_contable`,
			}),
			this.replaceDomainByDescription({
				dateMovements: dateMovements,
				domainKey: `${movementsTableAlias}_dominio_tipo_formulario`,
			}),
		])

		for (const title of titles) {
			titlesReportColumns.push({ header: title, width: columnWidth })
		}

		worksheet.columns = titlesReportColumns

		dateMovements.map((data: DianMovements): void => {
			worksheet.addRow(Object.values(data))
		})

		const tmpResultExcel: Buffer = await workbook.csv.writeBuffer()

		return tmpResultExcel
	}

	public async reportsHistoricalTable1740(params: {
		consecutive: number | undefined
		startDate: Date | undefined
		endDate: Date | undefined
		offset: number
		limit: number
	}): Promise<ReportsHistoricalsTable1740ResponseDto> {
		const reportsHistoricalTable1740Response: ReportsHistoricalsTable1740ResponseDto =
			new Object() as ReportsHistoricalsTable1740ResponseDto

		const reportsHistoricalsTable1740DataDto: ReportsHistoricalsTable1740DataDto[] =
			[] as ReportsHistoricalsTable1740DataDto[]

		const [dataRegisters, count]: [
			DianReports1740TableDataInterface[],
			number
		] = await this.dianReportsService.reportsHistoricalTable1740({
			consecutive: params.consecutive,
			startDate: params.startDate,
			endDate: params.endDate,
			offset: params.offset,
			limit: params.limit,
		})

		const discriptionsCache: { string: string } = new Object() as {
			string: string
		}

		for (const data of dataRegisters) {
			const dataOutRegister: ReportsHistoricalsTable1740DataDto =
				new Object() as ReportsHistoricalsTable1740DataDto

			// ** info: assignations with special treatements
			dataOutRegister.generationDate = moment(data.generationDate).format(
				"YYYY-MM-DD"
			)

			dataOutRegister.news = data.news ? "Si" : "No"

			if (data.reportType in discriptionsCache) {
				dataOutRegister.reportType = discriptionsCache[data.reportType]
			} else {
				const description: string =
					await this.dianDomainService.getDescriptionByDomainId({
						domainId: data.reportType,
					})
				discriptionsCache[data.reportType] = description
				dataOutRegister.reportType = description
			}

			// ** info: direct assignations
			dataOutRegister.consecutive = data.consecutive
			dataOutRegister.generationUser = data.generationUser
			dataOutRegister.realDate = data.realDate
			dataOutRegister.reportId1740 = data.reportId1740
			dataOutRegister.reportName = data.reportName

			reportsHistoricalsTable1740DataDto.push(dataOutRegister)
		}

		reportsHistoricalTable1740Response.data = reportsHistoricalsTable1740DataDto
		reportsHistoricalTable1740Response.count = count

		return reportsHistoricalTable1740Response
	}

	private async replaceDomainByRealValue(params: {
		dateMovements: DianMovements[]
		domainKey: string
	}): Promise<void> {
		const domainsCache: object = {}
		for (const movement of params.dateMovements) {
			const domainId: number = movement[params.domainKey]
			if (movement !== undefined) {
				if (domainId in domainsCache) {
					movement[params.domainKey] = domainsCache[domainId]
				} else if (!(domainId in domainsCache)) {
					const domainRealValue: string =
						await this.dianDomainService.getRealValueByDomainIdNull(domainId)
					domainsCache[domainId] = domainRealValue
					movement[params.domainKey] = domainRealValue
				}
			} else if (movement === undefined) {
				domainsCache[domainId] = undefined
				movement[params.domainKey] = undefined
			}
		}
	}

	private formatDateToDayEnd(params: { date: Date }): Date {
		const dateYear: number = params.date.getUTCFullYear()
		const dateMonth: number = params.date.getUTCMonth()
		const dateDay: number = params.date.getUTCDate()

		const formatedDate: Date = new Date(dateYear, dateMonth, dateDay)

		formatedDate.setUTCHours(23, 59, 59, 999)

		return formatedDate
	}

	private formatDateToDayStart(params: { date: Date }): Date {
		const dateYear: number = params.date.getUTCFullYear()
		const dateMonth: number = params.date.getUTCMonth()
		const dateDay: number = params.date.getUTCDate()

		const formatedDate: Date = new Date(dateYear, dateMonth, dateDay)

		formatedDate.setUTCHours(0, 0, 0, 0)

		return formatedDate
	}

	private async replaceDomainByDescription(params: {
		dateMovements: DianMovements[]
		domainKey: string
	}): Promise<void> {
		const domainsCache: object = {}
		for (const movement of params.dateMovements) {
			const domainId: number = movement[params.domainKey]
			if (movement !== undefined) {
				if (domainId in domainsCache) {
					movement[params.domainKey] = domainsCache[domainId]
				} else if (!(domainId in domainsCache)) {
					const domainRealValue: string =
						await this.dianDomainService.getDescriptionByDomainIdNull({
							domainId: domainId,
						})
					domainsCache[domainId] = domainRealValue
					movement[params.domainKey] = domainRealValue
				}
			} else if (movement === undefined) {
				domainsCache[domainId] = undefined
				movement[params.domainKey] = undefined
			}
		}
	}

	private isDateBeforeCurrentDate(params: { date: Date }): boolean {
		// ** info: getting Date class object time
		const dateTime: number = params.date.getTime()

		// ** info: todays date
		const todaysDateTime: number = Date.now()

		if (dateTime > todaysDateTime) {
			return false
		}

		return true
	}

	private isoDateString2Date(params: { isoDateString: string }): Date {
		// ** info: parsig iso string to Date class object
		const date: Date = new Date(params.isoDateString)

		// ** if Date class object time is NaN the initial iso string is not a valid date
		if (isNaN(date.getTime())) {
			throw new BadRequestException("invalid date")
		}

		if (!this.isDateBeforeCurrentDate({ date: date })) {
			throw new BadRequestException(
				`the requested date can't be after todays date`
			)
		}

		return date
	}
}
