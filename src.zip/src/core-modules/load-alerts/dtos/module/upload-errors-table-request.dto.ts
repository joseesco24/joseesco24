/** @format */

// ** info: class validator imports
import { IsNumberString } from "class-validator"
import { IsByteLength } from "class-validator"
import { IsNotEmpty } from "class-validator"
import { IsDefined } from "class-validator"
import { IsString } from "class-validator"

// ** info: inheritable dtos imports
import { StartEndDateDto } from "@core-modules/load-alerts/dtos/inheritables/start-end-date.dto"

// todo: implement class transformer transformations here
export class UploadErrorsTableRequestDto extends StartEndDateDto {
	@IsString()
	@IsDefined()
	public readonly fileName!: string

	@IsString()
	@IsNumberString()
	@IsByteLength(1, 2)
	@IsNotEmpty()
	public readonly limit!: string

	@IsString()
	@IsNumberString()
	@IsByteLength(1, 4)
	@IsNotEmpty()
	public readonly offset!: string
}
