/** @format */

import { IsInt, IsNotEmpty, IsString } from "class-validator"

export class ExcelColumns {
	@IsString()
	@IsNotEmpty()
	public header!: string

	@IsInt()
	@IsNotEmpty()
	public width!: number
}
