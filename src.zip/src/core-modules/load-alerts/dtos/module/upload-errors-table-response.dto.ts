/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsDefined } from "class-validator"
import { IsString } from "class-validator"
import { IsArray } from "class-validator"
import { IsInt } from "class-validator"
import { Min } from "class-validator"

// todo: implement class transformer transformations here
export class UploadErrorsTableResponseDto {
	@IsInt()
	@Min(0)
	@IsNotEmpty()
	public count!: number

	@IsDefined()
	@IsArray()
	public data!: UploadErrorsTableDataDto[]

	@IsDefined()
	@IsArray()
	public columns!: UploadErrorsTableColumnsDto[]
}

// todo: implement class transformer transformations here
export class UploadErrorsTableDataDto {
	@IsString()
	@IsNotEmpty()
	public fileName!: string

	@IsInt()
	@IsNotEmpty()
	public totalRegistries!: number

	@IsString()
	@IsNotEmpty()
	public successRegistries!: number

	@IsNotEmpty()
	public failRegistries!: number | string

	@IsString()
	@IsNotEmpty()
	public errorDetail!: string

	@IsNotEmpty()
	public lineNo!: number | string

	@IsString()
	@IsNotEmpty()
	public loadTimestamp!: string
}

// todo: implement class transformer transformations here
export class UploadErrorsTableColumnsDto {
	@IsString()
	@IsNotEmpty()
	public columnDef!: string

	@IsString()
	@IsNotEmpty()
	public header!: string

	@IsString()
	@IsNotEmpty()
	public filter!: boolean
}
