/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsBoolean } from "class-validator"

// todo: implement class transformer transformations here
export class IsUploadErrorsResponseDto {
	@IsBoolean()
	@IsNotEmpty()
	public isUploadErrors!: boolean
}
