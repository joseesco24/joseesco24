/** @format */

// ** info: inheritable dtos imports
import { StartEndDateDto } from "@core-modules/load-alerts/dtos/inheritables/start-end-date.dto"

// todo: implement class transformer transformations here
export class IsCsvDownloadAvailableRequestDto extends StartEndDateDto {}
