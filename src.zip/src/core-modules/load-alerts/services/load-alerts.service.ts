/** @format */

// ** info: nest commons imports
import { HttpException } from "@nestjs/common"
import { Injectable } from "@nestjs/common"
import { HttpStatus } from "@nestjs/common"
import { Logger } from "@nestjs/common"

// ** info: response dtos imports
import { UploadErrorsTableResponseDto } from "@core-modules/load-alerts/dtos/module/upload-errors-table-response.dto"
import { UploadErrorsTableDataDto } from "@core-modules/load-alerts/dtos/module/upload-errors-table-response.dto"
import { UploadErrorsTableColumnsDto } from "@core-modules/load-alerts/dtos/module/upload-errors-table-response.dto"
import { IsUploadErrorsResponseDto } from "@core-modules/load-alerts/dtos/module/is-upload-errors-response.dto"

// ** info: exceljs import
import { Worksheet } from "exceljs"
import { Workbook } from "exceljs"
import { Buffer } from "exceljs"

import { LoadAlertsDbService } from "@common-modules/dian-database/services/load-alerts.db-service"

import { ExcelColumns } from "@core-modules/load-alerts/dtos/module/excel-columns.dto"

// ** info: dtaabase entites imports
import { DianBatchLoad } from "@common-modules/dian-database/entities/dian-batch-load.entity"

import { FoundDomainDescription } from "@common-modules/dian-database/dtos/foundDomainDescription.dto"
import { LoadErrorsFullData } from "@common-modules/dian-database/interfaces/load-errors-full-data.interface"
import { FilesWithoutLoadErrorsDetails } from "@common-modules/dian-database/interfaces/files-without-load-errors-details.interface"
import { DianDomainService } from "@common-modules/dian-database/services/dian-domain.service"

@Injectable()
export class LoadAlertsService {
	private readonly logger: Logger = new Logger(LoadAlertsService.name)

	// todo: replace burned parametrization by params table call
	// ! warning: burned parametrization here [ uploadErrorsDaysSearchRegressionRange ]
	private readonly uploadErrorsDaysSearchRegressionRange: number = 7

	public constructor(
		private readonly loadAlertsDbService: LoadAlertsDbService,
		private readonly dianDomainService: DianDomainService
	) {}

	public async uploadErrorsTable(params: {
		fileName: string
		startDate: Date
		offset: number
		limit: number
		endDate: Date
	}): Promise<UploadErrorsTableResponseDto> {
		const uploadErrorsTableResponse: UploadErrorsTableResponseDto =
			new Object() as UploadErrorsTableResponseDto
		const uploadErrorsTableResponseData: UploadErrorsTableDataDto[] = []
		const columnSpec: UploadErrorsTableColumnsDto[] = []

		const startDate: Date = this.formatDateToDayStart({
			date: params.startDate,
		})
		const endDate: Date = this.formatDateToDayEnd({
			date: params.endDate,
		})

		console.log("###############")
		console.log(endDate, startDate)
		console.log(params.endDate, params.startDate)
		console.log("###############")

		const [loadErrorsFullData, titlesColumnsRaw, titlesFiltersRaw]: [
			LoadErrorsFullData[],
			FoundDomainDescription[],
			FoundDomainDescription[]
		] = await Promise.all([
			this.getLoadsErrorsFullData({
				startDate: startDate,
				endDate: endDate,
			}),
			this.dianDomainService.getDescriptionsByDomain("titulos_tabla_alertas"),
			this.dianDomainService.getDescriptionsByDomain("filtros_tabla_alertas"),
		])

		let limitedLoadErrorsFullData: LoadErrorsFullData[]

		if (
			titlesColumnsRaw.length === undefined ||
			titlesFiltersRaw.length === undefined
		) {
			throw new HttpException(
				"error al cargar la estructura de la tabla",
				HttpStatus.INTERNAL_SERVER_ERROR
			)
		}

		if (titlesColumnsRaw.length === 0 || titlesFiltersRaw.length === 0) {
			throw new HttpException(
				"error al cargar la estructura de la tabla",
				HttpStatus.INTERNAL_SERVER_ERROR
			)
		}

		if (params.fileName !== "") {
			const fileNamePattern: RegExp = new RegExp(`^${params.fileName}`)

			const filteredLoadErrorsFullData: LoadErrorsFullData[] =
				loadErrorsFullData.filter(
					(loadErrorFullData: LoadErrorsFullData): boolean => {
						if (fileNamePattern.test(loadErrorFullData.nombrearchivocargado)) {
							return true
						} else {
							return false
						}
					}
				)

			limitedLoadErrorsFullData = filteredLoadErrorsFullData.slice(
				params.offset,
				params.limit + params.offset
			)
		} else {
			limitedLoadErrorsFullData = loadErrorsFullData.slice(
				params.offset,
				params.limit + params.offset
			)
		}

		limitedLoadErrorsFullData.map(
			(loadErrorFullData: LoadErrorsFullData): void => {
				const uploadErrorsTableDataDto: UploadErrorsTableDataDto =
					new Object() as UploadErrorsTableDataDto

				uploadErrorsTableDataDto.errorDetail =
					loadErrorFullData.descripcionerror
				uploadErrorsTableDataDto.failRegistries =
					loadErrorFullData.cantidadregistrosfallidos
				uploadErrorsTableDataDto.fileName =
					loadErrorFullData.nombrearchivocargado
				uploadErrorsTableDataDto.lineNo = loadErrorFullData.numeroregistroerror
				uploadErrorsTableDataDto.loadTimestamp =
					loadErrorFullData.tiempocarga.toISOString()
				uploadErrorsTableDataDto.successRegistries =
					loadErrorFullData.cantidadregistrosexitosos
				uploadErrorsTableDataDto.totalRegistries =
					loadErrorFullData.cantidadregistros

				uploadErrorsTableResponseData.push(uploadErrorsTableDataDto)
			}
		)

		for (const titleColumnRaw of titlesColumnsRaw) {
			const uploadErrorsTableColumnsDto: UploadErrorsTableColumnsDto =
				new Object() as UploadErrorsTableColumnsDto

			uploadErrorsTableColumnsDto.columnDef = titleColumnRaw.realValue
			uploadErrorsTableColumnsDto.header = titleColumnRaw.domainDescription
			uploadErrorsTableColumnsDto.filter = false

			columnSpec.push(uploadErrorsTableColumnsDto)
		}

		const filtersSet: Set<string> = new Set()

		titlesFiltersRaw.map((filterSpec: FoundDomainDescription): void => {
			filtersSet.add(filterSpec.realValue)
		})

		columnSpec.map((columnSpec: UploadErrorsTableColumnsDto): void => {
			if (filtersSet.has(columnSpec.columnDef)) {
				columnSpec.filter = true
			}
		})

		uploadErrorsTableResponse.columns = columnSpec
		uploadErrorsTableResponse.data = uploadErrorsTableResponseData
		uploadErrorsTableResponse.count = loadErrorsFullData.length

		return uploadErrorsTableResponse
	}

	public async uploadsRegistryFullDataCsv(params: {
		startDate: Date
		endDate: Date
	}): Promise<Buffer> {
		// todo: replace burned parametrization by params table call
		// ! warning: burned parametrization here [ sheetTittle, columnWidth ]
		const sheetTittle: string = "Full Data"
		const columnWidth: number = 30

		// ** info: creating csv init file here
		const workbook: Workbook = new Workbook()

		const worksheet: Worksheet = workbook.addWorksheet(sheetTittle)

		const titlesReportColumns: ExcelColumns[] = []

		const startDate: Date = this.formatDateToDayStart({
			date: params.startDate,
		})
		const endDate: Date = this.formatDateToDayEnd({
			date: params.endDate,
		})

		const loadErrorsFullData: LoadErrorsFullData[] =
			await this.getLoadsErrorsFullData({
				startDate: startDate,
				endDate: endDate,
			})

		const sample: LoadErrorsFullData = loadErrorsFullData[0]

		for (const title of Object.keys(sample)) {
			titlesReportColumns.push({ header: title, width: columnWidth })
		}

		worksheet.columns = titlesReportColumns

		loadErrorsFullData.map((data: LoadErrorsFullData): void => {
			worksheet.addRow(Object.values(data))
		})

		const tmpResultExcel: Buffer = await workbook.csv.writeBuffer()

		return tmpResultExcel
	}

	private async getLoadsErrorsFullData(params: {
		startDate: Date
		endDate: Date
	}): Promise<LoadErrorsFullData[]> {
		const [
			loadErrorsFullDataInDateRange,
			filesWithoutLoadErrorsDetailsInDateRange,
		]: [LoadErrorsFullData[], FilesWithoutLoadErrorsDetails[]] =
			await Promise.all([
				this.loadAlertsDbService.getLoadErrorsFullDataInDateRange({
					startDate: params.startDate,
					endDate: params.endDate,
				}),
				this.loadAlertsDbService.getFilesWithoutLoadErrorsDetailsInDatesRange({
					startDate: params.startDate,
					endDate: params.endDate,
				}),
			])

		let fullData: LoadErrorsFullData[] = []

		if (loadErrorsFullDataInDateRange.length === 0) {
			return fullData
		}

		const sample: LoadErrorsFullData = loadErrorsFullDataInDateRange[0]

		const suceessRegistrys: LoadErrorsFullData[] = []

		if (filesWithoutLoadErrorsDetailsInDateRange.length !== 0) {
			filesWithoutLoadErrorsDetailsInDateRange.map(
				(fileWithoutLoadErrorsDetail: FilesWithoutLoadErrorsDetails): void => {
					const suceessRegistry: LoadErrorsFullData =
						new Object() as LoadErrorsFullData

					for (const title of Object.keys(sample)) {
						if (title in fileWithoutLoadErrorsDetail) {
							suceessRegistry[title] = fileWithoutLoadErrorsDetail[title]
						} else {
							// todo: replace burned parametrization by params table call
							// ! warning: burned parametrization here [ suceessRegistry[title] ]
							suceessRegistry[title] = "N/A"
						}
					}

					suceessRegistrys.push(suceessRegistry)
				}
			)

			fullData = loadErrorsFullDataInDateRange.concat(suceessRegistrys)
		} else {
			fullData = loadErrorsFullDataInDateRange
		}

		fullData.sort((a: LoadErrorsFullData, b: LoadErrorsFullData) => {
			if (a.codigocargue < b.codigocargue) {
				return -1
			} else if (a.codigocargue > b.codigocargue) {
				return 1
			} else {
				return 0
			}
		})

		return fullData
	}

	public async isUploadErrors(): Promise<IsUploadErrorsResponseDto> {
		const isUploadErrorsResponse: IsUploadErrorsResponseDto =
			new Object() as IsUploadErrorsResponseDto

		const endDate: Date = this.formatDateToDayEnd({
			date: this.getTodaysDate(),
		})

		const startDate: Date = this.formatDateToDayStart({
			date: this.subtractDaysToDate({
				initialDate: endDate,
				substractindays: this.uploadErrorsDaysSearchRegressionRange,
			}),
		})

		const [filesWithLoadErrors, filesWithoutLoadErrors]: [
			DianBatchLoad[],
			DianBatchLoad[]
		] = await Promise.all([
			this.loadAlertsDbService.getFileNamesWithLoadErrorsInDatesRange({
				startDate: startDate,
				endDate: endDate,
			}),
			this.loadAlertsDbService.getFileNamesWithoutLoadErrorsInDatesRange({
				startDate: startDate,
				endDate: endDate,
			}),
		])

		const namesFilesWithLoadErrors: Set<string> = new Set()
		const namesFilesWithoutLoadErrors: Set<string> = new Set()

		filesWithLoadErrors.map((fileWithLoadErrorsRegistry: DianBatchLoad) => {
			namesFilesWithLoadErrors.add(
				fileWithLoadErrorsRegistry.nombreArchivoCargado
			)
		})
		filesWithoutLoadErrors.map((fileWithLoadErrorsRegistry: DianBatchLoad) => {
			namesFilesWithoutLoadErrors.add(
				fileWithLoadErrorsRegistry.nombreArchivoCargado
			)
		})

		for (const namesFileWithLoadErrors of namesFilesWithLoadErrors) {
			if (namesFilesWithoutLoadErrors.has(namesFileWithLoadErrors)) {
				continue
			} else {
				isUploadErrorsResponse.isUploadErrors = true
				return isUploadErrorsResponse
			}
		}

		isUploadErrorsResponse.isUploadErrors = false
		return isUploadErrorsResponse
	}

	private subtractDaysToDate(params: {
		substractindays: number
		initialDate: Date
	}): Date {
		const initialDateTime: number = params.initialDate.getTime()
		const oneDay: number = 24 * 60 * 60 * 1000

		const susbstractionTime: number = oneDay * params.substractindays

		const substractedDate: Date = new Date(initialDateTime - susbstractionTime)

		return substractedDate
	}

	private formatDateToDayEnd(params: { date: Date }): Date {
		const dateYear: number = params.date.getUTCFullYear()
		const dateMonth: number = params.date.getUTCMonth()
		const dateDay: number = params.date.getUTCDate()

		const formatedDate: Date = new Date(dateYear, dateMonth, dateDay)

		formatedDate.setUTCHours(23, 59, 59, 999)

		return formatedDate
	}

	private formatDateToDayStart(params: { date: Date }): Date {
		const dateYear: number = params.date.getUTCFullYear()
		const dateMonth: number = params.date.getUTCMonth()
		const dateDay: number = params.date.getUTCDate()

		const formatedDate: Date = new Date(dateYear, dateMonth, dateDay)

		formatedDate.setUTCHours(0, 0, 0, 0)

		return formatedDate
	}

	private getTodaysDate(): Date {
		const todaysDate: Date = new Date()
		return todaysDate
	}
}
