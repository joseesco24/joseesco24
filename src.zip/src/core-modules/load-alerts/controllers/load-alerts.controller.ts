/** @format */

// ** info: node imports
import { posix } from "path"

// ** info: nest commons imports
import { BadRequestException } from "@nestjs/common"
import { Controller } from "@nestjs/common"
import { HttpStatus } from "@nestjs/common"
import { HttpCode } from "@nestjs/common"
import { Query } from "@nestjs/common"
import { Body } from "@nestjs/common"
import { Post } from "@nestjs/common"
import { Get } from "@nestjs/common"
import { Res } from "@nestjs/common"
import { Req } from "@nestjs/common"

// ** info: express imports
import { Response } from "express"
import { Request } from "express"

// ** info: response dtos imports
import { IsCsvDownloadAvailableResponseDto } from "@core-modules/load-alerts/dtos/module/is-csv-download-available-response.dto"
import { UploadErrorsTableResponseDto } from "@core-modules/load-alerts/dtos/module/upload-errors-table-response.dto"
import { IsUploadErrorsResponseDto } from "@core-modules/load-alerts/dtos/module/is-upload-errors-response.dto"

// ** info: request dtos imports
import { UploadsRegistryFullDataCsvRequestDto } from "@core-modules/load-alerts/dtos/module/uploads-registry-full-data-csv-request.dto"
import { IsCsvDownloadAvailableRequestDto } from "@core-modules/load-alerts/dtos/module/is-csv-download-available-request.dto"
import { UploadErrorsTableRequestDto } from "@core-modules/load-alerts/dtos/module/upload-errors-table-request.dto"

// ** info: controller and service import
import { LoadAlertsService } from "@core-modules/load-alerts/services/load-alerts.service"

// ** info: logger service imports
import { LoggingService } from "@common-artifacts/logger-service/logging.service"

// ** info: exceljs import
import { Buffer } from "exceljs"

// ** info: class traosnformer imports
import { instanceToPlain } from "class-transformer"

@Controller("loads-alert")
export class LoadAlertsController {
	// todo: replace burned parametrization by params table call
	// ! warning: burned parametrization here [ maxErrosTableDaysRange ]
	private readonly maxErrosTableDaysRange: number = 7

	// todo: replace burned parametrization by params table call
	// ! warning: burned parametrization here [ maxCsvDaysRange ]
	private readonly maxCsvDaysRange: number = 7

	public constructor(
		private readonly loadAlertsService: LoadAlertsService,
		private readonly loggingService: LoggingService
	) {}

	@HttpCode(HttpStatus.OK)
	@Post(posix.join("is-csv-download-available"))
	public reportsHistoricalTable1188(
		@Body()
		isCsvDownloadAvailableRequest: IsCsvDownloadAvailableRequestDto,
		@Req() request: Request
	): IsCsvDownloadAvailableResponseDto {
		this.loggingService.log(undefined, request)

		const isCsvDownloadAvailableResponse: IsCsvDownloadAvailableResponseDto =
			new Object() as IsCsvDownloadAvailableResponseDto

		// ** info: parsing request values manually due to problems with class transformer
		const startDate: Date = this.isoDateString2Date({
			isoDateString: isCsvDownloadAvailableRequest.start,
		})
		const endDate: Date = this.isoDateString2Date({
			isoDateString: isCsvDownloadAvailableRequest.end,
		})

		// ** info: valdaing dates range
		const isDatesRangeValid: boolean = this.isDatesRangeValid({
			maxDaysRange: this.maxCsvDaysRange,
			start: startDate,
			end: endDate,
		})

		isCsvDownloadAvailableResponse.isCsvDownloadAvailable = isDatesRangeValid

		const secureIsCsvDownloadAvailableResponse: IsCsvDownloadAvailableResponseDto =
			instanceToPlain(
				isCsvDownloadAvailableResponse
			) as IsCsvDownloadAvailableResponseDto

		return secureIsCsvDownloadAvailableResponse
	}

	@HttpCode(HttpStatus.OK)
	@Post(posix.join("upload-errors-table"))
	public async uploadErrorsTable(
		@Body()
		uploadErrorsTableRequest: UploadErrorsTableRequestDto,
		@Req() request: Request
	): Promise<UploadErrorsTableResponseDto> {
		this.loggingService.log(undefined, request)

		// ** info: parsing request values manually due to problems with class transformer
		const startDate: Date = this.isoDateString2Date({
			isoDateString: uploadErrorsTableRequest.start,
		})
		const endDate: Date = this.isoDateString2Date({
			isoDateString: uploadErrorsTableRequest.end,
		})

		const fileName: string = String(uploadErrorsTableRequest.fileName)
		const offset: number = Number(uploadErrorsTableRequest.offset)
		const limit: number = Number(uploadErrorsTableRequest.limit)

		// ** info: valdaing dates range
		const isDatesRangeValid: boolean = this.isDatesRangeValid({
			maxDaysRange: this.maxErrosTableDaysRange,
			start: startDate,
			end: endDate,
		})

		if (!isDatesRangeValid) {
			throw new BadRequestException(`the dates range is above the max allowed`)
		}

		const uploadErrorsTableResponse: UploadErrorsTableResponseDto =
			await this.loadAlertsService.uploadErrorsTable({
				startDate: startDate,
				fileName: fileName,
				endDate: endDate,
				offset: offset,
				limit: limit,
			})

		const secureUploadErrorsTableResponse: UploadErrorsTableResponseDto =
			instanceToPlain(uploadErrorsTableResponse) as UploadErrorsTableResponseDto

		return secureUploadErrorsTableResponse
	}

	@HttpCode(HttpStatus.OK)
	@Get(posix.join("uploads-registry-full-data-csv"))
	public async uploadsRegistryFullDataCsv(
		@Query()
		uploadsRegistryFullDataCsvRequest: UploadsRegistryFullDataCsvRequestDto,
		@Res() response: Response,
		@Req() request: Request
	): Promise<void> {
		this.loggingService.log(undefined, request)

		// todo: replace burned parametrization by params table call
		// ! warning: burned parametrization here [ outputFileName ]
		const outputFileName: string = "fullData"

		// ** info: parsing request values manually due to problems with class transformer
		const startDate: Date = this.isoDateString2Date({
			isoDateString: uploadsRegistryFullDataCsvRequest.start,
		})
		const endDate: Date = this.isoDateString2Date({
			isoDateString: uploadsRegistryFullDataCsvRequest.end,
		})

		// ** info: valdaing dates range
		const isDatesRangeValid: boolean = this.isDatesRangeValid({
			maxDaysRange: this.maxCsvDaysRange,
			start: startDate,
			end: endDate,
		})

		if (!isDatesRangeValid) {
			throw new BadRequestException(`the dates range is above the max allowed`)
		}

		const fullDataReport: Buffer =
			await this.loadAlertsService.uploadsRegistryFullDataCsv({
				startDate: startDate,
				endDate: endDate,
			})

		// ** info: setting up response content type
		response.set("Content-Type", "text/csv")

		response.set(
			"Content-disposition",
			`attachment; filename=${outputFileName}.csv`
		)

		// ** info: sending response
		response.end(fullDataReport)

		return
	}

	@HttpCode(HttpStatus.OK)
	@Get(posix.join("is-upload-errors"))
	public async isUploadErrors(
		@Req() request: Request
	): Promise<IsUploadErrorsResponseDto> {
		this.loggingService.log(undefined, request)

		const isUploadErrorsResponse: IsUploadErrorsResponseDto =
			await this.loadAlertsService.isUploadErrors()

		const secureIsUploadErrorsResponse: IsUploadErrorsResponseDto =
			instanceToPlain(isUploadErrorsResponse) as IsUploadErrorsResponseDto

		return secureIsUploadErrorsResponse
	}

	private isoDateString2Date(params: { isoDateString: string }): Date {
		// ** info: parsig iso string to Date class object
		const date: Date = new Date(params.isoDateString)

		// ** if Date class object time is NaN the initial iso string is not a valid date
		if (isNaN(date.getTime())) {
			throw new BadRequestException("invalid date")
		}

		if (!this.isDateBeforeCurrentDate({ date: date })) {
			throw new BadRequestException(
				`the requested date can't be after todays date`
			)
		}

		return date
	}

	private isDateBeforeCurrentDate(params: { date: Date }): boolean {
		// ** info: getting Date class object time
		const dateTime: number = params.date.getTime()

		// ** info: todays date
		const todaysDateTime: number = Date.now()

		if (dateTime > todaysDateTime) {
			return false
		}

		return true
	}

	private isDatesRangeValid(params: {
		start: Date
		end: Date
		maxDaysRange: number
	}): boolean {
		// ** info: milliseconds of a day
		const oneDay: number = 24 * 60 * 60 * 1000

		// ** info: extracting date time in milliseconds
		const startTime: number = params.start.getTime()
		const endTime: number = params.end.getTime()

		if (startTime > endTime) {
			throw new BadRequestException(
				`the start date can't be after the end date`
			)
		}

		// ** info: checking dates range to be above max
		const diffDays: number = Math.round(Math.abs(endTime - startTime) / oneDay)

		const maxDaysRange: number = params.maxDaysRange

		if (diffDays > maxDaysRange) {
			return false
		}

		return true
	}
}
