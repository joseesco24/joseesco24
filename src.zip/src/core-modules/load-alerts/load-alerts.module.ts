/** @format */

// ** info: nest imports
import { Module } from "@nestjs/common"

// ** info: dian database module import
import { DianDatabaseModule } from "@common-modules/dian-database/dian-database.module"

// ** info: controller and service import
import { LoadAlertsController } from "@core-modules/load-alerts/controllers/load-alerts.controller"
import { LoadAlertsService } from "@core-modules/load-alerts/services/load-alerts.service"

@Module({
	imports: [DianDatabaseModule],
	controllers: [LoadAlertsController],
	providers: [LoadAlertsService],
})
export class LoadAlertsModule {}
