/** @format */

// ** info: node imports
import { posix } from "path"

// ** info: nest commons imports
import { BadRequestException } from "@nestjs/common"
import { Controller } from "@nestjs/common"
import { HttpStatus } from "@nestjs/common"
import { HttpCode } from "@nestjs/common"
import { Body } from "@nestjs/common"
import { Post } from "@nestjs/common"
import { Req } from "@nestjs/common"

// ** info: response dto's imports
import { SummaryTableResponseDto } from "@core-modules/summarys/dtos/summary-table-response.dto"

// ** info: request dto's imports
import { SummaryTableRequestDto } from "@core-modules/summarys/dtos/summary-table-request.dto"

// ** info: offices service import
import { SummarysService } from "@core-modules/summarys/services/summarys.service"

import { LoggingService } from "@common-artifacts/logger-service/logging.service"

import { Request } from "express"

@Controller("summarys")
export class SummarysController {
	public constructor(
		private readonly summarysService: SummarysService,
		private readonly loggingService: LoggingService
	) {}

	@HttpCode(HttpStatus.OK)
	@Post(posix.join("summary-table"))
	public async summaryTable(
		@Body() summaryTableRequestDto: SummaryTableRequestDto,
		@Req() request: Request
	): Promise<SummaryTableResponseDto> {
		this.loggingService.log(undefined, request)
		// ** info: milliseconds of a day
		const oneDay: number = 24 * 60 * 60 * 1000

		// ** info: parsing request values manually due to problems with class transformer
		const earId: number = Number(summaryTableRequestDto.earId)

		const start: Date = new Date(summaryTableRequestDto.start)

		const end: Date = new Date(summaryTableRequestDto.end)

		// ** info: extracting date time in milliseconds
		const startTime: number = start.getTime()
		const endTime: number = end.getTime()

		// ** info: validating the dates values

		if (isNaN(startTime)) {
			throw new BadRequestException("invalid start date")
		}

		if (isNaN(endTime)) {
			throw new BadRequestException("invalid end date")
		}

		// ** info: checking dates range to be above max
		const diffDays: number = Math.round(Math.abs(endTime - startTime) / oneDay)

		// todo: replace burned parametrization by params table call
		// ! warning: burned parametrization here [ maxDaysRange ]
		const maxDaysRange: number = 30

		if (diffDays >= maxDaysRange) {
			throw new BadRequestException(
				`El rango de fechas máximo es ${maxDaysRange} días`
			)
		}

		const summaryTableResponseDto: SummaryTableResponseDto =
			await this.summarysService.summaryTable({
				earId: earId,
				start: start,
				end: end,
			})

		return summaryTableResponseDto
	}
}
