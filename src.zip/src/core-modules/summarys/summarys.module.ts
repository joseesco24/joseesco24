/** @format */

// ** info: nest imports
import { Module } from "@nestjs/common"

// ** info: dian database module import
import { DianDatabaseModule } from "@common-modules/dian-database/dian-database.module"

// ** info: controller and service import
import { SummarysController } from "@core-modules/summarys/controllers/summarys.controller"
import { SummarysService } from "@core-modules/summarys/services/summarys.service"

@Module({
	imports: [DianDatabaseModule],
	controllers: [SummarysController],
	providers: [SummarysService],
})
export class SummarysModule {}
