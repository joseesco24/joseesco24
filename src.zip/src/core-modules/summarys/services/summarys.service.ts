/** @format */

// ** info: nest commons imports
import { Injectable } from "@nestjs/common"

// ** info: dian database module imports
import { DianMovementsService } from "@common-modules/dian-database/services/dian-movements.service"
import { DianDomainService } from "@common-modules/dian-database/services/dian-domain.service"
import { DianTaxService } from "@common-modules/dian-database/services/dian-tax.service"

// ** info: dian database entites repositorioes imports
import { DianTax } from "@common-modules/dian-database/entities/dian-tax.entity"

// ** info: dian database dtos imports
import { FoundDomainDescription } from "@common-modules/dian-database/dtos/foundDomainDescription.dto"

// ** info: dtos imports
import { NotNullishPaymentMethod } from "@common-modules/dian-database/dtos/notNullishPaymentMethod.dto"
import { NotNullishForm } from "@common-modules/dian-database/dtos/notNullishForm.dto"

// ** info: response dto's imports
import { SummaryTableResponseDto } from "@core-modules/summarys/dtos/summary-table-response.dto"

// ** info: moment import
import * as moment from "moment"

@Injectable()
export class SummarysService {
	public constructor(
		private readonly dianMovementsService: DianMovementsService,
		private readonly dianDomainService: DianDomainService,
		private readonly dianTaxService: DianTaxService
	) {}

	// eslint-disable-next-line @typescript-eslint/require-await
	public async summaryTable(params: {
		earId: number
		start: Date
		end: Date
	}): Promise<SummaryTableResponseDto> {
		const summaryTableResponseDto: SummaryTableResponseDto =
			new SummaryTableResponseDto()

		// ** info: fetching not null consolidated by form and payment method, all taxes names, all payment methods names and all forms names at the same time
		const [
			summaryTablePaymentMethods,
			summaryTableForms,
			allActiveTaxNames,
			rawForms,
			rawPaymentMethods,
		]: [
			NotNullishPaymentMethod[],
			NotNullishForm[],
			DianTax[],
			FoundDomainDescription[],
			FoundDomainDescription[]
		] = await Promise.all([
			this.dianMovementsService.summaryTablePaymentMethods({
				earId: params.earId,
				start: params.start,
				end: params.end,
			}),
			this.dianMovementsService.summaryTableForms({
				earId: params.earId,
				start: params.start,
				end: params.end,
			}),
			this.dianTaxService.allActiveTaxNames(),
			this.dianDomainService.getDescriptionsByDomain("tipo_formulario"),
			this.dianDomainService.getDescriptionsByDomain(
				"forma_de_pago_impuestos_dian"
			),
		])

		// ** info: declarating allowed payment methods
		// todo: replace burned parametrization by domain filter
		// ! warning: burned parametrization here [allowedPaymentMethods] set
		const allowedPaymentMethods: Set<string> = new Set([
			"tidis",
			"cert",
			"pse",
			"trt",
		])

		// ** info: declarating allowed payment forms
		// todo: replace burned parametrization by domain filter
		// ! warning: burned parametrization here [allowedPaymentForms] set
		const allowedPaymentForms: Set<string> = new Set([
			"doble código",
			"litográfico",
		])

		// todo: make all this filters async

		// ** info: filtering table payment mehtods
		const filteredPaymentMethods: NotNullishPaymentMethod[] =
			summaryTablePaymentMethods.filter(
				(paymentMethodData: NotNullishPaymentMethod): boolean => {
					const key: string = paymentMethodData.paymentMethod.toLowerCase()
					const filter: Set<string> = allowedPaymentMethods
					if (filter.has(key)) {
						return true
					} else {
						return false
					}
				}
			)

		// ** info: filtering table payment forms
		const filteredPaymentForms: NotNullishForm[] = summaryTableForms.filter(
			(formData: NotNullishForm): boolean => {
				const key: string = formData.paymentForm.toLowerCase()
				const filter: Set<string> = allowedPaymentForms
				if (filter.has(key)) {
					return true
				} else {
					return false
				}
			}
		)

		// ** info: mapping taxes names
		const activeTaxNames: string[] = []
		allActiveTaxNames.map((tax: DianTax) => {
			activeTaxNames.push(tax.taxName)
		})

		// ** info: mapping and filtering payment methods
		const activePaymentMethods: string[] = []
		rawPaymentMethods
			.filter((paymentMethod: FoundDomainDescription) => {
				const key: string = paymentMethod.domainDescription.toLowerCase()
				const filter: Set<string> = allowedPaymentMethods
				if (filter.has(key)) {
					return true
				} else {
					return false
				}
			})
			.map((paymentMethod: FoundDomainDescription) => {
				activePaymentMethods.push(paymentMethod.domainDescription)
			})

		// ** info: mapping and filtering payment forms
		const activePaymentForms: string[] = []
		rawForms
			.filter((paymentForm: FoundDomainDescription) => {
				const key: string = paymentForm.domainDescription.toLowerCase()
				const filter: Set<string> = allowedPaymentForms
				if (filter.has(key)) {
					return true
				} else {
					return false
				}
			})
			.map((paymentForm: FoundDomainDescription) => {
				activePaymentForms.push(paymentForm.domainDescription)
			})

		// ** info: mapping result dates
		// todo: make this map operations async
		const dates: Set<string> = new Set()
		filteredPaymentMethods.map((paymentMethodData: NotNullishPaymentMethod) => {
			dates.add(paymentMethodData.realDate)
		})
		filteredPaymentForms.map((formData: NotNullishForm) => {
			dates.add(formData.realDate)
		})

		// ** info: appending aditional dates
		const startDate: moment.Moment = moment(
			params.start.toISOString(),
			true
		).utc()
		const endDate: moment.Moment = moment(params.end.toISOString(), true).utc()

		const diff: number = endDate.diff(startDate, "day")

		const finalDatesFormat: string = "YYYY-MM-DD"

		dates.add(startDate.format(finalDatesFormat))
		dates.add(endDate.format(finalDatesFormat))

		for (let i: number = 0; i <= diff; i++) {
			const newDate: string = moment(startDate)
				.add(i, "day")
				.utc()
				.format(finalDatesFormat)
			dates.add(newDate)
		}

		// ** info: sorting dates
		const sortedDates: string[] = Array.from(dates).sort()

		// todo: move this interface
		interface ValueCount {
			value: number
			count: number
		}

		const tableColumnsNames: string[] = [
			...activePaymentForms,
			...activePaymentMethods,
		]

		// ** info: initializing table data
		const initialValueCount: ValueCount = { value: 0, count: 0 }

		const initialDetailColumns: object = new Object()

		const paymentMethodInitialDetail: object = new Object()
		const taxInitialDetail: object = new Object()

		tableColumnsNames.map((tableColumnName: string): void => {
			const paymentMethodLabel: string = this.name2label({
				target: tableColumnName,
			})
			paymentMethodInitialDetail[paymentMethodLabel] = initialValueCount
			initialDetailColumns[paymentMethodLabel] = initialValueCount
		})

		const initialTaxesDetail: object = new Object()

		activeTaxNames.map((taxName: string): void => {
			const taxNameLable: string = this.name2label({ target: taxName })
			taxInitialDetail[taxNameLable] = initialValueCount
			initialTaxesDetail[taxNameLable] = initialDetailColumns
		})

		// ! warning: burned labels here
		const detailLabel: string = "detail"
		const sumPaymentMethodLabel: string = "sum_pyment_method"
		const sumTaxLabel: string = "sum_tax"
		const sumLabel: string = "sum"

		const initialDetail: object = new Object()

		initialDetail[detailLabel] = initialTaxesDetail
		initialDetail[sumPaymentMethodLabel] = paymentMethodInitialDetail
		initialDetail[sumTaxLabel] = taxInitialDetail
		initialDetail[sumLabel] = initialValueCount

		sortedDates.map((date: string): void => {
			const dateLabel: string = this.name2label({ target: date })
			summaryTableResponseDto.data[dateLabel] = JSON.parse(
				JSON.stringify(initialDetail)
			)
		})

		// ** info: filling table data

		filteredPaymentForms.map((formData: NotNullishForm) => {
			// ** info: extracting values
			const paymentsValue: number = formData.paymentsValue
			const paymentsCount: number = formData.paymentsCount

			// ** info: extracting labels
			const paymentMethodLabel: string = this.name2label({
				target: formData.paymentForm,
			})
			const paymentDateLabel: string = this.name2label({
				target: formData.realDate,
			})
			const paymentTaxLabel: string = this.name2label({
				target: formData.taxName,
			})

			// ** info: overwriting detail values
			const detailSelection: ValueCount = summaryTableResponseDto.data[
				paymentDateLabel
			].detail[paymentTaxLabel][paymentMethodLabel] as ValueCount

			detailSelection.value = paymentsValue
			detailSelection.count = paymentsCount

			// ** info: appending to taxes sum values
			const taxSelection: ValueCount = summaryTableResponseDto.data[
				paymentDateLabel
			][sumTaxLabel][paymentTaxLabel] as ValueCount

			taxSelection.count += paymentsCount
			taxSelection.value += paymentsValue

			// ** info: appending to payment methods sum values
			const paymentmethodSelection: ValueCount = summaryTableResponseDto.data[
				paymentDateLabel
			][sumPaymentMethodLabel][paymentMethodLabel] as ValueCount

			paymentmethodSelection.count += paymentsCount
			paymentmethodSelection.value += paymentsValue

			// ** info: appending to totals sum values
			const totalsSelection: ValueCount = summaryTableResponseDto.data[
				paymentDateLabel
			][sumLabel] as ValueCount

			totalsSelection.count += paymentsCount
			totalsSelection.value += paymentsValue
		})

		filteredPaymentMethods.map((paymentMethodData: NotNullishPaymentMethod) => {
			// ** info: extracting values
			const paymentsValue: number = paymentMethodData.paymentsValue
			const paymentsCount: number = paymentMethodData.paymentsCount

			// ** info: extracting labels
			const paymentMethodLabel: string = this.name2label({
				target: paymentMethodData.paymentMethod,
			})
			const paymentDateLabel: string = this.name2label({
				target: paymentMethodData.realDate,
			})
			const paymentTaxLabel: string = this.name2label({
				target: paymentMethodData.taxName,
			})

			// ** info: overwriting detail values
			const detailSelection: ValueCount = summaryTableResponseDto.data[
				paymentDateLabel
			].detail[paymentTaxLabel][paymentMethodLabel] as ValueCount

			detailSelection.value = paymentsValue
			detailSelection.count = paymentsCount

			/**
			 * ! warning: This business logic part is really important and you need to be really careful if you are planning to modify this, the thing is that the table uses two column types,
			 * ! forms and payment methods, the forms include the payment methods information, for this reason the consolidations are just based on the forms, if you add the payment methods
			 * ! you are going to get duplicated information, and if you use just the payment methods your information is not going to be complete, its creepy to use just the forms cause it
			 * ! could be understood as a bug, but is the unique option at this point
			 */

			// ** info: appending to taxes sum values
			// todo: define this business logic part
			// ! warning: this lines ar comment because the table taxes values are extracted just from the forms types sum
			/**
			const taxSelection: ValueCount = summaryTableResponseDto.data[
				paymentDateLabel
			][sumTaxLabel][paymentTaxLabel] as ValueCount

			taxSelection.count += paymentsCount
			taxSelection.value += paymentsValue
			*/

			// ** info: appending to payment methods sum values
			const paymentmethodSelection: ValueCount = summaryTableResponseDto.data[
				paymentDateLabel
			][sumPaymentMethodLabel][paymentMethodLabel] as ValueCount

			paymentmethodSelection.count += paymentsCount
			paymentmethodSelection.value += paymentsValue

			// ** info: appending to totals sum values
			// todo: define this business logic part
			// ! warning: this lines ar comment because the table totals values are extracted just from the forms types sum
			/*
			const totalsSelection: ValueCount = summaryTableResponseDto.data[
				paymentDateLabel
			][sumLabel] as ValueCount

			totalsSelection.count += paymentsCount
			totalsSelection.value += paymentsValue
			*/
		})

		// ! warning: burned key here [taxeskey]
		const taxeskey: string = "taxes"
		const taxesObj: object = new Object()

		for (const activeTaxName of activeTaxNames) {
			taxesObj[this.name2label({ target: activeTaxName })] = activeTaxName
		}

		summaryTableResponseDto.render[taxeskey] = taxesObj

		// ! warning: burned key here [paymentMethodskey]
		const paymentMethodskey: string = "payment_methods"
		const paymentMethodsObj: object = new Object()

		for (const paymentMethodName of tableColumnsNames) {
			paymentMethodsObj[this.name2label({ target: paymentMethodName })] =
				paymentMethodName
		}

		summaryTableResponseDto.render[paymentMethodskey] = paymentMethodsObj

		return summaryTableResponseDto
	}

	// todo: move this method to artifacts
	private name2label(params: { target: string }): string {
		const label: string = params.target
			.toLowerCase()
			.trim()
			.replace(/[.,]/g, "")
			.normalize("NFD")
			.replace(/[\u0300-\u036f]/g, "")
			.replace(/\s+/g, "_")

		return label
	}
}
