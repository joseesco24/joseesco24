/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsString } from "class-validator"
import { IsInt } from "class-validator"

// ** info: the object schema is defined by the summary service
// todo: improve this object schema
// ! warning: undefined object schema
export class SummaryTableResponseDto {
	@IsInt()
	@IsNotEmpty()
	public render: object = new Object()

	@IsString()
	@IsNotEmpty()
	public data: object = new Object()
}
