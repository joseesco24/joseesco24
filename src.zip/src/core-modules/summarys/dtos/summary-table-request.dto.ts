/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsString } from "class-validator"
import { Matches } from "class-validator"
import { IsInt } from "class-validator"
import { Min } from "class-validator"
import { Max } from "class-validator"

// todo: implement class transformer transformations here
export class SummaryTableRequestDto {
	@IsInt()
	@Min(1)
	@Max(99999)
	@IsNotEmpty()
	public readonly earId!: number

	@IsString()
	@Matches(RegExp("^[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}$"))
	@IsNotEmpty()
	public readonly start!: string

	@IsString()
	@Matches(RegExp("^[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}$"))
	@IsNotEmpty()
	public readonly end!: string
}
