/** @format */

// ** info: nest commons imports
import { UseFilters } from "@nestjs/common"
import { Controller } from "@nestjs/common"
import { HttpCode } from "@nestjs/common"
import { Body } from "@nestjs/common"
import { Post } from "@nestjs/common"
import { Req } from "@nestjs/common"

// ** info: module service providers imports
import { DianTransversalService } from "@core-modules/transversal/services/dian-transversal.service"

// ** info: response dto's imports
import { TableStructResponse } from "@core-modules/transversal/dtos/table-struct-response.dto"
import { ParameterResponse } from "@core-modules/transversal/dtos/parameter-response.dto"
import { TypeListResponse } from "@core-modules/transversal/dtos/type-list-response.dto"

// ** info: request dto's imports
import { TableStructRequest } from "@core-modules/transversal/dtos/table-struct-request.dto"
import { TypeListRequest } from "@core-modules/transversal/dtos/type-list-request.dto"
import { ParameterRequest } from "@core-modules/transversal/dtos/parameter-request.dto"

// ** info: common artifacts imports
import { AllExceptionsFilter } from "@common-artifacts/decorators/all-exceptions.filter"

import { LoggingService } from "@common-artifacts/logger-service/logging.service"

import { Request } from "express"

@UseFilters(AllExceptionsFilter)
@Controller("transversals")
export class DianTransversalController {
	public constructor(
		private readonly dianTransversalService: DianTransversalService,
		private readonly loggingService: LoggingService
	) {}

	@HttpCode(200)
	@Post("/domain-list")
	public async findTypeList(
		@Body() body: TypeListRequest,
		@Req() request: Request
	): Promise<TypeListResponse[]> {
		this.loggingService.log(undefined, request)
		return await this.dianTransversalService.findTypeList(body.domainType)
	}

	@Post("/parameters")
	@HttpCode(200)
	public async getParameter(
		@Body() requestParameter: ParameterRequest,
		@Req() request: Request
	): Promise<ParameterResponse[]> {
		this.loggingService.log(undefined, request)
		return await this.dianTransversalService.getParam(requestParameter)
	}

	@Post("/domain-table-struct")
	@HttpCode(200)
	public async getTableStruct(
		@Body() tableStructRequest: TableStructRequest,
		@Req() request: Request
	): Promise<TableStructResponse> {
		this.loggingService.log(undefined, request)
		return await this.dianTransversalService.getTableStruct(tableStructRequest)
	}
}
