/** @format */

// ** info: nest commons imports
import { Module } from "@nestjs/common"

// ** info: dian databse module import
import { DianDatabaseModule } from "@common-modules/dian-database/dian-database.module"

// ** info: this module services controllers imports
import { DianTransversalService } from "@core-modules/transversal/services/dian-transversal.service"

// ** info: this module controllers imports
import { DianTransversalController } from "@core-modules/transversal/controllers/dian-transversal.controller"

@Module({
	imports: [DianDatabaseModule],
	providers: [DianTransversalService],
	controllers: [DianTransversalController],
})
export class DianTransversalModule {}
