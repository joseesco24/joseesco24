/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsBoolean } from "class-validator"
import { IsString } from "class-validator"

// ** info: class transformer imports
import { Type } from "class-transformer"

export class TableStructResponse {
	@Type(() => TitleTableColumns)
	@IsNotEmpty()
	public readonly columns!: TitleTableColumns[]
}

export class TitleTableColumns {
	@IsString()
	@IsNotEmpty()
	public columnDef!: string

	@IsString()
	@IsNotEmpty()
	public header!: string

	@IsBoolean()
	@IsNotEmpty()
	public filter!: boolean
}
