/** @format */

// ** info: class validator imports
import { IsString } from "class-validator"

export class ParameterResponse {
	@IsString()
	public readonly parameterCode!: string

	@IsString()
	public readonly value!: string
}
