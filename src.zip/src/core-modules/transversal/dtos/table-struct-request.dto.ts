/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsString } from "class-validator"

export class TableStructRequest {
	@IsNotEmpty()
	@IsString()
	public readonly tableTitles: string

	@IsNotEmpty()
	@IsString()
	public readonly tableFilters: string
}
