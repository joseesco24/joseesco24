/** @format */

// ** info: class validator imports
import { IsNumber } from "class-validator"
import { IsString } from "class-validator"

export class TypeListResponse {
	@IsString()
	public readonly viewValue!: string

	@IsNumber()
	public readonly value!: number
}
