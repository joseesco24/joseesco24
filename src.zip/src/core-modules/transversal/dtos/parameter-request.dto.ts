/** @format */

// ** info: class validator imports
import { ArrayNotEmpty } from "class-validator"
import { IsString } from "class-validator"
import { IsArray } from "class-validator"

export class ParameterRequest {
	@IsArray()
	@IsString({ each: true })
	@ArrayNotEmpty()
	public readonly parameterCodes!: string[]
}
