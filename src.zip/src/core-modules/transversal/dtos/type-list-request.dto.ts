/** @format */

// ** info: class validator imports
import { IsNotEmpty } from "class-validator"
import { IsString } from "class-validator"

export class TypeListRequest {
	@IsNotEmpty()
	@IsString()
	public readonly domainType: string
}
