/** @format */

// ** info: nest imports
import { Injectable } from "@nestjs/common"

// ** info: response dto's imports
import { TableStructResponse } from "@core-modules/transversal/dtos/table-struct-response.dto"
import { TitleTableColumns } from "@core-modules/transversal/dtos/table-struct-response.dto"
import { ParameterResponse } from "@core-modules/transversal/dtos/parameter-response.dto"
import { TypeListResponse } from "@core-modules/transversal/dtos/type-list-response.dto"

// ** info: request dto's imports
import { TableStructRequest } from "@core-modules/transversal/dtos/table-struct-request.dto"
import { ParameterRequest } from "@core-modules/transversal/dtos/parameter-request.dto"

// ** info: common services imports
import { DianDomainService } from "@common-modules/dian-database/services/dian-domain.service"
import { DianParamService } from "@common-modules/dian-database/services/dian-param.service"

// ** info: common dto's imports
import { FoundDomainDescription } from "@common-modules/dian-database/dtos/foundDomainDescription.dto"

@Injectable()
export class DianTransversalService {
	public constructor(
		private readonly dianDomainService: DianDomainService,
		private readonly dianParamService: DianParamService
	) {}

	public async findTypeList(typeDomain: string): Promise<TypeListResponse[]> {
		const dataResponseArray: TypeListResponse[] = []

		const domainsRaw: FoundDomainDescription[] =
			await this.dianDomainService.getDescriptionsByDomain(typeDomain)

		if (domainsRaw.length === 0) {
			return dataResponseArray
		} else {
			domainsRaw.map((domain: any) => {
				const dataResponse: TypeListResponse = {
					value: domain.domainId,
					viewValue: domain.domainDescription,
				}
				dataResponseArray.push(dataResponse)
			})
			return dataResponseArray
		}
	}

	public async getParam(
		requestParameter: ParameterRequest
	): Promise<ParameterResponse[]> {
		return await this.dianParamService.getParameterValArray(
			requestParameter.parameterCodes
		)
	}

	public async getTableStruct(
		tableStructRequest: TableStructRequest
	): Promise<TableStructResponse> {
		//get table titles from DB
		const titlesColumnsRaw: FoundDomainDescription[] =
			await this.dianDomainService.getDescriptionsByDomain(
				tableStructRequest.tableTitles
			)

		//get columns with filter from DB
		const filterColumnsRaw: FoundDomainDescription[] =
			await this.dianDomainService.getDescriptionsByDomain(
				tableStructRequest.tableFilters
			)

		//build titleResponse schema
		const titlesResponseColumns: TitleTableColumns[] = titlesColumnsRaw.map(
			(title: any) => {
				return {
					columnDef: title.realValue,
					header: title.domainDescription,
					filter: false,
				}
			}
		)

		//change filtre true to columns with filter in db
		titlesResponseColumns.forEach((title: any) => {
			filterColumnsRaw.forEach((filter: any) => {
				if (title.columnDef === filter.realValue) {
					title.filter = true
				}
			})
		})

		//build response schema if data
		const response: any = {
			columns: titlesResponseColumns,
		}

		return response
	}
}
