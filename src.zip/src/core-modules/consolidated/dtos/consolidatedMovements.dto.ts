/** @format */

import { IsNotEmpty, IsNumber } from "class-validator"

export class ConsolidatedMovements {
	@IsNotEmpty()
	@IsNumber()
	public enero!: number

	@IsNotEmpty()
	@IsNumber()
	public febrero!: number

	@IsNotEmpty()
	@IsNumber()
	public marzo!: number

	@IsNotEmpty()
	@IsNumber()
	public abril!: number

	@IsNotEmpty()
	@IsNumber()
	public mayo!: number

	@IsNotEmpty()
	@IsNumber()
	public junio!: number

	@IsNotEmpty()
	@IsNumber()
	public julio!: number

	@IsNotEmpty()
	@IsNumber()
	public agosto!: number

	@IsNotEmpty()
	@IsNumber()
	public septiembre!: number

	@IsNotEmpty()
	@IsNumber()
	public octubre!: number

	@IsNotEmpty()
	@IsNumber()
	public noviembre!: number

	@IsNotEmpty()
	@IsNumber()
	public diciembre!: number
}
