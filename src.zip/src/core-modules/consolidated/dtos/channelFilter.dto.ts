/** @format */

import { IsNotEmpty, IsNumber, IsString } from "class-validator"

export class ChannelFilter {
	@IsNotEmpty()
	@IsString()
	public domainDescription!: string

	@IsNotEmpty()
	@IsNumber()
	public domainId!: number

	@IsNumber({}, { each: true })
	public channelInd: number[]

	@IsNotEmpty()
	@IsString()
	public column!: string
}
