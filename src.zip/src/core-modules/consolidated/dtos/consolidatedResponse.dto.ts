/** @format */

import { Type } from "class-transformer"
import { IsNotEmpty } from "class-validator"
import { ConsolidatedMovements } from "./consolidatedMovements.dto"

export class ConsolidatedResponse {
	@Type(() => ConsolidatedMovements)
	@IsNotEmpty()
	public value!: ConsolidatedMovements

	@Type(() => ConsolidatedMovements)
	@IsNotEmpty()
	public count!: ConsolidatedMovements
}
