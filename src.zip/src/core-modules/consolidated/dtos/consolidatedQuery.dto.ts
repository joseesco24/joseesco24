/** @format */

import { Transform, TransformFnParams } from "class-transformer"
import { IsInt, IsOptional } from "class-validator"

export class ConsolidatedQuery {
	@Transform((param: TransformFnParams) => Number(param.value))
	@IsInt()
	@IsOptional()
	public filter?: number

	@Transform((param: TransformFnParams) => Number(param.value))
	@IsInt()
	public year: number
}
