/** @format */

import { DianDatabaseModule } from "@common-modules/dian-database/dian-database.module"
import { DianDomainService } from "@common-modules/dian-database/services/dian-domain.service"
import { DianMovementsService } from "@common-modules/dian-database/services/dian-movements.service"
import { Module } from "@nestjs/common"
import { ConsolidatedController } from "./controllers/consolidated.controller"
import { ConsolidatedService } from "./services/consolidated.service"

@Module({
	controllers: [ConsolidatedController],
	imports: [DianDatabaseModule],
	providers: [DianDomainService, DianMovementsService, ConsolidatedService],
})
export class ConsolidatedModule {}
