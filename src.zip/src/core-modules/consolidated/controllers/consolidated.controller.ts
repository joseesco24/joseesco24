/** @format */

import {
	Body,
	Controller,
	Post,
	ServiceUnavailableException,
	UseFilters,
	Req,
} from "@nestjs/common"
import { AllExceptionsFilter } from "@common-artifacts/decorators/all-exceptions.filter"
import { ConsolidatedQuery } from "@core-modules/consolidated/dtos/consolidatedQuery.dto"
import { ConsolidatedService } from "@core-modules/consolidated/services/consolidated.service"
import { ConsolidatedResponse } from "@core-modules/consolidated/dtos/consolidatedResponse.dto"
import { DianDomainService } from "@common-modules/dian-database/services/dian-domain.service"
import {
	consChannelDefaultDomain,
	databaseErrorMessage,
} from "@common-artifacts/constants/constants"
import { posix } from "path"
import { FoundDomainDescription } from "@common-modules/dian-database/dtos/foundDomainDescription.dto"

// ** info: logger service imports
import { LoggingService } from "@common-artifacts/logger-service/logging.service"

import { Request } from "express"

@UseFilters(AllExceptionsFilter)
@Controller("consolidated")
export class ConsolidatedController {
	public constructor(
		private readonly consolidatedService: ConsolidatedService,
		private readonly dianDomainService: DianDomainService,
		private readonly loggingService: LoggingService
	) {}

	@Post(posix.join("graphics-consolidated"))
	public async findConsolidatedMovements(
		@Body() body: ConsolidatedQuery,
		@Req() request: Request
	): Promise<ConsolidatedResponse> {
		this.loggingService.log(undefined, request)
		if (body.filter === undefined) {
			const channelConsolidateddomain: FoundDomainDescription[] =
				await this.dianDomainService.getDescriptionsByDomain(
					consChannelDefaultDomain
				)
			if (channelConsolidateddomain.length === 0) {
				try {
					const errorMessage: string =
						await this.dianDomainService.getRealValueByDomainId(
							databaseErrorMessage
						)
					throw new ServiceUnavailableException(`${errorMessage}`)
				} catch (e: any) {
					throw new ServiceUnavailableException(e.message)
				}
			}
			body.filter = Number(channelConsolidateddomain[0].realValue)
			return await this.consolidatedService.findConsolidatedMovements(
				body.filter,
				body.year
			)
		} else {
			return await this.consolidatedService.findConsolidatedMovements(
				body.filter,
				body.year
			)
		}
	}
}
