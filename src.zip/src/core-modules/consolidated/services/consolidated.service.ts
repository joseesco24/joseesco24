/** @format */

import { DianMovementsService } from "@common-modules/dian-database/services/dian-movements.service"
import { Injectable } from "@nestjs/common"
import {
	consChannelDefaultDomain,
	consolidatedChannelDomain,
	consolidatedColumnsQuery,
	consolidatedtypeFormDomain,
	months,
} from "@common-artifacts/constants/constants"
import { ConsolidatedMovements } from "../dtos/consolidatedMovements.dto"
import { MovementsByMonth } from "@common-modules/dian-database/dtos/movementsByMonth.dto"
import { plainToInstance } from "class-transformer"
import { ConsolidatedResponse } from "../dtos/consolidatedResponse.dto"
import { DianDomainService } from "@common-modules/dian-database/services/dian-domain.service"
import { ValidationException } from "@common-artifacts/decorators/validation.filter"
import { ChannelFilter } from "@core-modules/consolidated/dtos/channelFilter.dto"
import { FoundDomainDescription } from "@common-modules/dian-database/dtos/foundDomainDescription.dto"

@Injectable()
export class ConsolidatedService {
	public constructor(
		private readonly dianMovementsService: DianMovementsService,
		private readonly dianDomainService: DianDomainService
	) {}

	public async findConsolidatedMovements(
		filter: number,
		year: number
	): Promise</*ConsolidatedResponse*/ any> {
		const consolidatedMovementsValue: object = {}
		const consolidatedMovementsCount: object = {}
		//Get Filter for all consolidated
		const defaultFilter: FoundDomainDescription[] =
			await this.dianDomainService.getDescriptionsByDomain(
				consChannelDefaultDomain
			)
		//filter input validation with BD domain
		const paymentMethodDomain: FoundDomainDescription[] =
			await this.dianDomainService.getDescriptionsByDomain(
				consolidatedChannelDomain
			)
		// get the consolidated filter by form type
		const formTypeConsolidatedDomain: FoundDomainDescription[] =
			await this.dianDomainService.getDescriptionsByDomain(
				consolidatedtypeFormDomain
			)
		let channelConsolidateddomain: FoundDomainDescription[] =
			formTypeConsolidatedDomain.concat(paymentMethodDomain)
		channelConsolidateddomain = channelConsolidateddomain.concat(defaultFilter)

		//Sort arrays by id
		channelConsolidateddomain.sort(function (a: any, b: any) {
			return -(
				a.domainId - b.domainId ||
				a.domainDescription.localeCompare(b.domainDescription)
			)
		})

		const channelConsolidatedIds: number[] = channelConsolidateddomain.map(
			(channel: any) => channel.domainId
		)

		if (!channelConsolidatedIds.includes(filter)) {
			throw new ValidationException(
				"Bad Request. Datos de entrada no validos: filter"
			)
		}

		const channelColumns: any =
			await this.dianDomainService.getDescriptionsByDomain(
				consolidatedColumnsQuery
			)

		const channelConsolidated: ChannelFilter[] = channelConsolidateddomain.map(
			(channel: any) => {
				const realValuesNumbers: number[] = []
				let channelColumnDescription: string = "undefined"

				channelColumns.map((channelColumn: any) => {
					if (channel.domainId === Number(channelColumn.realValue)) {
						realValuesNumbers.push(Number(channelColumn.realValue))
						channelColumnDescription = channelColumn.domainDescription
					}
				})
				return {
					domainDescription: channel.domainDescription,
					domainId: channel.domainId,
					channelInd: realValuesNumbers,
					column: channelColumnDescription,
				}
			}
		)

		const channelfilter: ChannelFilter = channelConsolidated.filter(
			(channel: any) => channel.domainId === filter
		)[0]

		const movementsByMonth: MovementsByMonth[] =
			await this.dianMovementsService.findConsolidatedMovements(
				channelfilter,
				year
			)

		//In case no payments, all months must be zero
		if (movementsByMonth.length === 0) {
			Object.values(months).forEach((month: any) => {
				consolidatedMovementsValue[month] = 0
			})
		}

		//build consolidated movements value
		movementsByMonth.forEach((movementByMonth: any) => {
			if (Object.keys(months).includes(movementByMonth.month)) {
				consolidatedMovementsValue[months[movementByMonth.month]] = Math.trunc(
					Number(movementByMonth.paymentValueSum)
				)
			}

			Object.values(months).forEach((month: any) => {
				if (!Object.keys(consolidatedMovementsValue).includes(month)) {
					consolidatedMovementsValue[month] = 0
				}
			})
		})

		//build consolidated movements count
		movementsByMonth.forEach((movementByMonth: any) => {
			if (Object.keys(months).includes(movementByMonth.month)) {
				consolidatedMovementsCount[months[movementByMonth.month]] = Number(
					movementByMonth.count
				)
			}

			Object.values(months).forEach((month: any) => {
				if (!Object.keys(consolidatedMovementsCount).includes(month)) {
					consolidatedMovementsCount[month] = 0
				}
			})
		})

		const consolidatedValuesOrdered: object = await this.objOrderedByMonth(
			consolidatedMovementsValue
		)
		const consolidatedCountOrdered: object = await this.objOrderedByMonth(
			consolidatedMovementsCount
		)

		const valuesDataDto: ConsolidatedMovements = plainToInstance(
			ConsolidatedMovements,
			consolidatedValuesOrdered
		)
		//! wrning: comment validation method as a bug provisional fixing.
		// await validateOrReject(valuesDataDto)

		const countDataDto: ConsolidatedMovements = plainToInstance(
			ConsolidatedMovements,
			consolidatedCountOrdered
		)
		//! warning: comment validation method as a bug provisional fixing.
		// await validateOrReject(countDataDto)

		//build response structure
		const data: ConsolidatedResponse = {
			value: valuesDataDto,
			count: countDataDto,
		}

		const filters: any = channelConsolidateddomain.map((channel: any) => {
			let name: string = channel.domainDescription.toUpperCase()
			if (channel.domainDescription.toLowerCase() === "undefined") {
				name = "TODOS"
			}
			return {
				id: channel.domainId,
				name: name,
			}
		})

		const response: object = {
			data: data,
			filters: filters,
		}
		return response
	}

	public objOrderedByMonth(objNotSorted: any): any {
		const objSortedmonths: object = {}
		const monthNames: any = Object.values(months)

		for (const month of monthNames) {
			if (Object.prototype.hasOwnProperty.call(objNotSorted, month)) {
				objSortedmonths[month] = objNotSorted[month]
			}
		}
		return objSortedmonths
	}
}
