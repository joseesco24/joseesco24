/** @format */

import {
	IsNumberString,
	IsInt,
	IsString,
	IsNotEmpty,
	IsBoolean,
} from "class-validator"

import { Type } from "class-transformer"
import { boolean, number, string } from "joi"

export class MovsByIdResponse {
	@IsNotEmpty()
	@Type(() => DataIdResponse)
	public data: DataIdResponse

	@IsNotEmpty()
	@IsInt()
	@Type(() => number)
	public modifiableFields: DataFieldResponse
}

export class DataIdResponse {
	@IsInt()
	@IsNotEmpty()
	@Type(() => number)
	public declarationNumber: number

	@IsNumberString()
	@IsNotEmpty()
	@Type(() => string)
	public adhesiveOrCus: string

	@IsInt()
	@IsNotEmpty()
	@Type(() => number)
	public earId: number

	@IsString()
	@IsNotEmpty()
	@Type(() => string)
	public realDate: string

	@IsInt()
	@IsNotEmpty()
	@Type(() => number)
	public formType: number

	@IsNumberString()
	@IsNotEmpty()
	@Type(() => string)
	public nitOrId: string

	@IsInt()
	@IsNotEmpty()
	@Type(() => number)
	public paymentFormId: string

	@IsNumberString()
	@IsNotEmpty()
	@Type(() => string)
	public paymentValue: string

	@IsInt()
	@IsNotEmpty()
	@Type(() => number)
	public formId: number

	@IsInt()
	@IsNotEmpty()
	@Type(() => number)
	public conceptId: number

	@IsInt()
	@IsNotEmpty()
	@Type(() => number)
	public dayTypeId: number

	@IsString()
	@IsNotEmpty()
	@Type(() => string)
	public limitPaymentDate: string

	@IsInt()
	@IsNotEmpty()
	@Type(() => number)
	public operationNumber: number

	@IsInt()
	@IsNotEmpty()
	@Type(() => number)
	public hashNumber: number

	@IsInt()
	@IsNotEmpty()
	@Type(() => number)
	public authorizationNumber: number

	@IsNumberString()
	@IsNotEmpty()
	@Type(() => string)
	public tellerCode: string
}

export class DataFieldResponse {
	@IsBoolean()
	@IsNotEmpty()
	@Type(() => boolean)
	public declarationNumber: boolean

	@IsBoolean()
	@IsNotEmpty()
	@Type(() => boolean)
	public adhesiveOrCus: boolean

	@IsBoolean()
	@IsNotEmpty()
	@Type(() => boolean)
	public earId: boolean

	@IsBoolean()
	@IsNotEmpty()
	@Type(() => boolean)
	public realDate: boolean

	@IsBoolean()
	@IsNotEmpty()
	@Type(() => boolean)
	public formType: boolean

	@IsBoolean()
	@IsNotEmpty()
	@Type(() => boolean)
	public nitOrId: boolean

	@IsBoolean()
	@IsNotEmpty()
	@Type(() => boolean)
	public paymentFormId: boolean

	@IsBoolean()
	@IsNotEmpty()
	@Type(() => boolean)
	public paymentValue: boolean

	@IsBoolean()
	@IsNotEmpty()
	@Type(() => boolean)
	public formId: boolean

	@IsBoolean()
	@IsNotEmpty()
	@Type(() => boolean)
	public conceptId: boolean

	@IsBoolean()
	@IsNotEmpty()
	@Type(() => boolean)
	public dayTypeId: boolean

	@IsBoolean()
	@IsNotEmpty()
	@Type(() => boolean)
	public limitPaymentDate: boolean

	@IsBoolean()
	@IsNotEmpty()
	@Type(() => boolean)
	public operationNumber: boolean

	@IsBoolean()
	@IsNotEmpty()
	@Type(() => boolean)
	public hashNumber: boolean

	@IsBoolean()
	@IsNotEmpty()
	@Type(() => boolean)
	public authorizationNumber: boolean

	@IsBoolean()
	@IsNotEmpty()
	@Type(() => boolean)
	public tellerCode: boolean
}
