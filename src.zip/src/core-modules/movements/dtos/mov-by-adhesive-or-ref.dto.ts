/** @format */

import { IsNumberString } from "class-validator"
import { IsNotEmpty } from "class-validator"
import { IsInt } from "class-validator"

import { Type } from "class-transformer"
import { number, string } from "joi"

export class MovsTableByAdhesiveResponse {
	@IsNotEmpty()
	@Type(() => DataAdhesiveResponse)
	public data: DataAdhesiveResponse[]

	@IsNotEmpty()
	@IsInt()
	@Type(() => number)
	public count: number
}

export class DataAdhesiveResponse {
	@IsNumberString()
	@IsNotEmpty()
	@Type(() => string)
	public nitOrId: string

	@IsNumberString()
	@IsNotEmpty()
	@Type(() => string)
	public adhesiveOrCus: string

	@IsNumberString()
	@IsNotEmpty()
	@Type(() => string)
	public declarationNumber: string

	@IsNumberString()
	@IsNotEmpty()
	@Type(() => string)
	public collectedValue: string

	@IsNumberString()
	@IsNotEmpty()
	@Type(() => string)
	public formId: string

	@IsNumberString()
	@IsNotEmpty()
	@Type(() => string)
	public conceptId: string

	@IsNumberString()
	@IsNotEmpty()
	@Type(() => string)
	public earId: string

	@IsNumberString()
	@IsNotEmpty()
	@Type(() => string)
	public realDate: string
}
