/** @format */

import { IsNumberString } from "class-validator"
import { IsNotEmpty } from "class-validator"
import { IsInt } from "class-validator"

import { Type } from "class-transformer"

export class FindMovByNumber {
	@IsNotEmpty()
	@IsInt()
	@Type(() => Number)
	public year!: number

	@IsNotEmpty()
	@IsInt()
	@Type(() => Number)
	public referenceType!: number

	@IsNotEmpty()
	@IsNumberString()
	public referenceNumber!: string

	@IsNotEmpty()
	@IsInt()
	@Type(() => Number)
	public offset!: number

	@IsNotEmpty()
	@IsInt()
	@Type(() => Number)
	public limit!: number
}
