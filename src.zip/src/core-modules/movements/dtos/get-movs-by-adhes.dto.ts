/** @format */

import { IsNumberString } from "class-validator"
import { IsNotEmpty } from "class-validator"

export class GetMovsByAdhes {
	@IsNotEmpty()
	@IsNumberString()
	public search: string
}
