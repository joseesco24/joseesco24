/** @format */

import { IsNotEmpty } from "class-validator"
import { IsInt } from "class-validator"

export class FindMovById {
	@IsNotEmpty()
	@IsInt()
	public movementId: number
}
