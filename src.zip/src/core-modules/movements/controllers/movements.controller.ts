/** @format */

import {
	BadRequestException,
	Body,
	Controller,
	HttpCode,
	Post,
	Req,
} from "@nestjs/common"
import { posix } from "path"
/**
 * Custom Imports for controllers
 */
import { FindMovByNumber } from "@core-modules/movements/dtos/find-mov-by-number.dto"
import { DianDomainService } from "@common-modules/dian-database/services/dian-domain.service"
import { FoundDomainDescription } from "@common-modules/dian-database/dtos/foundDomainDescription.dto"
import { MovementsService } from "@core-modules/movements/services/movements.service"
import { GetMovsByAdhes } from "../dtos/get-movs-by-adhes.dto"
import { FindMovById } from "../dtos/find-movs-by-id.dto"
import { MovsByIdResponse } from "../dtos/movs-by-id-response.dto"

import { LoggingService } from "@common-artifacts/logger-service/logging.service"

import { Request } from "express"

@Controller("movements")
export class MovementsController {
	public constructor(
		private readonly dianDomainService: DianDomainService,
		private readonly movementService: MovementsService,
		private readonly loggingService: LoggingService
	) {}
	@HttpCode(200)
	@Post(posix.join("movements-table"))
	public async getAllTableBySearch(
		@Body() findMovsRequest: FindMovByNumber,
		@Req() request: Request
	): Promise<object> {
		this.loggingService.log(undefined, request)
		const currentYear: number = Number(new Date().getFullYear())
		const yearBySearch: FoundDomainDescription[] =
			await this.dianDomainService.getDescriptionsByDomain(
				"delta_year_by_search"
			)

		const yearDelta: number =
			yearBySearch.length > 0 ? Number(yearBySearch[0].realValue) : 0

		const minYear: number = currentYear - (yearDelta + 1)

		const allowedDomainValues: number[] = []

		const domainsRaw: FoundDomainDescription[] =
			await this.dianDomainService.getDescriptionsByDomain("adh_ref_list")

		for (const domain of domainsRaw) {
			allowedDomainValues.push(domain.domainId)
		}

		if (!allowedDomainValues.includes(findMovsRequest.referenceType)) {
			throw new BadRequestException(`referenceType not valid`)
		}

		if (findMovsRequest.year < minYear) {
			throw new BadRequestException(`the min search year is ${minYear}`)
		}

		return await this.movementService.getAllTableBySearch({
			referenceNumber: findMovsRequest.referenceNumber,
			referenceType: findMovsRequest.referenceType,
			year: findMovsRequest.year,
			offset: findMovsRequest.offset,
			limit: findMovsRequest.limit,
		})
	}
	@HttpCode(200)
	@Post(posix.join("find-movement-by-adhesive-or-reference"))
	public async getAllTableByAdhesive(
		@Body() findMovsRequest: GetMovsByAdhes,
		@Req() request: Request
	): Promise<object> {
		this.loggingService.log(undefined, request)
		return await this.movementService.getAllTableByAdhesive({
			adhesiveOrRef: findMovsRequest.search,
		})
	}
	@HttpCode(200)
	@Post(posix.join("find-movement-by-id"))
	public async findMovementsById(
		@Body() findMovsRequest: FindMovById,
		@Req() request: Request
	): Promise<MovsByIdResponse> {
		this.loggingService.log(undefined, request)
		return await this.movementService.findMovementsById({
			movementId: Number(findMovsRequest.movementId),
		})
	}
}
