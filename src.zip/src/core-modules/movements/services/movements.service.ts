/** @format */

/** Custom imports */
import { FoundDomainDescription } from "@common-modules/dian-database/dtos/foundDomainDescription.dto"
import { DianDomainService } from "@common-modules/dian-database/services/dian-domain.service"
import { Injectable } from "@nestjs/common"

import { DianMovementsService } from "@common-modules/dian-database/services/dian-movements.service"
import { MovsTableResponse } from "../dtos/movs-table-response.dto"
import { MovsTableByAdhesiveResponse } from "../dtos/mov-by-adhesive-or-ref.dto"
import {
	DataFieldResponse,
	MovsByIdResponse,
} from "../dtos/movs-by-id-response.dto"
import { ValidationException } from "@common-artifacts/decorators/validation.filter"
import { modifiableFieldsDomain } from "@common-artifacts/constants/constants"

@Injectable()
export class MovementsService {
	public constructor(
		private readonly dianMovementsService: DianMovementsService,
		private readonly dianDomainService: DianDomainService
	) {}

	public async getAllTableBySearch(params: {
		referenceNumber: string
		referenceType: number
		year: number
		offset: number
		limit: number
	}): Promise<MovsTableResponse> {
		const movements: MovsTableResponse =
			await this.dianMovementsService.getTableMovements({
				referenceNumber: params.referenceNumber,
				referenceType: params.referenceType,
				year: params.year,
				offset: params.offset,
				limit: params.limit,
			})

		const responseObject: MovsTableResponse = {
			data: movements.data,
			count: movements.count,
		}

		return responseObject
	}
	public async getAllTableByAdhesive(params: {
		adhesiveOrRef: string
	}): Promise<MovsTableByAdhesiveResponse> {
		const movements: MovsTableByAdhesiveResponse =
			await this.dianMovementsService.getTableMovementsByAdhesiveOrRef({
				adhesiveOrRef: params.adhesiveOrRef,
			})
		const responseObject: MovsTableByAdhesiveResponse = {
			data: movements.data,
			count: movements.count,
		}

		return responseObject
	}
	public async findMovementsById(params: {
		movementId: number
	}): Promise<MovsByIdResponse> {
		try {
			const modifiableFields: object = {}

			const modifiableFieldsRaw: FoundDomainDescription[] =
				await this.dianDomainService.getDescriptionsByDomain(
					modifiableFieldsDomain
				)
			const realValueFields: string[] = modifiableFieldsRaw.map(
				(field: any) => field.realValue
			)

			const movements: any =
				await this.dianMovementsService.getTableMovementsById({
					movementId: params.movementId,
				})
			//Set modifiable keys
			Object.keys(movements).map((key: any) => {
				if (realValueFields.includes(key)) {
					modifiableFields[key] = true
				} else {
					modifiableFields[key] = false
				}
			})
			const responseObject: MovsByIdResponse = {
				data: movements,
				modifiableFields: modifiableFields as DataFieldResponse,
			}

			return responseObject
		} catch (error) {
			throw new ValidationException(
				"Bad Request. Datos de entrada no validos: movementId"
			)
		}
	}
}
