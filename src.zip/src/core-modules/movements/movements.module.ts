/** @format */

import { Module } from "@nestjs/common"
import { MovementsController } from "@core-modules/movements/controllers/movements.controller"
import { MovementsService } from "./services/movements.service"
import { DianDatabaseModule } from "@common-modules/dian-database/dian-database.module"

@Module({
	imports: [DianDatabaseModule],
	controllers: [MovementsController],
	providers: [MovementsService],
	exports: [MovementsService],
})
export class MovementsModule {}
