/** @format */

import { DianDatabaseModule } from "@common-modules/dian-database/dian-database.module"
import { LoggingService } from "@common-artifacts/logger-service/logging.service"
import { HttpModule } from "@nestjs/axios"
import { Global } from "@nestjs/common"
import { Module } from "@nestjs/common"

@Global()
@Module({
	imports: [HttpModule, DianDatabaseModule],
	providers: [LoggingService],
	exports: [LoggingService],
})
export class CustomLoggerModule {}
