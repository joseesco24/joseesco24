/** @format */

// ** info: nest imports
import { Injectable } from "@nestjs/common"
// import { Logger } from "@nestjs/common"

// ** info: nest axios imports
import { HttpService } from "@nestjs/axios"

// ** info: rxjs imports
import { catchError } from "rxjs"
import { throwError } from "rxjs"
import { Observable } from "rxjs"
import { map } from "rxjs"

// ** info: nest config imports
import { ConfigService } from "@nestjs/config"

import { v4 } from "uuid"

import * as requestIp from "request-ip"

@Injectable()
export class LoggingService {
	// private readonly logger: Logger = new Logger(LoggingService.name)

	private readonly loggingServiceUrl: string

	public constructor(
		private readonly httpService: HttpService,
		private readonly configService: ConfigService
	) {
		this.loggingServiceUrl = this.configService.get(
			"URL_LOGGER_SERVICE_LOGS" as string
		)
	}

	public log(response: any, request: any): Observable<any> {
		const isError: boolean =
			response !== undefined ? response.stack !== undefined : false

		const ip: string = requestIp
			.getClientIp(request)
			.toString()
			.replace("::ffff:", "")

		const sessionId: any = request.headers.iv

		const body: object = {
			level: isError ? "ERROR" : "INFO",

			ruta: "estadistico-dian",

			stackTrace:
				response !== undefined
					? response.stack !== undefined
						? response.stack
						: ""
					: "",

			requestId: v4(),

			request: {
				body: JSON.stringify(request.body),
				headers: request.headers,
				url: request.originalUrl,
			},

			initTimeStamp: new Date().toISOString(),

			endTimeStamp: new Date().toISOString(),

			response: response !== undefined ? JSON.stringify(response) : "",

			code: isError ? "ERRO00000" : "INFO00000",

			group: "process",

			message: isError ? "ERROR" : "OK",

			userIdentity: {
				sourceIp: ip,
				accountId: "2658478555",
				sessionId: sessionId,
				userAgent: request.headers["user-agent"],
				sessionChannelId: "app-estadistico-dian",
			},
		}

		// todo: change this log level
		// this.logger.log(body, "logger service request body")

		return this.httpService.post(`${this.loggingServiceUrl}`, body).pipe(
			map(() => {
				return response
			}),
			catchError((error: any) => {
				// this.logger.error({ metadata: error }, "error metadata")
				return throwError(() => error)
			})
		)
	}
}
