/** @format */
// todo: disable rule omition
/* eslint-disable @typescript-eslint/typedef */

import {
	ExceptionFilter,
	Catch,
	ArgumentsHost,
	HttpException,
	HttpStatus,
} from "@nestjs/common"
import { HttpAdapterHost } from "@nestjs/core"
import { ValidationException } from "./validation.filter"

@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
	public constructor(private readonly httpAdapterHost: HttpAdapterHost) {}

	// todo: correct any
	public catch(exception: any, host: ArgumentsHost): void {
		const { httpAdapter } = this.httpAdapterHost

		const ctx = host.switchToHttp()

		const httpStatus: number =
			exception instanceof HttpException
				? exception.getStatus()
				: HttpStatus.INTERNAL_SERVER_ERROR

		let httpMessage
		if (
			exception instanceof HttpException &&
			!(exception instanceof ValidationException)
		) {
			httpMessage = exception.message
		} else if (exception instanceof ValidationException) {
			httpMessage = exception.validationErrors
		} else {
			httpMessage = exception ? exception : "Internal Server Error"
		}

		const responseBody = {
			statusCode: httpStatus,
			timestamp: new Date().toISOString(),
			message: httpMessage,
			path: httpAdapter.getRequestUrl(ctx.getRequest()),
		}

		httpAdapter.reply(ctx.getResponse(), responseBody, httpStatus)
	}
}
