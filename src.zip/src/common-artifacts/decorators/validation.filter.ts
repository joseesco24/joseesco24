/** @format */

import { BadRequestException } from "@nestjs/common"

export class ValidationException extends BadRequestException {
	public constructor(public validationErrors: any) {
		super()
	}
}
