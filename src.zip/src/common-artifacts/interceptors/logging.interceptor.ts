/** @format */

// ** info: nest imports
import { NestInterceptor } from "@nestjs/common"
import { ExecutionContext } from "@nestjs/common"
import { HttpException } from "@nestjs/common"
import { CallHandler } from "@nestjs/common"
import { Injectable } from "@nestjs/common"
import { Logger } from "@nestjs/common"

// ** info: logger service imports
import { LoggingService } from "@common-artifacts/logger-service/logging.service"

// ** info: rxjs imports
import { Observable } from "rxjs"
import { catchError } from "rxjs"
import { throwError } from "rxjs"
import { switchMap } from "rxjs"
import { of } from "rxjs"

@Injectable()
export class LoggingInterceptor implements NestInterceptor {
	private readonly logger: Logger = new Logger(LoggingInterceptor.name)

	public constructor(private readonly loggingService: LoggingService) {}

	public intercept(
		context: ExecutionContext,
		next: CallHandler
	): Observable<any> {
		const request: any = context.switchToHttp().getRequest()

		return next.handle().pipe(
			catchError((error: any) => {
				return this.loggingService.log(error, request).pipe(
					switchMap((response: any) => {
						return throwError(() => response)
					}),

					catchError(() => {
						if (error.status !== 400) {
							return throwError(
								() =>
									new HttpException(
										{
											message: error.message,
										},
										error.status
									)
							)
						} else {
							return throwError(() => error)
						}
					})
				)
			}),

			switchMap((data: any) => {
				return this.loggingService.log(data, request).pipe(
					switchMap(() => {
						return of(data)
					}),

					catchError(() => {
						return of(data)
					})
				)
			})
		)
	}
}
