/** @format */

import { BadRequestException } from "@nestjs/common"
import { ArgumentMetadata } from "@nestjs/common"
import { PipeTransform } from "@nestjs/common"
import { Injectable } from "@nestjs/common"

import * as moment from "moment"

@Injectable()
export class ParseDatePipe implements PipeTransform {
	public transform(
		value: Date | undefined = undefined,
		metadata: ArgumentMetadata
	): Date {
		if (value === undefined) {
			throw new BadRequestException(`${metadata.data} is required`)
		}
		const momentDate: moment.Moment = moment(value)
		if (!momentDate.isValid()) {
			throw new BadRequestException(
				`${metadata.data} value ${momentDate.format("YYYY-MM-DD")} is not valid`
			)
		}
		return value
	}
}
