/** @format */

// Needed imports.
import { BadRequestException } from "@nestjs/common"
import { ArgumentMetadata } from "@nestjs/common"
import { PipeTransform } from "@nestjs/common"
import { Injectable } from "@nestjs/common"

@Injectable()
export class ParseIntOptionalPipe implements PipeTransform {
	public transform(
		value: string | undefined = undefined,
		metadata: ArgumentMetadata
	): number | undefined {
		if (value === undefined) {
			return undefined
		}
		const val: number = Number(value)
		if (isNaN(val)) {
			throw new BadRequestException(
				`${metadata.data} value ${value} is not an number`
			)
		}
		return val
	}
}
