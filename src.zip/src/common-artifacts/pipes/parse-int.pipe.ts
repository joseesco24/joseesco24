/** @format */

// Needed imports.
import { BadRequestException } from "@nestjs/common"
import { ArgumentMetadata } from "@nestjs/common"
import { PipeTransform } from "@nestjs/common"
import { Injectable } from "@nestjs/common"

@Injectable()
export class ParseIntPipe implements PipeTransform {
	public transform(
		value: string | undefined = undefined,
		metadata: ArgumentMetadata
	): number {
		if (value === undefined) {
			throw new BadRequestException(`${metadata.data} is required`)
		}
		const val: number = Number(value)
		if (isNaN(val)) {
			throw new BadRequestException(
				`${metadata.data} value ${value} is not an number`
			)
		}
		return val
	}
}
