/** @format */
/* eslint-disable @typescript-eslint/naming-convention */

// ** info: joi import
import * as Joi from "joi"

// ** info: valid environment modes
const validEnvironmentModes: string[] = ["development", "production"]

// ** info: validating env variables with joi
export const validationSchema: Joi.ObjectSchema<any> = Joi.object({
	// ** info: app environment
	ENVIRONMENT_MODE: Joi.string()
		.required()
		.valid(...validEnvironmentModes),

	// ** info: app listening port
	HTTP_PORT: Joi.number().required(),

	// ** info: database env variables
	POSTGRES_PASSWORD: Joi.string().required(),
	POSTGRES_DATABASE: Joi.string().required(),
	POSTGRES_SCHEMA: Joi.string().required(),
	POSTGRES_HOST: Joi.string().required(),
	POSTGRES_PORT: Joi.number().required(),
	POSTGRES_USER: Joi.string().required(),

	REPORT_GENERATION_TIMEOUT: Joi.number().required(),

	URL_REPORT_SERVICE_REPORTS: Joi.string().required(),
	URL_AUTH_SERVICE_VALIDATE: Joi.string().required(),
	URL_LOGGER_SERVICE_LOGS: Joi.string().required(),

	// ** info: auth middleware config
	ACTIVE_AUTH: Joi.boolean(),
})
