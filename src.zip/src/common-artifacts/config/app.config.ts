/** @format */

// ** info: nest imports
import { registerAs } from "@nestjs/config"

export default registerAs("config", (): object => {
	const configDict: object = new Object({
		// ** info: app environment
		nodeEnv: process.env.ENVIRONMENT_MODE,

		// ** info: app listening port
		port: parseInt(process.env.HTTP_PORT, 10) || 3000,

		// ** info: database env variables
		postgresPassword: process.env.POSTGRES_PASSWORD,
		postgresDatabase: process.env.POSTGRES_DATABASE,
		postgresSchema: process.env.POSTGRES_SCHEMA,
		postgresHost: process.env.POSTGRES_HOST,
		postgresPort: parseInt(process.env.POSTGRES_PORT, 10) || 5432,

		urlReportServiceReports: process.env.URL_REPORT_SERVICE_REPORTS,
		urlAuthServiceValidate: process.env.URL_AUTH_SERVICE_VALIDATE,
		urlLoggerServiceLogs: process.env.URL_LOGGER_SERVICE_LOGS,

		reportGenerationTimeout: process.env.REPORT_GENERATION_TIMEOUT,

		// ** info: auth middleware config
		activeAuth: process.env.ACTIVE_AUTH,
	})
	return configDict
})
