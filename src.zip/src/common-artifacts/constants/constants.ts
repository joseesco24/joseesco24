/** @format */
/* eslint-disable @typescript-eslint/naming-convention */

export const months: object = new Object({
	1: "enero",
	2: "febrero",
	3: "marzo",
	4: "abril",
	5: "mayo",
	6: "junio",
	7: "julio",
	8: "agosto",
	9: "septiembre",
	10: "octubre",
	11: "noviembre",
	12: "diciembre",
})

export const databaseErrorMessage: number = 19
export const noMovementsErrorMessage: number = 62
export const serviceReportErrorMessage: number = 63

//domain related constants
export const fileDebitPseDomainId: number[] = [4]
export const fileCreditPseDomainId: number[] = [5]
export const officeChannelDomainIds: number[] = [37]
export const electronicChannelDomainIds: number[] = [39]
export const creditCardChannelDomainIds: number[] = [38, 40]
export const dayTypeDomain: string = "ind_jornada"
export const dateTypeDomain: string = "tipo_fecha"
export const defaultDateTypeDomain: string = "tipo_fecha_predefinido"
export const defaultDateTypeDomainId: number = 27
export const defaultDayTypeDomain: string = "ind_jornada_predefinido"
export const defaultDayTypeDomainId: number = 28
export const defaultEarFilterDomain: string = "filtro_oficina_predefinido"
export const defaultEarFilterDomainId: number = 29
export const allOfficesDomain: string = "id_todas_oficinas"
export const allOfficesDomainId: number = 49
export const dateRangeDomainId: number = 26
export const limitOfficeDomainId: number = 30
export const csvEnabledDomainId: number = 31
export const paymentChannelDomain: string = "canal_pago"
export const reportTypeDomain: string = "tipo_reporte"
export const titlesReportDomain: string = "titulos_generacion_reporte"
export const consolidatedChannelDomain: string = "forma_de_pago_impuestos_dian"
export const consolidatedtypeFormDomain: string = "tipo_formulario"
export const consolidatedColumnsQuery: string = "columnas_consolidado_query"
export const reportServiceUrlParam: string = "url_report_service_reports"
export const authServiceUrlParam: string = "url_auth_service_validate"
export const loggingServiceUrlParam: string = "url_logger_service_logs"
export const maxLimitTaxTableParam: string = "max_limit_tax_table"
export const columnRefListQuery: string = "column_ref_list_query"

export const bucketGcp: string = "bucket_gcp"

export const maxLimitIssuesDomainId: number = 167
export const maxLimitIssuesDomain: string = "limite_maximo_inconsistencias"
export const taxTableFilterDomain: string = "filtros_tabla_impuestos"
export const taxTableTitlesDomain: string = "titulos_tabla_impuestos"
export const issuesTableTitlesDomain: string = "titulos_tabla_inconsistencias"
export const issuesTableFilterDomain: string = "filtros_tabla_inconsistencias"
export const modifiableFieldsIssuesDomain: string = "campos_modificables_incons"
export const issueTypeDomain: string = "indicador_tipo_inconsistencia"
export const foundIssuesTitlesDomain: string = "titulos_buscar_incons"
export const dayTypeIssuesDomain: string = "ind_jornada_incons"
export const contributionIndDomain: string = "indicador_aporte"
export const paymentMethodDomain: string = "medio_pago"
export const dianModeDomain: string = "modalidad_dian"
export const consChannelDefaultDomain: string =
	"forma_de_pago_impuestos_dian_predef"
export const officeChannelIssuesIds: number[] = [1, 2]
export const electronicChannelIssuesIds: number[] = [3, 4]
export const inclusionTypeDomainId: number = 162
export const excludeTypeDomainId: number = 163
export const modificationTypeDomainId: number = 164

export const vigente: string = "Vigente"
export const cancelado: string = "Cancelado"
export const ninguno: string = "Ninguno"

export const addIssuesTaxesDomain: string = "impuestos_agregar_inc"
export const taxesAddTaxesDomain: string = "impuestos_agregar_impuesto"

export const noParentTaxName: string = "Ninguno"
export const noParentTaxId: number = 77777
export const taxStatusDomain: string = "vigencia_impuestos"
export const errorPostgresUniqueKey: string = "23505"

export const modifiableFieldsDomain: string = "campos_modificables_incons"
