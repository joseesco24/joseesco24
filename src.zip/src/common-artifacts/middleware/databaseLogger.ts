/** @format */

import { Logger as TypeOrmLogger } from "typeorm"
import { Logger as NestLogger } from "@nestjs/common"

class DatabaseLogger implements TypeOrmLogger {
	private readonly logger: NestLogger = new NestLogger("Postgres")

	public logQuery(query: string, parameters?: undefined[]): void {
		this.logger.debug(
			`${query} -- Parameters: ${this.stringifyParameters(parameters)}`
		)
		return
	}

	public logQueryError(
		error: string,
		query: string,
		parameters?: undefined[]
	): void {
		this.logger.error(
			`${query} -- Parameters: ${this.stringifyParameters(
				parameters
			)} -- ${error}`
		)
		return
	}

	public logQuerySlow(
		time: number,
		query: string,
		parameters?: undefined[]
	): void {
		this.logger.warn(
			`Time: ${time} -- Parameters: ${this.stringifyParameters(
				parameters
			)} -- ${query}`
		)
		return
	}

	public logMigration(message: string): void {
		this.logger.debug(message)
		return
	}

	public logSchemaBuild(message: string): void {
		this.logger.debug(message)
		return
	}

	public log(level: "log" | "info" | "warn", message: string): void {
		if (level === "log") {
			this.logger.debug(message)
			return
		}
		if (level === "info") {
			this.logger.debug(message)
			return
		}
		if (level === "warn") {
			this.logger.warn(message)
			return
		}
	}

	private stringifyParameters(parameters?: undefined[]): string {
		try {
			return JSON.stringify(parameters)
		} catch {
			return ""
		}
	}
}

export default DatabaseLogger
