/** @format */

// ** info: nest imports
import { NestMiddleware } from "@nestjs/common"
import { Injectable } from "@nestjs/common"
import { Logger } from "@nestjs/common"

// ** info: express imports
import { NextFunction } from "express"
import { Response } from "express"
import { Request } from "express"

import { AuthenticationService } from "@common-modules/authentication/authentication.service"

@Injectable()
export class AuthMiddleware implements NestMiddleware {
	private readonly logger: Logger = new Logger(AuthMiddleware.name)

	public constructor(
		private readonly authenticationService: AuthenticationService
	) {}

	public exit(res: Response): void {
		res.status(401).json({
			error: "Error auth invalida",
		})
		return
	}

	public use(request: Request, response: Response, next: NextFunction): void {
		const jwt: string | string[] = request.headers.jwt
		const iv: string | string[] = request.headers.iv

		if (!jwt || !iv) {
			return this.exit(response)
		}

		this.authenticationService.checkAuth(jwt, iv).subscribe({
			next: () => {
				next()
			},
			error: () => {
				this.exit(response)
			},
		})

		return
	}
}
